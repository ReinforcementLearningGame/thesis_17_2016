/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygamel.GameClasses.Actions;

import com.mygdx.rlstrategygamel.GameClasses.BoardLocation;
import com.mygdx.rlstrategygamel.GameClasses.GameState;
import com.mygdx.rlstrategygamel.GameClasses.Units.Knight;
import com.mygdx.rlstrategygamel.GameClasses.Units.Unit;

/**
 * Action that moves the selected pawn from a BoardLocation to a nearby one
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class Transposition extends GameAction{
    
    public static boolean isTransposition(String string){
        //to string na ksekinaei apo "tra"
        int index1 = string.indexOf("tra");
        if(index1!=0)return false;
        //o tetartos xaraktiras na einai ','
        index1 = string.indexOf(',');
        if(index1!=3)return false;
        //an den iparxei deutero komma ','
        int index2 = string.indexOf(',',index1+1);
        if(index2==-1)return false;
        //an den iparxei deutero komma ','
        int index3 = string.indexOf(',',index2+1);
        if(index3==-1) return false;
        try{
            Integer.parseInt(string.substring(index1+1, index2));
            Integer.parseInt(string.substring(index2+1, index3));
            Integer.parseInt(string.substring(index3+1));
        }
        catch(NumberFormatException e){
            return false;
        }
        return true;
    }
    
    public Transposition(int actingUnitX, int actingUnitZ,int direction) {
        super(actingUnitX, actingUnitZ);
        this.direction = direction;
    }
    
    public Transposition(Unit unit,int direction) {
        super(unit.location.x, unit.location.z);
        this.direction = direction;
    }
    
    public Transposition(String string){
        super(0,0);
        int index1 = string.indexOf(',');
        int index2 = string.indexOf(',',index1+1);
        int index3 = string.indexOf(',',index2+1);
        int x,z,d;
        x=Integer.parseInt(string.substring(index1+1, index2));
        z=Integer.parseInt(string.substring(index2+1, index3));
        d=Integer.parseInt(string.substring(index3+1));
        this.actingUnitX = x;
        this.actingUnitZ = z;
        this.direction = d;
    }
    
    //Checks if this attack can be perforded to this gameState
    public boolean isValid(GameState gameState){
        BoardLocation targetLocation;

        //i metatopisi einai egkuri ws enegreia 
        if(!super.isValid(gameState))return false;
        //energeia pros thesi ektws pistas
        targetLocation = gameState.locations[this.actingUnitX][this.actingUnitZ].next(this.direction);
        if(targetLocation == null) return false;
        //System.out.println("Valid Targetlocation");
        //energeia pros nogo thesi
        if(!targetLocation.canGo) return false;
        //System.out.println("Targetlocation CanGo");
        //energeia pros katilimeni thesi
        if(targetLocation.captured) return false;
        //System.out.println("Targetlocation Not Captured");
        //knight prospathei na kanei bros pisw

        Unit movingUnit = gameState.locations[this.actingUnitX][this.actingUnitZ].unit;
        if(movingUnit instanceof Knight){
            Knight tempKnight = (Knight)movingUnit;
            if(targetLocation == tempKnight.startingLocation){
                //System.out.println("Transposition fail bros pisw "+tempKnight.startingLocation.x+"-"+tempKnight.startingLocation.z);
                return false;
            }
        }
        // i metatopisi borei na ektelestei
        //System.out.println("Valid Transposition");
        return true;
    }
    
    public String toString(){
        return new String("tra,"+this.actingUnitX+","+this.actingUnitZ+","+this.direction);
    }
}
