/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygamel.RL_Agents;

import com.mygdx.rlstrategygamel.GameClasses.Actions.GameAction;
import com.mygdx.rlstrategygamel.GameClasses.GameState;
import com.mygdx.rlstrategygamel.GameClasses.Units.Infantry;
import com.mygdx.rlstrategygamel.GameClasses.Units.Knight;
import com.mygdx.rlstrategygamel.GameClasses.Players.Player;
import com.mygdx.rlstrategygamel.GameClasses.Settings;
import com.mygdx.rlstrategygamel.GameClasses.Units.Spearman;
import com.mygdx.rlstrategygamel.GameClasses.Units.Unit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;




/**
 * This is a reinforcement learning Agent, extending the RLAgent class, in order to implement the RL algorithm of TD(λ) learning.
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class TDAgent extends RLAgent{
    
    
    /**
     * The discount rate parameter
     */
    protected double gamma;
    
    /**
     * The decaying factor of the eligibility traces
     */
    protected double lambda;
    
    /**
     * The Filename where the ANN will be saved
     */
    protected String neuralNetFileName;
    
    protected Settings gameSettings;
    
    /**
     * The desired number of output nodes of the ANN
     */
    protected int outputNodes=1;
    
    /**
     *Keep the ID of the player that agent controls.
     */
    protected int playerID;
    
    /**
     * Previous state's number of alive agent's units
     */
    protected int oldAlliedUnits;
    
    /**
     * Previous state's number of alive opponent's units
     */
    protected int oldEnemyUnits;

    /**
     * Minimum reward that agent can take
     */    
    protected double minReward;
    
    /**
     * Maximum reward that agent can take
     */
    protected double maxReward;

    /**
     * Keep the number of different type of units
     */
    protected int unitTypes = 0;
    
    /**
     * Every neural net has 2-4 nodes for every track position.
     * Keep the node matches with agent's infantry.
     */
    protected int infantryPosition = 0;
    
    /**
     * Every neural net has 2-4 nodes for every track position.
     * Keep the node matches with agent's spearman.
     */
    protected int spearmanPosition = 0;
    
    /**
     * Every neural net has 2-4 nodes for every track position.
     * Keep the node matches with agent's Knight.
     */
    protected int knightPosition = 0;
    
    /**
     * Keep the number of Infantries that agent controls. 
     */
    protected int numberOfInfantries = 0;
    
    /**
     * Keep the number of Spearmen that agent controls. 
     */
    protected int numberOfSpearmen = 0;
    
    /**
     * Keep the number of Knights that agent controls. 
     */
    protected int numberOfKnights = 0;
    
    /**
     * It is true, if after agent's action, game approaches certainly to the final state.
     */
    private boolean approachToFinalState;
    
    
    /**
     * Constructor of the TD Agent
     */
    public TDAgent(){
        
    }
    
    /**
     * Constructor with parameters
     * @param playerID The player(red or blue) who is controlled by the agent
     * @param initialState The initial state of the game that agent will play
     * @param gameSettings  The settings of the game
     */
    public TDAgent(Settings gameSettings, int playerID, GameState initialState){
        
        this.RLMethod = "TD(λ)";
        this.minReward = gameSettings.getMinReward();
        this.maxReward = gameSettings.getMaxReward();

        this.playerID = playerID;
        Player RLPlayer = null;
        if (playerID==0) {
            this.gamma = gameSettings.getRedGamma();
            this.lambda = gameSettings.getRedLambda();
            this.eGreedyValue = gameSettings.getRedEGreedy();
            RLPlayer = initialState.redPlayer;
        }
        else if (playerID==1){
            this.gamma = gameSettings.getBlueGamma();
            this.lambda = gameSettings.getBlueLambda();
            this.eGreedyValue = gameSettings.getBlueEGreedy();
            RLPlayer = initialState.bluePlayer;
        }
        else System.out.println("Error setting player");
        this.gameSettings = gameSettings;
        
        
        this.neuralNetFileName = gameSettings.getTrack();
        
        //count the mapPositions (CanGo)
        int mapPositions = 0;
        for(int i=0;i<initialState.game.Xmax;i++)
            for(int j=0;j<initialState.game.Zmax;j++)
                if(initialState.locations[i][j].canGo) mapPositions++;
        
        //count type of units in the track

        for(int i=0;i<RLPlayer.units.length;i++)
            if(RLPlayer.units[i] instanceof Infantry){
                infantryPosition = 1;
                numberOfInfantries++;
            }
            else if(RLPlayer.units[i] instanceof Spearman){
                spearmanPosition = 1;
                numberOfSpearmen++;
            }
            else if(RLPlayer.units[i] instanceof Knight){
                knightPosition = 1;
                numberOfKnights++;
            }
            
        unitTypes = infantryPosition + spearmanPosition + knightPosition;
        infantryPosition = 0;
        spearmanPosition = infantryPosition+spearmanPosition;
        knightPosition = infantryPosition+spearmanPosition+knightPosition;
        
        //neural net input size is: [(UNIT TYPES IN GAME + 1)  x TRACK POSITIONS ] + UNIT TYPES IN GAME 
        //comment out the appropriate line in accordance with which worldToNeuralInput() method you want to use
        
        int inputNodes = (unitTypes + 1) * mapPositions + unitTypes;
        int hiddenNodes = inputNodes;
        if(playerID==0){
            //Try to load the neural network from file, or initalize
            if(gameSettings.redNeuralNet==null) this.neuralNetwork = new NeuralNet(inputNodes, hiddenNodes, outputNodes, gamma, lambda, neuralNetFileName);
            //Take the neural network from game setting
            else this.neuralNetwork = gameSettings.redNeuralNet;
        }
        else{
            //Try to load the neural network from file, or initalize
            if(gameSettings.blueNeuralNet==null) this.neuralNetwork = new NeuralNet(inputNodes, hiddenNodes, outputNodes, gamma, lambda, neuralNetFileName);
            //Take the neural network from game setting
            else this.neuralNetwork = gameSettings.blueNeuralNet;
        }
    }
    
    /**
     * Used to initialize the TD Agent before he starts making decisions.
     * @param state the initial game state
     */
    @Override
    public void initialize(GameState state){
        
        //System.out.println("Initializing TD Agent");
        
        if(this.playerID == 0){//red Player uses the TD Agent
            this.oldAlliedUnits = state.redPlayer.numberofAliveUnits;
            this.oldEnemyUnits = state.bluePlayer.numberofAliveUnits;
        }
        else{//blue player uses the TD Agent
            this.oldAlliedUnits = state.bluePlayer.numberofAliveUnits;
            //System.out.println(state.bluePlayer.numberofAliveUnits);
            this.oldEnemyUnits = state.redPlayer.numberofAliveUnits;
        }
        
        neuralNetwork.setInput(worldToNeuralInput(state)); //set the initial game state as an input to the neural network
        neuralNetwork.setOldOutputNode(neuralNetwork.response());
        neuralNetwork.updateElig();
        //System.out.println("TD agent for Player " + this.player.getPlayerId() + " initialized.");
    }
        
    
    /**
     * The method used for choosing an action among the legal actions.
     * @param legalActions the legal actions the player can make during his turn
     * @param state the current game state
     * @return the action, chosen by the agent
     */
    
    @Override
    public GameAction[] chooseAction(ArrayList<GameAction[]> legalActions, GameState state) {
        //System.out.println("Player " + player.getPlayerId()+" Nr of Pawns " + player.getAlivePawns().size() + ". Player choosing from "+legalActions.size());
        int chosenIndex = 0;
        double actionValue = 0;
        double largestValue = -Double.MAX_VALUE;
        GameAction[] choice = null;
        //error checking
        if (legalActions == null){
            System.out.println("Error! No actions were passed (legalActions pointer NULL)");
            return null;
        }
        
        float choiceRoll = new Random().nextFloat();    //roll the "dice" to decide EXPLOIT or EXPLORE
        //System.out.println("choiceRoll "+choiceRoll);
        //System.out.println("=======================================");
        //System.out.println("Choosing action from available actions.");
        //System.out.println("=======================================");

        ArrayList <GameAction[]> chosenActions = new ArrayList<GameAction[]>(); 
        
        if(choiceRoll > eGreedyValue){//If ***E X P L O R I N G***
            //System.out.println("E X P L O R I N G");
            chosenIndex = new Random().nextInt(legalActions.size());    //generate a random index and
            choice = legalActions.get(chosenIndex);                     //choose the action of the index
            //choice.setExploiting(false);                                //The action is NOT an exploiting one
            //System.out.println(choice.toString());
            
        }
        else{// Else ***E X P L O I T I N G***
            //System.out.println("E X P L O I T I N G");
            for (GameAction[] action : legalActions){         //for every legal action
                //System.out.println("Checking ..."+action.toString());
                actionValue = simulateMove(action, state);         //simulate the action and get the value of the emerging afterstate
                //System.out.println("Value calculated"+ actionValue);
                if (actionValue >= largestValue) {      //IF the value of the action is the greatest yet encountered
                    if(actionValue > largestValue){     //New largest value
                        largestValue = actionValue;     //set the largest value to this action's value
                        chosenActions.clear();          // clear the list                                           
                    }
                    chosenActions.add(action);          //Add the action to the list    
                }//ELSE DO NOTHING. Don't do anything with the action   
            } //end for
            
            if(chosenActions.size() > 1){ //if there are more than one actions with the SAME value of afterstate
                chosenIndex = new Random().nextInt(chosenActions.size());   //pick a random action from those actions arraylist
                choice = chosenActions.get(chosenIndex);
                //choice.setExploiting(true);
            }
            else{
                choice = chosenActions.get(0);      //Else return the first (and only) entry of the array
                //choice.setExploiting(true);
            }
            //System.out.println("Maximum Value "+ largestValue);
            
        }//end else
        //System.out.println("Chosen "+choice.toString());
        return choice;
    }
    
    /**
     * Simulate a move for a pawn and check for the accumulated stateValue.
     * @param action the action to be simulated
     * @param state the current game state
     * @return the estimated value of the occurring state (the first node of the ANN output)
     */
    private double simulateMove(GameAction[] action, GameState state) {

        double [] stateValue = new double[outputNodes];  //initialize a double array to hold the stateValue of the action
        //System.out.println("TD Agent Simulate move");
        state.perform(action[0]);
        if(action.length==2) state.perform(action[1]);
        //check if the action results in a winning or loosing state for the pawns owner
        //System.out.println("Checking for final state");
        double reward = rewardFunction(state);
        if(this.approachToFinalState){
            if (reward==this.maxReward) stateValue [0] = 1d;
            else if (reward==this.minReward) stateValue [0] = 0d;
            this.approachToFinalState = false;
        }
        else{
            neuralNetwork.setInput(worldToNeuralInput(state));//set the emerging game state as an input to the neural network
            //System.out.print("NNF Response");
            stateValue = neuralNetwork.response();
            //System.out.println("simulated state"+stateValue[0]);
        }

        //UNDO the changes to the board
        state.undo();
        return stateValue[0];
    }

    



    /**
     * Learn from the last action the Agent made
     * @param chosenAction The chosen action
     * @param state the current game state
     */
    @Override
    public void learnFromAction(GameState state,GameAction[] chosenAction) {
        //this TD agent may only learn from the afterstate of each turn
        
        //visit afterstate
        state.perform(chosenAction[0]);
        if(chosenAction.length==2) state.perform(chosenAction[1]);
        //updates approachToFinalState value
        rewardFunction(state);
        //learn from afterstate 
        if(!approachToFinalState) learnFromAfterstate(state);
        this.approachToFinalState = false;
        //go back to the previous state.
        //Agent has choosen his action but is is going to be performed by the game loop
        state.undo();
    }
    
    /**
     * Learn from the afterstate that emerges after the agent's last action.
     * @param state the current game state
     */
    @Override
    public void learnFromAfterstate(GameState state){
        //apply the world stimulus (the afterstate of the action) to the ANN
        //System.out.println("*******Player***" + state.activePlayer.id+ " Learning from afterstate********");
        //System.out.println("learn from afterstate");
        neuralNetwork.setInput(worldToNeuralInput(state));
        double [] reward = new double[outputNodes];
        
        //if (world.isFinalState() == player){
        //for (int i = 0 ; i < reward.length ; i++ ){
        //reward[i] = Settings.MAX_REWARD;    
        //System.out.println("Winner is player "+player.getPlayerId());   
        //}
        //else
        //for (int i = 0 ; i < reward.length ; i++ )
        //   reward[i] = Settings.MIN_REWARD;
        
        for (int i = 0 ; i < reward.length ; i++ ){
           reward[i] = this.currentReward;//rewardFunction(state);
        }    
        //System.out.println("Rewarding..."+reward[0]);
       
        neuralNetwork.singleStep( reward );
    }

    /**
     * Finalizing learning after the game has ended.
     */
    @Override
    public void endOfGame() {
        //Game ended. Saving neuralNetworks on GameSettings

        //cleaning nodes and eligibility traces 
        neuralNetwork.cleanNodes();
        
        //saves the neural net to settings
        if(playerID == 0) this.gameSettings.redNeuralNet = neuralNetwork;
        else this.gameSettings.blueNeuralNet = neuralNetwork;
    }
    
    /**
    * Transform the game state to a binary input for the neural network.
    * @return an ArrayList to be used as input to the neural network
    * @param state the current game state
    */
    
    public ArrayList<Double> worldToNeuralInput(GameState state) {
        
        ArrayList<Double> input = new ArrayList<Double>();
        Double[] positionState = new Double[this.unitTypes+1];
        for(int i=0;i<this.unitTypes+1;i++) positionState[i]=-3.0;
        
        int zStart,zEnd,dZ,xStart,xEnd,dX;        
        Unit[] enemyUnits;

        if(this.playerID == 0){
            zStart = 0; zEnd= state.game.Zmax;dZ=1;
            xStart = 0; xEnd= state.game.Xmax;dX=1;
            enemyUnits = state.bluePlayer.units;
        }
        else{
            zStart = state.game.Zmax-1; zEnd=-1;dZ=-1;
            xStart = state.game.Xmax-1; xEnd=-1;dX=-1;
            enemyUnits = state.redPlayer.units;
        }
        
        int RLInfantries = 0;
        int RLSpearmen = 0;
        int RLKnights = 0;
        int enemyInfantries = 0;
        int enemySpearmen = 0;
        int enemyKnights = 0;
        
        for(int j=zStart; j!=zEnd;j+=dZ){

            for(int i=xStart; i!=xEnd; i+=dX){

                if(!state.locations[i][j].canGo) continue;
                else if(!state.locations[i][j].captured) input.addAll(Arrays.asList(positionState));
                else{
                    
                    //enemyUnint
                    if(state.locations[i][j].unit.player.id != this.playerID){
                        positionState[this.unitTypes] = 1.0;
                        input.addAll(Arrays.asList(positionState));
                        positionState[this.unitTypes] = -3.0;
                        
                        if(state.locations[i][j].unit instanceof Infantry) enemyInfantries++;
                        else if(state.locations[i][j].unit instanceof Spearman) enemySpearmen++;
                        else enemyKnights++;
                        
                        continue;
                    }
                    
                    int unitType = this.infantryPosition;
                    if(state.locations[i][j].unit instanceof Infantry) RLInfantries++;
                    if(state.locations[i][j].unit instanceof Spearman){
                        unitType = this.spearmanPosition;
                        RLSpearmen++;
                    }
                    if(state.locations[i][j].unit instanceof Knight){
                        unitType = this.knightPosition;
                        RLKnights++;
                    }
                    
                    boolean attack = false;
                    boolean defence = false;
                    for(Unit enemyUnit:enemyUnits){
                        if(!enemyUnit.alive) continue;
                        if(state.locations[i][j].unit.canBeAttackedNextTurnBy(enemyUnit)){
                            defence = true;
                            break;
                        }
                        if(enemyUnit.canBeAttackedNextTurnBy(state.locations[i][j].unit)) attack = true;
                    }
                    
                    if(defence){//unit is under threat
                        positionState[unitType] = -1.0;
                    }
                    else if(attack){ //unit is threating an enemy unit
                        positionState[unitType] = 3.0;
                    }
                    else{//no threats
                        positionState[unitType] = 2.5;
                    }
                    
                    input.addAll(Arrays.asList(positionState));
                    positionState[unitType] = -3.0;
                } 
            }
        }
        if(this.numberOfInfantries>0)input.add((double)(RLInfantries-enemyInfantries)/this.numberOfInfantries);
        if(this.numberOfSpearmen>0)input.add((double)(RLSpearmen-enemySpearmen)/this.numberOfSpearmen);
        if(this.numberOfKnights>0)input.add((double)(RLKnights-enemyKnights)/this.numberOfKnights);
        
        return input;
    }
    
    /**
    * Update the current reward and the number of alive units for each player. 
    * @param state the current game state
    */
    public void updateCurrentReward(GameState state){
        this.currentReward = rewardFunction(state);
        
        if(this.playerID == 0){//red Player uses the TD Agent
            this.oldAlliedUnits = state.redPlayer.numberofAliveUnits;
            this.oldEnemyUnits = state.bluePlayer.numberofAliveUnits;
        }
        else{//blue player uses the TD Agent
            this.oldAlliedUnits = state.bluePlayer.numberofAliveUnits;
            this.oldEnemyUnits = state.redPlayer.numberofAliveUnits;
        }
    }
    
    /**
    * Calculate the agent's reward. 
    * @return the agent's reward
    * @param state the current game state
    */
    public double rewardFunction(GameState state){
        this.approachToFinalState = false;
        if(this.playerID==0){//red player is using the agent
            
            if(state.gameOver){
                if (state.winner==null) return 0; //draw
                this.approachToFinalState = true;
                if (state.winner.id==0) return maxReward; //win
                else return minReward; //loose
            }
            
            //red flag is captured by blue unit at the end of the turn --- Lose red
            if(state.remainingMoves == 0 && state.redPlayer.flag.captured && state.redPlayer.flag.unit.player.id == 1){
                //System.out.println("red flag is captured by blue unit at the end of the turn --- Lose red");
                this.approachToFinalState = true;
                return minReward;
            }
            
            //blue flag is captured by red unit 
            if(state.bluePlayer.flag.captured && state.bluePlayer.flag.unit.player.id==0){

                boolean winOnNextState = true;
                for(Unit blueUnit:state.bluePlayer.units)
                    if(state.bluePlayer.flag.unit.canBeAttackedNextTurnBy(blueUnit)){
                        winOnNextState = false;
                        break;
                    }
                if(winOnNextState){
                    this.approachToFinalState = true;
                    return maxReward;
                }
            }
            
            //no flag is captured  
            //no elimination reward
            if(!this.gameSettings.getRedEliminationReward()) return 0.0;
            //elimination reward
            double result = state.redPlayer.numberofAliveUnits/(double)this.oldAlliedUnits - state.bluePlayer.numberofAliveUnits/(double)this.oldEnemyUnits;
            if(result<0.0) return 0.0; //no penalty for losing a pawn
            else if (result>0.0) return maxReward*result; //reward for eliminating a pawn
            return result;
            
        }
        else{//blue player is using the agent
            
            if(state.gameOver){
                //System.out.println("final state");
                //if (state.winner==null) return 0; //draw
                if (state.winner.id==0) return minReward; //loose
                else return maxReward; //win
                
            }
            //blue flag is captured by red unit at the end of the turn --- Lose blue
            if(state.remainingMoves == 0 && state.bluePlayer.flag.captured && state.bluePlayer.flag.unit.player.id == 0){
                //System.out.println("blue flag is captured by red unit at the end of the turn --- Lose blue");
                this.approachToFinalState = true;
                return minReward;
            }
            
            //red flag is captured by blue unit
            if(state.redPlayer.flag.captured && state.redPlayer.flag.unit.player.id==1){

                    boolean winOnNextState = true;
                    for(Unit redUnit:state.redPlayer.units)
                    if(state.redPlayer.flag.unit.canBeAttackedNextTurnBy(redUnit)){
                        winOnNextState = false;
                        break;
                    }
                    if(winOnNextState){
                        this.approachToFinalState = true;
                        return maxReward;
                    }
                }

            //no flag is captured
            //no elimination reward
            if(!this.gameSettings.getBlueEliminationReward()) return 0.0;
            //elimination reward
            double result = state.bluePlayer.numberofAliveUnits/(double)this.oldAlliedUnits - state.redPlayer.numberofAliveUnits/(double)this.oldEnemyUnits;
            if(result<0.0) return 0.0;//no penalty for losing a pawn
            else if (result>0.0) return maxReward*result; //reward for eliminating a pawn
            return result;
        }
    }  
}
