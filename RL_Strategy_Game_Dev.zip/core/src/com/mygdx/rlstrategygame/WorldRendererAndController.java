/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygame;

/**
 *
 * @author Alexandros
 */
import com.mygdx.rlstrategygame.GameClasses.Players.Player;
import com.mygdx.rlstrategygame.GameClasses.Players.HumanPlayer;
import com.mygdx.rlstrategygame.GameClasses.Players.ComputerPlayer;
import com.mygdx.rlstrategygame.Graphics.*;
import com.mygdx.rlstrategygame.GameClasses.*;
import com.mygdx.rlstrategygame.Intelligence.*;
import com.badlogic.gdx.Application;
import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.graphics.g3d.Environment;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.ModelBatch;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.environment.DirectionalLight;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.math.collision.Ray;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.Touchable;
import com.badlogic.gdx.scenes.scene2d.ui.CheckBox;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import java.util.ArrayList;

/**
 * Display the menu or render the 3D World
 * Control the mouse interactions
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class WorldRendererAndController extends InputAdapter implements ApplicationListener{

    private PerspectiveCamera camera;
    private BoardCameraController cameraController;
    private ModelBatch modelBatch;
    private AssetManager assets;
    private Environment environment;
    private boolean loading;

    public Stage worldStage;//peiexei ta 2D grafika mesa sto 3D perivalon
    public MenuStage menuStage;//periexei ta 2D grafika tou menu

    private Skin skin;

    private int visibleCount;

    private GraphicsGame graphicsGame;

    public boolean menuFlag;//emfanizei to menu(menuStage) i ta 3D grafika me to WorldStage
    
    private Settings gameSettings;
    private Player playerTrigedByNext; 
    
    //------WorldStage---2D graphics----------------        
    private TextButton undo;
    private TextButton bnReturnToMainMenu;
    private TextButton bnNext;
    private CheckBox cbContinuousPlay;
    private Label infoLabel;
    //------ClickListeners----------------------------
    private ClickListener undoListener;
    private ClickListener returnToMainMenuListener;
    private ClickListener continuousPlayListener;
    private ClickListener nextListener;
    
    public Thread backgroundThread;

    @Override
    public void create () {
        // Set Libgdx log level to DEBUG
	Gdx.app.setLogLevel(Application.LOG_DEBUG);

        //System.out.println((String)Gdx.files.internal("assets").);
        gameSettings = new Settings((String)Gdx.files.internal("").file().getAbsolutePath());
        //System.out.println("Target Path: "+Gdx.files.internal("").file().getAbsolutePath());
        skin = new Skin(Gdx.files.internal("uiskin.json"));
        menuFlag = true;
        menuStage = new MenuStage();
        createClickListeners();
        gameSettings = menuStage.initialize(gameSettings, skin);
        initializeWorldStage();
        Gdx.input.setInputProcessor(new InputMultiplexer(menuStage));
    }

    /**
     * render loop of the game
     * rendering rate is by default set to 60 fps
     * rendering rate is decreasing dynamic, depending on the device capabilities
     */
    @Override
    public void render () {

        Gdx.gl.glClearColor(.02734375f, .10546875f, .19921875f, 1);
        Gdx.gl.glViewport(0, 0, Gdx.graphics.getWidth() , Gdx.graphics.getHeight());
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);
        
        //Renderer will render the 3D world and the worldStage
        if(!menuFlag){
            cameraController.update();
            if(!Gdx.graphics.isContinuousRendering()) Gdx.graphics.setContinuousRendering(true);
            //trig the computer players
            if(graphicsGame.currentState.activePlayer instanceof ComputerPlayer && !graphicsGame.actingPawnIsMooving()){
                if(cbContinuousPlay.isChecked())graphicsGame.computerAct();//trig by continuous afterActionCheck
                else if(playerTrigedByNext!=null && graphicsGame.currentState.activePlayer.id == playerTrigedByNext.id)graphicsGame.computerAct();//trig by bnNext
                
            }
            //reset bnNext
            if(!graphicsGame.currentState.activePlayer.equals(playerTrigedByNext)) playerTrigedByNext = null;
            render3DWorld();
            worldStage.draw();
        }
        //Renderer  renders the menu once and stops (non continuous rendering)
        //every change in menu stage, will be rendered once
        else{
            try{
                menuStage.draw();
            } catch(Exception ex){
                System.err.println(ex.toString());
            }
            if(Gdx.graphics.isContinuousRendering())Gdx.graphics.setContinuousRendering(false);
        }
    }

    /**
     * Find if the Graphics Instance is inside the camera's field of view
     * @param cam the 3D environment camera
     * @param instance the graphics instance
     */
    private boolean isVisible (final Camera cam, final GraphicsInstance instance) {
        Vector3 position = new Vector3();
        instance.transform.getTranslation(position);
        position.add(instance.getCenter());
        return cam.frustum.sphereInFrustum(position, instance.getRadious());
    }

    /**
     * Find the clicked square of the board
     * @param screenX the horizontal dimension of screen clicked position 
     * @param screenY the vertical dimension of screen clicked position 
     * @return an integer matching with the clicked square 
     */
    private int getObject (int screenX, int screenY) {
        //System.out.println("getObject");
        Vector3 position = new Vector3();
        Ray ray = camera.getPickRay(screenX, screenY);
        int result = -1;
        float distance = -1;
        //apostasi tou ray mexti na ftasei sto epipedo 0
        final float len = -(ray.origin.y/ray.direction.y);
        if(len<=0) return(-1);
        Vector3 clicVec = new Vector3(ray.origin.x+ray.direction.x*len, ray.origin.y+ray.direction.y*len, ray.origin.z+ray.direction.z*len);

        for (int i = 0; i < graphicsGame.getFloor().size; ++i) {
            final GraphicsInstance instance = graphicsGame.getFloor().get(i);
            instance.transform.getTranslation(position);

            position.add(instance.getCenter());

            float dist2 = position.dst2(clicVec);
            if (distance >= 0f && dist2 > distance) continue;
            //if (dist2 <= 4f*instance.radius*instance.radius){
            if (dist2 <= 4f*instance.getRadious()){
                    result = i;
                    distance = dist2;
            }
        }
        return result;
    }
    
    /**
     * Create the clickListeners
     * for world stage:
     * - Undo
     * - Return to Main Menu
     * - Next (Trig computer players)
     * - Continuous Play
     * for menu stage:
     * - Start Game
     * - Select Game
     * - Display Game
     */
    private void createClickListeners(){
        //Undo button
        undoListener = new ClickListener(){
            @Override 
            public void clicked(InputEvent event, float x, float y){
                System.out.println("Undo Clicked");
                if(graphicsGame.currentState.undoCurrentTurnActions.isEmpty()) return;
                if(gameSettings.isLoggingOn()){
                    if(graphicsGame.currentState.undoCurrentTurnActions.get(0)[0]==0)
                        graphicsGame.logger.write("undo red");

                    else graphicsGame.logger.write("undo blue");
                    
                }
                graphicsGame.selectedUnit = null;
                graphicsGame.curentAction = null;
                if(graphicsGame.currentState.undoCurrentTurnActions.get(0)[0]!= graphicsGame.currentState.activePlayer.id)
                    graphicsGame.currentState.remainingTurns++;
                graphicsGame.currentState.undo();

                
                graphicsGame.deactivateFloor();
                graphicsGame.syncGraphics();
                
            };
        };
        
        //Return to main menu
        returnToMainMenuListener = new ClickListener(){
            @Override 
            public void clicked(InputEvent event, float x, float y){
                exitToMainMenu();
            };
        };
        
        //Trig Computer Player
        nextListener = new ClickListener(){
            @Override 
            public void clicked(InputEvent event, float x, float y){
                playerTrigedByNext = graphicsGame.currentState.activePlayer;
            };
        };
        
        //continuous play
        continuousPlayListener = new ClickListener(){
            @Override 
            public void clicked(InputEvent event, float x, float y){
                if(cbContinuousPlay.isChecked()){
                    bnNext.setTouchable(Touchable.disabled);
                }else{
                    bnNext.setTouchable(Touchable.enabled);
                }
            };
        };
//--------------------menuStage Listeners-----------------------------
        
        //New Game
        menuStage.newGameListener = new ClickListener(){
            @Override 
            public void clicked(InputEvent event, float x, float y){
                System.out.println(menuStage.bnStartGame.getText());
                if(menuStage.bnStartGame.getText().toString().equals("Start Game")){
                    gameSettings.setDrawLimit(menuStage.tfDrawLimit.getText());
                    gameSettings.setMinReward(menuStage.tfMinReward.getText());
                    gameSettings.setMaxReward(menuStage.tfMaxReward.getText());
                    if(gameSettings.redAI){
                        gameSettings.setRedEGreedy(menuStage.tfRedEGreedy.getText());
                        gameSettings.setRedLambda(menuStage.tfRedLambda.getText());
                        gameSettings.setRedGamma(menuStage.tfRedGamma.getText());
                        gameSettings.setRedEliminationReward(menuStage.cbRedEliminationReward.isChecked());
                        
                    }
                    if(gameSettings.blueAI){
                        gameSettings.setBlueEGreedy(menuStage.tfBlueEGreedy.getText());
                        gameSettings.setBlueLambda(menuStage.tfBlueLambda.getText());
                        gameSettings.setBlueGamma(menuStage.tfBlueGamma.getText());
                        gameSettings.setBlueEliminationReward(menuStage.cbBlueEliminationReward.isChecked());
                    }
                    
                    if(gameSettings.isGraphicsOn()){
                        initialize3DWorld();
                        worldStageDefaults();
                        menuFlag = false;
                    }else{

                        gameSettings.setNumberOfGames(menuStage.tfNumberOfGames.getText());
                        backgroundThread = new Thread(new BackgroundActor(gameSettings, menuStage, Thread.currentThread()));
                        backgroundThread.setPriority(Thread.MAX_PRIORITY);
                        backgroundThread.start();


                        //menuStage.bnStartGame.setTouchable(Touchable.disabled);
                        menuStage.bnStartGame.setColor(Color.SKY);
                        menuStage.bnStartGame.setText("Running");

                        menuStage.bnDisplayGame.setTouchable(Touchable.disabled);
                        menuStage.bnDisplayGame.setColor(Color.SKY);
                     
                    }
                        
                }
                else if(menuStage.bnStartGame.getText().toString().equals("Running")){
                    menuStage.bnStartGame.setText("Paused");
                    backgroundThread.suspend();
                    //Apothikeusi Neurwnikwn diktiwn
                    //Auto simvainei gia tin periptwsi pou theloume na stamatisoume
                    //ena gameSchedule prin tin oloklirwsi tou xwris na xasoume
                    //tin mexri tote ekpaideusi
                    gameSettings.saveNeuralNetworks();
                }
                else if(menuStage.bnStartGame.getText().toString().equals("Paused")){
                    menuStage.bnStartGame.setText("Running");
                    backgroundThread.resume();
                }
            };
        };
        menuStage.selectGameListener = new ClickListener(){
            //@Override 
            public void clicked(InputEvent event, float x, float y){
                menuStage.displayGameChooser.showOpenDialog(menuStage.displayGameChooser);
            };
        };
        menuStage.displayGameListener = new ClickListener(){
            //@Override 
            public void clicked(InputEvent event, float x, float y){
                System.out.println("Display Saved Game Selected");

                if(menuStage.displayGameChooser==null ||menuStage.displayGameChooser.getSelectedFile()==null) return;//den exei epilegei arxeio gia provoli
                String displayFile = menuStage.displayGameChooser.getSelectedFile().toString();
                if(displayFile !=null){
                    gameSettings.redPlayer = "CPU DisplayFromFile";
                    gameSettings.bluePlayer = "CPU DisplayFromFile";
                    gameSettings.setLoggingOn(false);
                    DisplayFromFile.loadFile(displayFile,gameSettings);

                    if(DisplayFromFile.isValid()){
                        initialize3DWorld();
                        worldStageDefaults();

                        menuFlag = false;
                    }
                    else{
                        gameSettings = menuStage.defaultValues(gameSettings);
                        System.err.println("File: "+displayFile+" can't be displayed");
                    }
                }else System.err.println("No File Selected");
            };
        };
    }

    /**
     * Initialize the 3d world
     */
    private void initialize3DWorld(){
        if(!gameSettings.settingsReady()) return;
        graphicsGame = new GraphicsGame(gameSettings);
        int size = GraphicsGame.getSize();
        graphicsGame.updateUndo = true;
        //updateStage3DFlag = true;
        cameraController = new BoardCameraController(camera,new Vector2(graphicsGame.Xmax,graphicsGame.Zmax));
        cameraController.setVelocity(10);
        camera.position.set(size*(float)(graphicsGame.Xmax-1)/2.0f, 0.75f*size*max(graphicsGame.Xmax,graphicsGame.Zmax), size*(graphicsGame.Zmax+1.5f));
        camera.up.set(0, 1, 0);
        camera.lookAt(size*(float)(graphicsGame.Xmax-1)/2.0f, 0, size*(float)(graphicsGame.Zmax-1)/2.0f);
        Gdx.input.setInputProcessor(new InputMultiplexer(worldStage, this, cameraController));
    }
    /**
     * Initialize the 3D world
     */
    private void initializeWorldStage(){
        worldStage = new Stage();
        int W = Gdx.graphics.getWidth();
        int H = Gdx.graphics.getHeight();

        infoLabel = new Label(" ",skin);
        infoLabel.setHeight(4*H/100);
        infoLabel.setPosition(12*W/100, H-5*H/100);
        worldStage.addActor(infoLabel);

        undo = new TextButton("Undo",skin, "default");
        undo.setWidth(10*W/100);
        undo.setHeight(4*H/100);
        undo.setPosition(1*W/100, H-5*H/100);
        undo.setColor(Color.RED);
        undo.addListener(undoListener);
        worldStage.addActor(undo);

        bnReturnToMainMenu = new TextButton("Exit Game",skin, "default");
        bnReturnToMainMenu.setWidth(10*W/100);
        bnReturnToMainMenu.setHeight(4*H/100);
        bnReturnToMainMenu.setPosition(W-11*W/100, H-5*H/100);
        bnReturnToMainMenu.setColor(Color.LIGHT_GRAY);
        bnReturnToMainMenu.addListener(returnToMainMenuListener);
        worldStage.addActor(bnReturnToMainMenu);

        bnNext = new TextButton("Next",skin, "default");
        bnNext.setWidth(10*W/100);
        bnNext.setHeight(4*H/100);
        bnNext.setPosition(1*W/100, H-10*H/100);
        bnNext.setColor(Color.LIGHT_GRAY);
        bnNext.addListener(nextListener);
        worldStage.addActor(bnNext);

        cbContinuousPlay = new CheckBox("Continuous Play",skin);
        cbContinuousPlay.setPosition(1*W/100, H-15*H/100);
        cbContinuousPlay.addListener(continuousPlayListener);
        worldStage.addActor(cbContinuousPlay);

        modelBatch = new ModelBatch();

        environment = new Environment();
        float lightPower = 0.1f;
        environment.set(new ColorAttribute(ColorAttribute.AmbientLight, 0.4f, 0.4f, 0.4f, 10f));
        environment.add(new DirectionalLight().set(lightPower, lightPower, lightPower, -0.3f, -1f, -0.3f));
        environment.add(new DirectionalLight().set(lightPower, lightPower, lightPower, 0.3f, -1f, 0.3f));
        environment.add(new DirectionalLight().set(lightPower, lightPower, lightPower, 0.3f, -1f, -0.3f));
        environment.add(new DirectionalLight().set(lightPower, lightPower, lightPower, -0.3f, -1f, 0.3f));

        assets = new AssetManager();
        assets.load(gameSettings.getSource()+"/RLModels.g3db", Model.class);
        loading = true;

        camera = new PerspectiveCamera(67, W, H);
        camera.near = 1f;
        camera.far = 300f;
        camera.update();
    }
    /**
     * Render the 3D world
     */
    private void render3DWorld(){
        if (loading && assets.update())loading = graphicsGame.loadModels(gameSettings.getSource()+"/RLModels.g3db", assets); //doneLoading();
        modelBatch.begin(camera);

        //ektelesi kinisewn sta pionia pou pithanwn kinoundai
        if(graphicsGame.isActiveActingPawnRotation()) graphicsGame.getActingPawnRotation().rotate(Gdx.graphics.getDeltaTime());
        if(graphicsGame.isActiveActingPawnTransposition()) graphicsGame.getActingPawnTransposition().move(Gdx.graphics.getDeltaTime());
        
        ArrayList<GraphicalTransposition> transpositionDaed = graphicsGame.getTranspositionDead();
        if(!transpositionDaed.isEmpty()){
            int i = 0;
            do{
                GraphicalTransposition t= transpositionDaed.get(i);
                if(t.isMoving()){
                    t.move(Gdx.graphics.getDeltaTime());
                    i++;
                }
                else transpositionDaed.remove(t);
            }while(i<transpositionDaed.size());
        }

        ArrayList<GraphicalRotation> rotationDaed = graphicsGame.getRotationDead();
        if(!rotationDaed.isEmpty()){
            int i = 0;
            do{
                GraphicalRotation r = rotationDaed.get(i);    
                if(r.isRotating()){
                    r.rotate(Gdx.graphics.getDeltaTime());
                    i++;
                }
                else rotationDaed.remove(r);
            } while(i<rotationDaed.size());
        }

        //emfanisi twn grafikwn pou vriskondai endws optikou paidiou tis cameras
        visibleCount = 0;
        for (final GraphicsInstance instance : graphicsGame.getFloor()) {
            if (isVisible(camera, instance)) {
                modelBatch.render(instance, environment);
                visibleCount++;
            }
        }
        for (final GraphicsInstance instance : graphicsGame.getInstases()) {
            if (isVisible(camera, instance)) {
                modelBatch.render(instance, environment);
                visibleCount++;
            }
        }
        for (final GraphicsInstance instance : graphicsGame.getPawns()) {
            if (isVisible(camera, instance)) {
                modelBatch.render(instance, environment);
                visibleCount++;
            }
        }
        modelBatch.end();

        //if(stage3DPlayer!=graphicsGame.activePlayer)updateStage3D();
        //if(updateStage3DFlag) updateStage3D();
        if(graphicsGame.updateUndo) updateWorldStage();

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.setLength(0);
        if(graphicsGame.currentState.gameOver){
            if(graphicsGame.currentState.winner==null) stringBuilder.append("Draw");
            else if(graphicsGame.currentState.winner.id == 0) stringBuilder.append("Red Player Won The Game");
            else stringBuilder.append("Blue Player Won The Game");
        }
        else{
            if(graphicsGame.currentState.activePlayer.id == 0) stringBuilder.append("Red Player's Turn");
            else stringBuilder.append("Blue Player's Turn");
        }
        stringBuilder.append(" - Remaining Turns: "+graphicsGame.currentState.remainingTurns);
        //stringBuilder.append("  (FPS: ").append(Gdx.graphics.getFramesPerSecond());
        //stringBuilder.append(" Visible: ").append(visibleCount).append(")");;
        infoLabel.setText(stringBuilder);
    }

    /**
     * Swap the color of undo button between red and blue
     * Enable or disable button Next
     * Enable or disable the Continuous Play check box 
     */
    private void updateWorldStage(){
        if(graphicsGame==null) return;
        //allagi xrwmatos sto undo
        int color;
        if(graphicsGame.currentState.undoCurrentTurnActions.isEmpty())
            color = graphicsGame.currentState.activePlayer.id;
        else color = graphicsGame.currentState.undoCurrentTurnActions.get(0)[0];
        if(color==0) undo.setColor(Color.RED);
        else undo.setColor(Color.BLUE);
        //enable/disable undu
        if(graphicsGame.currentState.activePlayer instanceof HumanPlayer){
            undo.setTouchable(Touchable.enabled);
            //trigComputerPlayer = false;
        }else{
            undo.setTouchable(Touchable.disabled);
        }

        graphicsGame.updateUndo = false;
    }	

    /**
     * Set the default conditions of World Stage Graphics 
     */
    private void worldStageDefaults(){
        cbContinuousPlay.setChecked(false);
        undo.setTouchable(Touchable.enabled);
        undo.setColor(Color.LIGHT_GRAY);
        bnNext.setTouchable(Touchable.disabled);

        if(graphicsGame.currentState.redPlayer instanceof HumanPlayer && graphicsGame.currentState.bluePlayer instanceof HumanPlayer)cbContinuousPlay.setTouchable(Touchable.disabled);
        else{
            cbContinuousPlay.setTouchable(Touchable.enabled);
            bnNext.setTouchable(Touchable.enabled);
        }
    }
    
    /**
     * Destroy the 3D world to return to main menu
     */
    private void exitToMainMenu(){
        //System.out.println("Exit to main menu");
        Gdx.input.setInputProcessor(new InputMultiplexer(menuStage));
        gameSettings = menuStage.defaultValues(gameSettings);
        menuFlag = true;
        loading = true;
    }
    
    /**
     * Mouse click touchUp method
     */
    @Override
    public boolean touchUp (int screenX, int screenY, int pointer, int button) {
        //System.out.println("touchUp");
        if(graphicsGame.currentState.gameOver)exitToMainMenu();
        //den epitepetai click otan kati kinitai
        if(graphicsGame.actingPawnIsMooving()) return false;
        //epistrefei to tetragvno tis skakieras pou exei ginei click
        int clickedSquare = getObject(screenX, screenY);

        if(clickedSquare!=-1)graphicsGame.humanOrder(clickedSquare, button);
        return true;
    }
    
    /**
     * Window resize method
     */
    @Override
    public void resize (int width, int height) {
        //System.out.println("Resizing Window");
        menuStage.getViewport().update(width, height, true);
        worldStage.getViewport().update(width, height, true);
        camera.viewportHeight = height;
        camera.viewportWidth = width;
    }
    
    /**
     * Window dispose method
     */
    @Override
    public void dispose () {
        modelBatch.dispose();
        assets.dispose();  
    }
    
    /**
     * Return the max between 2 integers
     */
    private int max(int x, int y) {
        if(x>y) return x;
        else return y;
    }
    
    /**
     * Disabling touch drag method by overriding
     */
    @Override
    public boolean touchDragged (int screenX, int screenY, int pointer) {
        //System.out.println("touchDrag disabled by overriding");
        return true;
    }

    /**
     * Disabling pause method by overriding
     */
    @Override
    public void pause () {
        //System.out.println("pause disabled by overriding");
    }
    
    /**
     * Disabling resume method by overriding
     */
    @Override
    public void resume () {
        //System.out.println("resume disabled by overriding");
    }	
    
    /**
     * Disabling touchDown method by overriding
     */
    @Override
    public boolean touchDown (int screenX, int screenY, int pointer, int button) {
        //System.out.println("touchDown disabled by overriding");
        return true;
    }
}
