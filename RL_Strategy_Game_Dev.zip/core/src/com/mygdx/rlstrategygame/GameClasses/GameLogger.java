/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygame.GameClasses;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Write data for game (or array of games) in log file
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class GameLogger {
    File file;
    
    public GameLogger(String loggingDirectory){
        //dimiourgia arxeiou eggrafis
        try {
            LocalDateTime dateTime = LocalDateTime.now();
            String name = dateTime.format(DateTimeFormatter.BASIC_ISO_DATE).toString()+'-'+dateTime.format(DateTimeFormatter.ISO_TIME).toString();
            name = name.replace(":","");
            //System.out.println("GameLoger file name :"+name);
            
            File temp = new File(loggingDirectory);
            if(!temp.exists())temp.mkdir();
            
            file = new File(loggingDirectory+"/"+name+".txt");
            if (!file.exists()) file.createNewFile();
        } catch (IOException e) {
            System.err.println("Failed to create GameLogger file: "+e);
        }
    }
    
    public void write(String string){
        try{
            FileWriter fw = new FileWriter(file,true);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.append(string+System.getProperty("line.separator"));
            bw.close();
        }catch(IOException e){
            System.err.println(e);
        }
    }
    
    public void write(String string1,String string2){
        this.write(string1+"-"+string2);
    }
}