/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygame.RL_Agents;

import java.util.*;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * This is a 3 level Neural Network, used by the RL Agent
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */

public class NeuralNet  {
    /**
     * The number of input Nodes of the NN
     */
    protected int nrOfInputNodes;
    /**
     * The number of hidden Nodes of the NN
     */
    protected int nrOfHiddenNodes;
    /**
     * The number of output Nodes of the NN
     */
    protected int nrOfOutputNodes;
    /**
     * First layer learning rate
     */
    private double  alpha;
    /**
     * Second layer learning rate
     */
    private double  beta;
    /**
     * Discount rate parameter
     */
    private double  gamma;
    /**
     * Trace decay parameter (should be <=gamma)
     */
    private double  lambda;
    /**
     * Bias that each neuron has (input node 0)
     */
    private double  bias = 0.5;
    /**
     * Array of input nodes (1st layer)
     */
    private double[] inputNode;
    /**
     * Array of hidden nodes (2nd layer)
     */
    private double[] hiddenNode;
    /**
     * Array of output nodes (3rd layer)
     */
    private double[] outputNode;
    /**
     * Array used for updating weights
     */
    private double[] oldOutputNode;
    /**
     * Error for each output node
     */
    private double[] error;
    /**
     * The reward received for each decision
     */
    private double[] reward;
    /**
     * Array of weights between layers 1->2
     */
    private double[][] w;
    /**
     * Array of weights between layers 2->3
     */
    private double[][] v;
    /**
     * Array of eligibility trace for weights v
     */
    private double[][][] ev;
    /**
     * Array of eligibility trace for weights w
     */
    private double[][] ew;
    /**
     * The NN file name that stores the Weights and traces
     */
    private File neuralNetFilename;

    /**
     * Constructor of the neural network used for clone
     */
    
    private NeuralNet(){
        
    }
    /**
     * Constructor of the neural network used by the agent
     * @param input the number of input nodes
     * @param hidden the number of hidden nodes
     * @param output the number of output nodes
     * @param gamma the discount rate parameter
     * @param lambda the decay rate parameter
     * @param neuralNetFilename  the file contains the ANN
     */

    protected NeuralNet(int input, int hidden, int output, double gamma, double lambda, File neuralNetFilename) {
        
        nrOfInputNodes = input;
        nrOfHiddenNodes = hidden;
        nrOfOutputNodes = output;
        this.gamma = gamma;
        this.lambda = lambda;
        alpha = 1.0 / nrOfInputNodes;
        beta = 0.5 / nrOfHiddenNodes;

        inputNode = new double[nrOfInputNodes + 1];
        hiddenNode = new double[nrOfHiddenNodes + 1];
        outputNode = new double[nrOfOutputNodes];
        oldOutputNode = new double[nrOfOutputNodes];
        error = new double[nrOfOutputNodes];
        v = new double[nrOfInputNodes + 1][nrOfHiddenNodes + 1];
        w = new double[nrOfHiddenNodes + 1][nrOfOutputNodes];
        ev = new double[nrOfInputNodes + 1][nrOfHiddenNodes + 1][nrOfOutputNodes];
        ew = new double[nrOfHiddenNodes + 1][nrOfOutputNodes];

        this.neuralNetFilename = neuralNetFilename;
        
         // initiate the net
        initialize();
    }
    
    /**
     * Return a copy of neural net
     */
    @Override
    public NeuralNet clone(){
       NeuralNet copy = new NeuralNet();
       
       copy.nrOfInputNodes = this.nrOfInputNodes;
       copy.nrOfHiddenNodes = this.nrOfHiddenNodes;
       copy.nrOfOutputNodes = this.nrOfOutputNodes;
       copy.gamma = this.gamma;
       copy.lambda = this.lambda;
       copy.alpha = this.alpha;
       copy.beta = this.beta;
       
       copy.inputNode = new double[nrOfInputNodes + 1];
       copy.hiddenNode = new double[nrOfHiddenNodes + 1];
       copy.outputNode = new double[nrOfOutputNodes];
       copy.oldOutputNode = new double[nrOfOutputNodes];
       copy.error = new double[nrOfOutputNodes];
        
       copy.inputNode[nrOfInputNodes] = bias;
       copy.hiddenNode[nrOfHiddenNodes] = bias;
        
       copy.v = this.v.clone();
       copy.w = this.w.clone();
       copy.ev = this.ev.clone();
       copy.ew = this.ew.clone();
        
       copy.neuralNetFilename = new File(this.neuralNetFilename.getAbsolutePath());
       return copy;
    }
    /**
     * Set the net nodes to zero or biases
     */
    public void cleanNodes(){
        Arrays.fill(inputNode, 0.0);
        Arrays.fill(hiddenNode, 0.0);
        inputNode[nrOfInputNodes] = bias;
        hiddenNode[nrOfHiddenNodes] = bias;
        Arrays.fill(outputNode,0.0);
        Arrays.fill(oldOutputNode,0.0);
        Arrays.fill(error, 0.0);
        ev = new double[nrOfInputNodes + 1][nrOfHiddenNodes + 1][nrOfOutputNodes];
        ew = new double[nrOfHiddenNodes + 1][nrOfOutputNodes];
        
    }
    /**
     * Initialize weights and biases
     */
    private void initialize() {
        
        if (!load()){
            System.out.println("Randomly initiating neural network.");
            initWeights(); // if there is an error loading the weights from disk, the network is initialized from zero
        }
            
        
        inputNode[nrOfInputNodes] = bias; // last input node is set to bias
        hiddenNode[nrOfHiddenNodes] = bias; // last hidden node is set to bias

    }

    /**
     * Initialize the weights array and eligibility traces of all layers of nodes
     */
    private void initWeights() {

        int j, k, i;
        
        //initialize weights
        java.util.Date helpDate = new Date(); // variable seed used for randomization
        System.out.println(helpDate.getTime()+" "+System.currentTimeMillis());
        Random initWeight = new Random(helpDate.getTime());
        
        //initiate the weights within [-0.5,0.5]
        for (j = 0; j <= nrOfHiddenNodes; j++) {
            for (k = 0; k < nrOfOutputNodes; k++) {
                w[j][k] = (initWeight.nextDouble() - 0.5d);
                //w[j][k] = 0;
            }
            for (i = 0; i <= nrOfInputNodes; i++) {
                v[i][j] = (initWeight.nextDouble() - 0.5d);
                //v[i][j] = 0;
            }
        }
        
        //initialize eligibility traces
        
        for (j = 0; j <= nrOfHiddenNodes; j++) {
                for (k = 0; k < nrOfOutputNodes; k++) {
                        ew[j][k] = 0.0;
                        oldOutputNode[k] = 0.0;
                }
                for (i = 0; i <= nrOfInputNodes; i++) {
                        for (k = 0; k < nrOfOutputNodes; k++) {
                                ev[i][j][k] = 0.0;
                        }
                }
        }
        
    }
        
    /**
    * A test method (not currently invoked by anything) to test that the file is saved/loaded correctly.
    */
    private void test(){
        System.out.println("Nr of Input Nodes"+nrOfInputNodes);
        System.out.println("Nr Of hidden Nodes"+nrOfHiddenNodes);
        System.out.println("Nr of Output Nodes"+nrOfOutputNodes);
        System.out.println("W array");
        for (int i=0;i<=nrOfHiddenNodes;i++)
            for (int j=0; j<nrOfOutputNodes;j++)
                System.out.print(". "+ w[i][j]);
        System.out.println();
        System.out.println("V array");
        for (int i=0;i<=nrOfInputNodes;i++)
            for (int j=0; j<=nrOfHiddenNodes;j++)
                System.out.print(". "+ v[i][j]);
        System.out.println("End of file");
    }

    /**
     * Store the weights of the Neural Network
     */
    public void store() {
        //System.out.println("Storing");
        //test();
        DataOutputStream out = null;
        try {
            out = new DataOutputStream(new FileOutputStream(neuralNetFilename));
            //out.writeObject(nrOfPawns);
            out.writeInt(nrOfInputNodes);
            out.writeInt(nrOfHiddenNodes);
            out.writeInt(nrOfOutputNodes);
            
            for (int i=0;i<=nrOfHiddenNodes;i++)
                for (int j=0; j<nrOfOutputNodes;j++)
                     out.writeDouble(w[i][j]);
            for (int i=0;i<=nrOfInputNodes;i++)
                for (int j=0; j<=nrOfHiddenNodes;j++)
                        out.writeDouble(v[i][j]);
            
        } catch (IOException ex) {
            Logger.getLogger(NeuralNet.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                out.close();
            } catch (IOException ex) {
                Logger.getLogger(NeuralNet.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    /**
     * Load the Neural Network node weights from a disk file
     */
    private boolean load() {
        //System.out.println("loading");
        try {
            int verifier;
            //System.out.println("neuralNetFilename: "+neuralNetFilename);
            DataInputStream in = new DataInputStream(new FileInputStream(neuralNetFilename));

            //verification process. check that the NN corresponds to the correct track (NN File name is not corrupted)
            verifier = in.readInt();
            if (verifier != nrOfInputNodes) return false;
            verifier = in.readInt();
            if (verifier != nrOfHiddenNodes) return false;
            verifier = in.readInt();
            if (verifier != nrOfOutputNodes) return false;
            
            //loading the weights
            for (int i=0;i<=nrOfHiddenNodes;i++)
                for (int j=0; j<nrOfOutputNodes;j++)
                    w[i][j] = in.readDouble();
            for (int i=0;i<=nrOfInputNodes;i++)
                for (int j=0; j<=nrOfHiddenNodes;j++)
                    v[i][j] = in.readDouble();
            in.close();  
            
            
        } catch (FileNotFoundException ex) {            
            //Logger.getLogger(NeuralNet.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Weight File not found! Initializing weights. Random values to be initialized.");
            return false;
        } catch (IOException ex) {
            //Logger.getLogger(NeuralNet.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Weight File is corrupted or contains incorrect Information. Random values to be initialized.");
            return false;
        } catch (Exception ex) {
            //Logger.getLogger(NeuralNet.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("General Error Loading Weights File. Random values to be initialized.");
            return false;
        }
        //test();
        return true;
        
    }
    
    /**
     * Calculate the response of the network, based on the current network input.
     * @return the result of the sigmoid value function of the output nodes as an array of doubles.
     */
    double[] response() {
        int i, j, k;
        hiddenNode[nrOfHiddenNodes] = bias;
        inputNode[nrOfInputNodes] = bias;
        for (j = 0; j < nrOfHiddenNodes; j++) {
            hiddenNode[j] = 0.0;
            for (i = 0; i <= nrOfInputNodes; i++) {
                hiddenNode[j] += inputNode[i] * v[i][j];
            }
            /*
             * Using sigmoid function to calculate the hidden nodes' value.
             * Asymmetric sigmoid
             */
            hiddenNode[j] = 1.0 / (1.0 + java.lang.Math.exp(-hiddenNode[j])); 
        }
        for (k = 0; k < nrOfOutputNodes; k++) {
            outputNode[k] = 0.0;
            for (j = 0; j <= nrOfHiddenNodes; j++) {
                outputNode[k] += hiddenNode[j] * w[j][k];
            }
            // using sigmoid function to calculate the output node's value
            outputNode[k] = 1.0 / (1.0 + java.lang.Math.exp(-outputNode[k]));
        }
        //System.out.println("Response "+outputNode[0]);
        return outputNode;
    }

    /**
     * Train the network by updating the weights of the nodes backwards, according to the error observed. Implement backpropagation and eligibility traces.
     */
    private void TDlearn() {
        int i, j, k;
        for (k = 0; k < nrOfOutputNodes; k++) {
            for (j = 0; j <= nrOfHiddenNodes; j++) {
                w[j][k] += beta * error[k] * ew[j][k]*0.1;
                for (i = 0; i <= nrOfInputNodes; i++){
                    v[i][j] += alpha * error[k] * ev[i][j][k]*0.5;
                }
            }
        }
    }
        
    /**
     * Update the array of eligibility traces.
     */
    protected void updateElig() {
        int i, j, k;
        double temp[] = new double[nrOfOutputNodes];

        for (k = 0; k < nrOfOutputNodes; k++) 
            temp[k] = outputNode[k] * (1 - outputNode[k]);

        for (j = 0; j <= nrOfHiddenNodes; j++) {
            for (k = 0; k < nrOfOutputNodes; k++) {
                ew[j][k] = lambda * ew[j][k] + temp[k] * hiddenNode[j];
                for (i = 0; i <= nrOfInputNodes; i++) {
                    ev[i][j][k] = lambda * ev[i][j][k] + temp[k] * w[j][k] * hiddenNode[j] * (1 - hiddenNode[j]) * inputNode[i];
                    //System.out.println("ev: "+ev[i][j][k]);
                }
                //System.out.println("ew: "+ew[j][k]);
            }
        }
    }

	
    /**
     * Calculate the response of the ANN and correct the weights (trains)
        with the reward passed.
     * @param reward the reward of the game state passed to the NN
     */
    protected void singleStep(double [] reward) {
        //System.out.println("Single Step");
        int k;

        response(); /* forward pass - compute activities */
        //System.out.println( "ANN response : "+outputNode[0]);

        this.reward = reward;

        for (k = 0; k < nrOfOutputNodes; k++) {
            error[k] = this.reward[k] + gamma * outputNode[k] - oldOutputNode[k]; /* form errors */
            //System.out.println("reward: "+this.reward[k] +"Error: "+error[k]);
        }

        TDlearn(); /* backward pass - learning */
        response(); /* forward pass must be done twice to form TD errors */
        //System.out.println("Response after backprop"+outputNode[0]);
        for (k = 0; k < nrOfOutputNodes; k++) {
            oldOutputNode[k] = outputNode[k]; /* for use in next cycle's TD errors */
        }

        updateElig(); /* update eligibility traces */

    }

    /**
     * Set the oldOutputNode to a certain value. Used during initialization of TD agents. Implement the t=0 part of Sutton's pseudo-code.
     * @param nodeValue 
     */
    void setOldOutputNode(double[] nodeValue) {
        if (nodeValue.length != oldOutputNode.length) {
            System.out.println("Error! Unable to set old output node. Different array sizes.");
        }
        for (int i=0; i<nodeValue.length ; i++)
            oldOutputNode[i]=nodeValue[i];      
    }
	
    /**
     * Set the designated Array as input to the ANN.
     * @param input The array/vector of inputs
     */
    void setInput(ArrayList<Double> input) {

        if (input.size()> nrOfInputNodes){
            System.out.println("Error in NN input!ArrayList of inputs greater than expected input size.");
            return;
        }
        //System.out.println("setInput input size "+inputNode.length);
        for (int i=0 ;i<input.size();i++){
            this.inputNode[i] = input.get(i);
        }

        this.inputNode[nrOfInputNodes] = bias;
    }

    /**
     * Clear the Eligibility Traces. To be used by RL algorithms that require clearing the eligibility trace.
     */
    void clearEligTrace() {
        for (int j = 0; j <= nrOfHiddenNodes; j++) {
            for (int k = 0; k < nrOfOutputNodes; k++) {
                ew[j][k] = 0.0;
            }
            for (int i = 0; i <= nrOfInputNodes; i++) {
                for (int k = 0; k < nrOfOutputNodes; k++) {
                    ev[i][j][k] = 0.0;
                }
            }
        }

    }
}
