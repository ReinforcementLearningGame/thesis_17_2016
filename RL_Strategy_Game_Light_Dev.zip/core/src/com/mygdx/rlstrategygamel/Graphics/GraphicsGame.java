/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygamel.Graphics;

import com.mygdx.rlstrategygamel.GameClasses.Settings;
import com.mygdx.rlstrategygamel.GameClasses.Game;
import com.mygdx.rlstrategygamel.GameClasses.Actions.GameAction;
import com.mygdx.rlstrategygamel.GameClasses.Actions.Transposition;
import com.mygdx.rlstrategygamel.GameClasses.Actions.Attack;
import com.mygdx.rlstrategygamel.GameClasses.Actions.Rotation;
import com.mygdx.rlstrategygamel.GameClasses.Players.ComputerPlayer;
import com.mygdx.rlstrategygamel.GameClasses.Players.HumanPlayer;
import com.mygdx.rlstrategygamel.GameClasses.Units.Spearman;
import com.mygdx.rlstrategygamel.GameClasses.Units.Knight;
import com.mygdx.rlstrategygamel.GameClasses.Units.Unit;
import com.mygdx.rlstrategygamel.GameClasses.Units.Infantry;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Array;
import java.util.ArrayList;


/**
 * Extends Game to a 3D environment
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class GraphicsGame extends Game{
    //Integer size must keep it's value to 10 in order to deal with
    //the model's size 
    protected static final int size = 10;
    
    protected GraphicalRotation actingPawnRotation;
    protected GraphicalTransposition actingPawnTransposition;
    protected ArrayList<GraphicalRotation> rotationDead;
    protected ArrayList<GraphicalTransposition> transpositionDead;        
    
    protected Array<GraphicsFloorInstance> floor;
    protected Array<GraphicsPawnInstance> pawn;
    protected Array<GraphicsInstance> instances;
    private Model model;
    
    public boolean updateUndo = false;
    

    /**
     * Constructor for a game in 3D environment
     * @param gameSettings the settings of the game
     */
    public GraphicsGame (Settings gameSettings)
    {
        super(gameSettings); 
        floor = new Array<GraphicsFloorInstance>();
        pawn = new Array<GraphicsPawnInstance>();
        instances = new Array<GraphicsInstance>();
        rotationDead = new ArrayList<GraphicalRotation>();
        transpositionDead = new ArrayList<GraphicalTransposition>();
    }
    
    /**
     * Loading the models  
     * @param fileName file contains the 3D models (model.g3db)
     * @param assets assets manager used to load the models
     * @return true if models load correctly
     */
    public boolean loadModels(String fileName,AssetManager assets)
    {
         model = assets.get(fileName, Model.class);//Model = ola ta modela
         for (int i = 0; i < model.nodes.size; i++){
            String id = model.nodes.get(i).id;
            if (id.equals("BlueKnight")){
                for(Unit unit:this.currentState.bluePlayer.units) if(unit instanceof Knight ){
                    GraphicsPawnInstance instance = new GraphicsPawnInstance(model, id, true, unit);
                    instance.transform.setToTranslation(size*unit.location.x, 0, size*unit.location.z).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 90*unit.direction);
                    pawn.add(instance);
                }
            }
            else if (id.equals("RedKnight")){
                for(Unit unit:this.currentState.redPlayer.units) if(unit instanceof Knight ){
                    GraphicsPawnInstance instance = new GraphicsPawnInstance(model, id, true, unit);
                    instance.transform.setToTranslation(size*unit.location.x, 0, size*unit.location.z).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 90*unit.direction);
                    pawn.add(instance);
                }
            }
            else if (id.equals("RedInfantry")){
                for(Unit unit:this.currentState.redPlayer.units) if(unit instanceof Infantry ){
                    GraphicsPawnInstance instance = new GraphicsPawnInstance(model, id, true, unit);
                    instance.transform.setToTranslation(size*unit.location.x, 0, size*unit.location.z).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 90*unit.direction);
                    pawn.add(instance);
                }
            }
            else if (id.equals("BlueInfantry")){
                for(Unit unit:this.currentState.bluePlayer.units) if(unit instanceof Infantry ){
                    GraphicsPawnInstance instance = new GraphicsPawnInstance(model, id, true, unit);
                    instance.transform.setToTranslation(size*unit.location.x, 0, size*unit.location.z).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 90*unit.direction);
                    pawn.add(instance);
                }
            }
            else if (id.equals("RedSpearman")){
                for(Unit unit:this.currentState.redPlayer.units) if(unit instanceof Spearman ){
                    GraphicsPawnInstance instance = new GraphicsPawnInstance(model, id, true, unit);
                    instance.transform.setToTranslation(size*unit.location.x, 0, size*unit.location.z).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 90*unit.direction);
                    pawn.add(instance);
                }
            }
            else if (id.equals("BlueSpearman")){
                for(Unit unit:this.currentState.bluePlayer.units) if(unit instanceof Spearman ){
                    GraphicsPawnInstance instance = new GraphicsPawnInstance(model, id, true, unit);
                    instance.transform.setToTranslation(size*unit.location.x, 0, size*unit.location.z).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 90*unit.direction);
                    pawn.add(instance);
                }
            }
            if (id.equals("Floor1")){
                for(int j = 0;j<Xmax;j++){
                    for(int k = 0;k<Zmax;k++){
                        if((j+k)%2==1 && this.currentState.locations[j][k].canGo){
                            GraphicsFloorInstance instance = new GraphicsFloorInstance(model, id, true, this.currentState.locations[j][k]);
                            instance.transform.setToTranslation(size*j,0,size*k).rotate(Vector3.Y, new Vector3(0,0,-1));
                            floor.add(instance);
                        }
                    }
                }
            }
            if (id.equals("Floor2")){
                for(int j = 0;j<Xmax;j++){
                    for(int k = 0;k<Zmax;k++){
                        if((j+k)%2==0 && this.currentState.locations[j][k].canGo){
                            GraphicsFloorInstance instance = new GraphicsFloorInstance(model, id, true, this.currentState.locations[j][k]);
                            instance.transform.setToTranslation(size*j,0,size*k).rotate(Vector3.Y, new Vector3(0,0,-1));
                            floor.add(instance);
                        }
                    }
                }
            }
            if (id.equals("FloorNoGo")){
                for(int j = 0;j<Xmax;j++){
                    for(int k = 0;k<Zmax;k++){
                        if(!this.currentState.locations[j][k].canGo){
                            GraphicsFloorInstance instance = new GraphicsFloorInstance(model, id, true, this.currentState.locations[j][k]);
                            instance.transform.setToTranslation(size*j,0,size*k).rotate(Vector3.Y, new Vector3(0,0,-1));
                            floor.add(instance);
                        }
                    }
                }
            }
            if (id.equals("NoGo")){
                for(int j = 0;j<Xmax;j++){
                    for(int k = 0;k<Zmax;k++){
                        if(!this.currentState.locations[j][k].canGo){
                            GraphicsInstance instance = new GraphicsInstance(model, id, true);
                            instance.transform.setToTranslation(size*j,0,size*k).rotate(Vector3.Y, new Vector3(0,0,-1));
                            instances.add(instance);
                        }
                    }
                }
            }
            if (id.equals("SideBorder")){
                for(int j = 0;j<Zmax;j++){
                        GraphicsInstance instance = new GraphicsInstance(model, id, true);
                        instance.transform.setToTranslation(-size*0.5f, 0, size*j).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 180);
                        
                        instances.add(instance);
                    }
                    for(int j = 0;j<Xmax;j++){
                        GraphicsInstance instance = new GraphicsInstance(model, id, true);
                        instance.transform.setToTranslation(size*j, 0, -size*0.5f).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 90);
                        instances.add(instance);
                    }   
                    for(int j = 0;j<Zmax;j++){
                        GraphicsInstance instance = new GraphicsInstance(model, id, true);
                        instance.transform.setToTranslation(size*(Xmax-0.5f), 0, size*j).rotate(Vector3.Y, new Vector3(0,0,-1));
                        instances.add(instance);
                    } 
                    for(int j = 0;j<Xmax;j++){
                        GraphicsInstance instance = new GraphicsInstance(model, id, true);
                        instance.transform.setToTranslation(size*j, 0, size*(Zmax-0.5f)).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, -90);
                        instances.add(instance);
                    }
            }
            if (id.equals("CornerBorder")){
                GraphicsInstance instance = new GraphicsInstance(model, id, true);
                instance.transform.setToTranslation(-size*0.5f, 0, -size*0.5f).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 90);
                instances.add(instance);


                instance = new GraphicsInstance(model, id, true);
                instance.transform.setToTranslation(-size*0.5f, 0, size*(Zmax-0.5f)).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 180);
                instances.add(instance);

                instance = new GraphicsInstance(model, id, true);
                instance.transform.setToTranslation(size*(Xmax-0.5f), 0, -size*0.5f).rotate(Vector3.Y, new Vector3(0,0,-1));
                instances.add(instance);

                instance = new GraphicsInstance(model, id, true);
                instance.transform.setToTranslation(size*(Xmax-0.5f), 0, size*(Zmax-0.5f)).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, -90);
                instances.add(instance);
            }
            if (id.equals("Mast")){
                GraphicsInstance instance = new GraphicsInstance(model, id, true);
                instance.transform.setToTranslation(size*(Xmax-0.5f), 0, -size*0.5f).rotate(Vector3.Y, new Vector3(0,0,-1));
                instances.add(instance);

                instance = new GraphicsInstance(model, id, true);
                instance.transform.setToTranslation(-size*0.5f, 0, size*(Zmax-0.5f)).rotate(Vector3.Y, new Vector3(0,0,-1));
                instances.add(instance);

            }
            if (id.equals("RedFlag")){
                GraphicsInstance instance = new GraphicsInstance(model, id, true);
                instance.transform.setToTranslation(size*(Xmax-0.5f), 2*size, -size*0.5f).rotate(Vector3.Y, new Vector3(0,0,-1));
                instances.add(instance);
            }
            if (id.equals("BlueFlag")){
                GraphicsInstance instance = new GraphicsInstance(model, id, true);
                instance.transform.setToTranslation(-size*0.5f, 2*size, size*(Zmax-0.5f)).rotate(Vector3.Y, new Vector3(0,0,-1));
                instances.add(instance);
            }

            if (id.equals("Fence")){
                for(int j = 0;j<Xmax;j++){
                    for(int k = 0;k<Zmax;k++){
                        if(!this.currentState.locations[j][k].canGo){
                            if(this.currentState.locations[j][k].north!=null && this.currentState.locations[j][k].north.canGo){
                                GraphicsInstance instance = new GraphicsInstance(model, id, true);
                                instance.transform.setToTranslation(size*j, 0, size*(k-0.5f)).rotate(Vector3.Y, new Vector3(0,0,-1));
                                instances.add(instance);
                            }

                            if(this.currentState.locations[j][k].west!=null && this.currentState.locations[j][k].west.canGo){
                                GraphicsInstance instance = new GraphicsInstance(model, id, true);
                                instance.transform.setToTranslation(size*(j-0.5f), 0, size*k).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 90);
                                instances.add(instance);
                            }

                            if(this.currentState.locations[j][k].south!=null && this.currentState.locations[j][k].south.canGo){
                                GraphicsInstance instance = new GraphicsInstance(model, id, true);
                                instance.transform.setToTranslation(size*j, 0, size*(k+0.5f)).rotate(Vector3.Y, new Vector3(0,0,-1));
                                instances.add(instance);
                            }

                            if(this.currentState.locations[j][k].east!=null && this.currentState.locations[j][k].east.canGo){
                                GraphicsInstance instance = new GraphicsInstance(model, id, true);
                                instance.transform.setToTranslation(size*(j+0.5f), 0, size*k).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 90);
                                instances.add(instance);
                            }
                        }
                    }
                }
            }
        }
        return false;
    }
    
    /**
     * Make the 3D environment similar to the game state condition.
     * This method is used after undo button press.
     */
    public void syncGraphics(){
        if(pawn.size==0) return;
        //afairesi olwn twn grafikvn pou aforoun pionia
        pawn.removeRange(0, pawn.size-1);
        //ta fagwmena pionia den tha boun stis theseis pou itan kathws den exoun apothikeutei sto gameState
        this.currentState.redPlayer.deadPoint = new Vector2(-1,-1);
        this.currentState.bluePlayer.deadPoint = new Vector2(this.Xmax,this.Zmax);
        
        for (int i = 0; i < model.nodes.size; i++){
            String id = model.nodes.get(i).id;
            if (id.equals("BlueKnight")){
                for(Unit unit:this.currentState.bluePlayer.units) if(unit instanceof Knight ){
                    GraphicsPawnInstance instance = new GraphicsPawnInstance(model, id, true, unit);
                    if(unit.alive)instance.transform.setToTranslation(size*unit.location.x, 0, size*unit.location.z).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 90*unit.direction);
                    else{
                        instance.transform.setToTranslation(size*(float)unit.player.deadPoint.x, 0, size*(float)unit.player.deadPoint.y).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 90*unit.player.deadDirection);
                        unit.player.deadPoint = unit.player.deadPoint.add(unit.player.deadVector);
                    }
                    pawn.add(instance);
                }
            }
            else if (id.equals("RedKnight")){
                for(Unit unit:this.currentState.redPlayer.units) if(unit instanceof Knight ){
                    GraphicsPawnInstance instance = new GraphicsPawnInstance(model, id, true, unit);
                    if(unit.alive)instance.transform.setToTranslation(size*unit.location.x, 0, size*unit.location.z).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 90*unit.direction);
                    else{
                        instance.transform.setToTranslation(size*(float)unit.player.deadPoint.x, 0, size*(float)unit.player.deadPoint.y).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 90*unit.player.deadDirection);
                        unit.player.deadPoint = unit.player.deadPoint.add(unit.player.deadVector);
                    }
                    pawn.add(instance);
                }
            }
            else if (id.equals("RedInfantry")){
                for(Unit unit:this.currentState.redPlayer.units) if(unit instanceof Infantry ){
                    GraphicsPawnInstance instance = new GraphicsPawnInstance(model, id, true, unit);
                    if(unit.alive)instance.transform.setToTranslation(size*unit.location.x, 0, size*unit.location.z).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 90*unit.direction);
                    else{
                        instance.transform.setToTranslation(size*(float)unit.player.deadPoint.x, 0, size*(float)unit.player.deadPoint.y).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 90*unit.player.deadDirection);
                        unit.player.deadPoint = unit.player.deadPoint.add(unit.player.deadVector);
                    }
                    pawn.add(instance);
                }
            }
            else if (id.equals("BlueInfantry")){
                for(Unit unit:this.currentState.bluePlayer.units) if(unit instanceof Infantry ){
                    GraphicsPawnInstance instance = new GraphicsPawnInstance(model, id, true, unit);
                    if(unit.alive)instance.transform.setToTranslation(size*unit.location.x, 0, size*unit.location.z).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 90*unit.direction);
                    else{
                        instance.transform.setToTranslation(size*(float)unit.player.deadPoint.x, 0, size*(float)unit.player.deadPoint.y).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 90*unit.player.deadDirection);
                        unit.player.deadPoint = unit.player.deadPoint.add(unit.player.deadVector);
                    }
                    pawn.add(instance);
                }
            }
            else if (id.equals("RedSpearman")){
                for(Unit unit:this.currentState.redPlayer.units) if(unit instanceof Spearman ){
                    GraphicsPawnInstance instance = new GraphicsPawnInstance(model, id, true, unit);
                    if(unit.alive)instance.transform.setToTranslation(size*unit.location.x, 0, size*unit.location.z).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 90*unit.direction);
                    else{
                        instance.transform.setToTranslation(size*(float)unit.player.deadPoint.x, 0, size*(float)unit.player.deadPoint.y).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 90*unit.player.deadDirection);
                        unit.player.deadPoint = unit.player.deadPoint.add(unit.player.deadVector);
                    }
                    pawn.add(instance);
                }
            }
            else if (id.equals("BlueSpearman")){
                for(Unit unit:this.currentState.bluePlayer.units) if(unit instanceof Spearman ){
                    GraphicsPawnInstance instance = new GraphicsPawnInstance(model, id, true, unit);
                    if(unit.alive)instance.transform.setToTranslation(size*unit.location.x, 0, size*unit.location.z).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 90*unit.direction);
                    else{
                        instance.transform.setToTranslation(size*(float)unit.player.deadPoint.x, 0, size*(float)unit.player.deadPoint.y).rotate(Vector3.Y, new Vector3(0,0,-1)).rotate(Vector3.Z, 90*unit.player.deadDirection);
                        unit.player.deadPoint = unit.player.deadPoint.add(unit.player.deadVector);
                    }
                    pawn.add(instance);
                }
            }
        }
        for(GraphicsFloorInstance temp:this.floor){
            int x = temp.location.x;
            int z = temp.location.z;
            temp.location = this.currentState.locations[x][z];
        }
    }

    /**
     * Transform the mouse click to game action for human players
     * and perform the action.
     * @param selected the clicked square of the board
     * @param click the type of click (0 --> left, 1 --> right)
     */
    public void humanOrder (int selected,int click){
        if(!(this.currentState.activePlayer instanceof HumanPlayer)) return;
        //System.out.println("humanOrder - "+selected+"-"+this.currentState.activePlayer.id+"-"+this.currentState.remainingMoves);
        if(selected==-1)return;//klick ektos tablo den kanei tipota
        GraphicsFloorInstance floorInstance = floor.get(selected);
        GraphicsPawnInstance unitInstance = null;
        for(GraphicsPawnInstance tempUnitInstance : pawn)
            if(tempUnitInstance.unit == floorInstance.location.unit){
                unitInstance = tempUnitInstance;
                break;
            }
        
        //select order
        if(click==0 && unitInstance!=null && unitInstance.unit.player.id == this.currentState.activePlayer.id){
            if(this.currentState.remainingMoves==1)return;//apagoteuetai i allagi pioniou otan alogo exei kanei mia energeia
            //System.out.println(" Selection Order ");
            if(select(floorInstance)){
            //    System.out.println(" Select "+unitInstance);
            }
            else return;
        }
        else {
            //Transposition order
            if(click==0 && unitInstance==null && this.selectedUnit!=null && floorInstance.isActivated() && floorInstance.location.canGo){
                //System.out.println(" Transposition "+selectedUnit);
                if(floorInstance.location == selectedUnit.location.next(0)) this.curentAction = new Transposition(selectedUnit,0);
                else if(floorInstance.location == selectedUnit.location.next(1)) this.curentAction = new Transposition(selectedUnit,1);
                else if(floorInstance.location == selectedUnit.location.next(2)) this.curentAction = new Transposition(selectedUnit,2);
                else if(floorInstance.location == selectedUnit.location.next(3)) this.curentAction = new Transposition(selectedUnit,3);
                else{ System.out.println("NO"); return;}
            }
            //Rotation order
            else if(click==1 && this.selectedUnit!=null && floorInstance.isActivated()){
                //System.out.println(" Rotation ");
                if(floorInstance.location == selectedUnit.location.next(0)) this.curentAction = new Rotation(selectedUnit,0);
                else if(floorInstance.location == selectedUnit.location.next(1)) this.curentAction = new Rotation(selectedUnit,1);
                else if(floorInstance.location == selectedUnit.location.next(2)) this.curentAction = new Rotation(selectedUnit,2);
                else if(floorInstance.location == selectedUnit.location.next(3)) this.curentAction = new Rotation(selectedUnit,3);
                else return;
            }
            //Attack order
            else if(click==0 && unitInstance!=null && unitInstance.unit.player != this.currentState.activePlayer && floorInstance.isAttackActivated()){
                //System.out.println(" Attack ");
                if(floorInstance.location == selectedUnit.location.next(0)) this.curentAction = new Attack(selectedUnit,0);
                else if(floorInstance.location == selectedUnit.location.next(1)) this.curentAction = new Attack(selectedUnit,1);
                else if(floorInstance.location == selectedUnit.location.next(2)) this.curentAction = new Attack(selectedUnit,2);
                else if(floorInstance.location == selectedUnit.location.next(3)) this.curentAction = new Attack(selectedUnit,3);
                else if(floorInstance.location == selectedUnit.location.next(4)) this.curentAction = new Attack(selectedUnit,4);
                else if(floorInstance.location == selectedUnit.location.next(5)) this.curentAction = new Attack(selectedUnit,5);
                else if(floorInstance.location == selectedUnit.location.next(6)) this.curentAction = new Attack(selectedUnit,6);
                else if(floorInstance.location == selectedUnit.location.next(7)) this.curentAction = new Attack(selectedUnit,7);
                else return;

            }
            if(!this.perform(this.curentAction))return;
            this.curentAction = null;
            if(this.currentState.remainingMoves==1) this.activateAround(floorInstance); // an i prwti energeia itan apo alogo
        }
    }
    
    /**
     * Perform the computer actions in 3D environment
     */
    public void computerAct(){
        if(this.currentState.activePlayer instanceof ComputerPlayer){
            ComputerPlayer computerPlayer = (ComputerPlayer)this.currentState.activePlayer;
            
            if(computerPlayer.isReady()){
                this.curentAction = computerPlayer.getAction();
                selectUnit(this.curentAction);
                if(this.curentAction!=null) this.perform(this.curentAction);
            }
            else{
                this.updateUndo = true;
                super.computerAct();
            }
        } else return;
    }
    

    /**
     * Activate the boardLocations around the selected pawn, according to the 
     * rules, in order to convert next click to action
     * @param instance the board square, the selected pawn is located to
     */
    public void activateAround(GraphicsFloorInstance instance){
        for(GraphicsFloorInstance tempInstance : floor){
            if(tempInstance.location==null) continue;
            //North
            if(tempInstance.location == instance.location.north){

                if(tempInstance.location.captured && tempInstance.location.unit.canBeAttackedBy(selectedUnit)){
                    tempInstance.attackActivate();
                }
                else tempInstance.activate();
            }
            //East
            if(tempInstance.location == instance.location.east){

                if(tempInstance.location.captured && tempInstance.location.unit.canBeAttackedBy(selectedUnit)){
                    tempInstance.attackActivate();
                }
                else tempInstance.activate();
            }
            //South
            if(tempInstance.location == instance.location.south){

                if(tempInstance.location.captured && tempInstance.location.unit.canBeAttackedBy(selectedUnit)){
                    tempInstance.attackActivate();
                }
                else tempInstance.activate();
            }
            //West
            if(tempInstance.location == instance.location.west){

                if(tempInstance.location.captured && tempInstance.location.unit.canBeAttackedBy(selectedUnit)){
                    tempInstance.attackActivate();
                }
                else tempInstance.activate();
            }
            //NorthEast (Spearman Attack)
            if(tempInstance.location == instance.location.next(7)){
                if(tempInstance.location.captured && tempInstance.location.unit.canBeAttackedBy(selectedUnit))tempInstance.attackActivate();
            }
            //NorthWest (Spearman Attack)
            if(tempInstance.location == instance.location.next(4)){
                if(tempInstance.location.captured && tempInstance.location.unit.canBeAttackedBy(selectedUnit))tempInstance.attackActivate();
            }
            //SouthEast (Spearman Attack)
            if(tempInstance.location == instance.location.next(6)){
                if(tempInstance.location.captured && tempInstance.location.unit.canBeAttackedBy(selectedUnit))tempInstance.attackActivate();
            }
            //SouthWest (Spearman Attack)
            if(tempInstance.location == instance.location.next(5)){
                if(tempInstance.location.captured && tempInstance.location.unit.canBeAttackedBy(selectedUnit))tempInstance.attackActivate();
            }
        }
    }
    
    /**
     * Select the pawn on the clicked board square
     * @param instance the clicked board square
     * @return true if selection deals with the rules
     */
    public boolean select(GraphicsFloorInstance instance){
        //System.out.println("Select ok");
        if(this.currentState.remainingMoves==1) return false;//to alogo exei idi kanei mia kinisi den boroume na epileksoume allo
        //this.saveState();//apothikeuei to paixnidi sto previousState stausGame gia periptvsi undo
        //this.previousState = this.currentState.clone();
        this.currentState.undoCurrentTurnActions.clear();
        //Render3D.updateStage3DFlag = true;// xrisimopoieitai gia tin allagi xrwmmatos sto koubi undo
        this.updateUndo = true;
        
        
        if(instance.location.unit==selectedUnit) return true; //epilogi tou pioniou pou ian idi epilegmeno
        else if(selectedUnit!=null){//exoume idi ena epilegmeno pioni, to apoepilegoume kai epilegoume kapoio allo
            //decelect
            this.deactivateFloor();
            selectedUnit = null;
        }
        //selectUnit: vazei to unit pou vrisketai sto location sto selectedUnit
        selectUnit(instance.location);//an iparxei pioni sto sigekrimeno tetragwno
        activateAround(instance);//energopoihsh guro tetragwnwn
        
        return true;
    }

    /**
     * Perform the graphical part of an action
     * @param action the action is going to be performed
     */
    public boolean perform(GameAction action){
        //System.out.println("Graphics perform");
        if(action==null || !action.isValidAction(this.currentState)) return false;//elegxos an i kinisi borei na ektelesei apo auto to game
        if(action instanceof Transposition) this.perform((Transposition) action);
        else if(action instanceof Rotation) this.perform((Rotation) action);
        else if (action instanceof Attack)this.perform((Attack) action);
        else return false;
        
        if(!this.currentState.perform(action)) return false;//ektelesi tis kinisis se epipedo logikis paixnidiou
        endOfTurnCheck();
        //if(!super.perform(action))return false;
        
        this.deactivateFloor();
        return true;
    }

    /**
     * Perform the graphical part of a Transposition
     * @param transposition the Transposition is going to be performed
     */
    private void perform(Transposition transposition){
        for(GraphicsPawnInstance tempUnitInstance : pawn){//evresi grafikwn pioniou pou tha kanei tin metatopisi
            if(!tempUnitInstance.unit.alive) continue;
            //System.out.println(transposition.getX() +"-"+transposition.getZ()+","+tempUnitInstance.unit.location.x+"-"+tempUnitInstance.unit.location.z);
            if(tempUnitInstance.unit.location.x==transposition.getX()&&tempUnitInstance.unit.location.z==transposition.getZ()){
                actingPawnRotation = new GraphicalRotation(transposition.direction * 90,tempUnitInstance);
                actingPawnTransposition = new GraphicalTransposition(tempUnitInstance, tempUnitInstance.unit.location.next(transposition.direction));
                return;
            }
        }
        System.err.println("GraphicsGame.Perform.Transposition error");
    }
    
    /**
     * Perform the graphical part of a Rotation
     * @param rotation the Rotation is going to be performed
     */
    private void perform(Rotation rotation){
        for(GraphicsPawnInstance tempUnitInstance : pawn){//evresi grafikwn pioniou pou tha kanei tin peristrofi
            if(!tempUnitInstance.unit.alive) continue;
            if(tempUnitInstance.unit.location.x==rotation.getX()&&tempUnitInstance.unit.location.z==rotation.getZ()){
                actingPawnRotation = new GraphicalRotation(rotation.direction * 90,tempUnitInstance);
                return;
            }
            
        }
        System.err.println("GraphicsGame.Perform.Rotation error");
    }
    
    /**
     * Perform the graphical part of an Attack
     * @param attack the Attack is going to be performed
     */
    private void perform(Attack attack){
        for(GraphicsPawnInstance attackUnitInstance : pawn){//evresi grafikwn pioniou pou tha kanei tin epithesi
            if(!attackUnitInstance.unit.alive) continue;
            if(attackUnitInstance.unit.location.x==attack.getX()&&attackUnitInstance.unit.location.z==attack.getZ()){
                int tempdirection = attack.direction;
                if(tempdirection==4||tempdirection==5)tempdirection=1;
                else if(tempdirection==6||tempdirection==7)tempdirection=3;
                
                for(GraphicsPawnInstance defenceUnitInstance : pawn){//evresi grafikwn pioniou pou tha kanei tin epithesi
                    if(!defenceUnitInstance.unit.alive) continue;
                    if(defenceUnitInstance.unit.location.equals(attackUnitInstance.unit.location.next(attack.direction))){
                        GraphicalRotation rotation2 = new GraphicalRotation(90*defenceUnitInstance.unit.player.deadDirection,defenceUnitInstance);
                        Vector2 defenceUnitDeadPoint = new Vector2((float)defenceUnitInstance.unit.player.deadPoint.x,(float)defenceUnitInstance.unit.player.deadPoint.y);
                        GraphicalTransposition transposition2 = new GraphicalTransposition(defenceUnitInstance, defenceUnitDeadPoint);
                        this.rotationDead.add(rotation2);
                        this.transpositionDead.add(transposition2);
                    }
                }
                
                actingPawnRotation = new GraphicalRotation(tempdirection * 90,attackUnitInstance);
                actingPawnTransposition = new GraphicalTransposition(attackUnitInstance, attackUnitInstance.unit.location.next(attack.direction));
                return;
            }
        }
        System.err.println("GraphicsGame.Perform.Rotation error");
    }
    
    /**
     * @return true if the acting pawn is still rotating 
     */
    public boolean isActiveActingPawnRotation(){
        if(actingPawnRotation==null || !actingPawnRotation.isRotating()) return false;
        return true;
    }
    /**
     * @return true if the acting pawn is still moving 
     */
    public boolean isActiveActingPawnTransposition(){
        if(actingPawnTransposition==null || !actingPawnTransposition.isMoving()) return false;
        return true;
    }
    
    /**
     * @return true if the acting pawn is still performing an action 
     */
    public boolean actingPawnIsMooving(){
        if(isActiveActingPawnRotation()||isActiveActingPawnTransposition()) return true;
        return false;
    }
    
    /**
     * return all board squares to their normal color
     */
    public void deactivateFloor(){
        for(GraphicsFloorInstance tempInstance : floor) if(tempInstance.isActivated())tempInstance.deactivate();
    }
    
    /**
     * @return the value static integer size
     */
    public static int getSize(){
        return size;
    }
    
    /**
     * @return the acting pawn's graphical rotation 
     */
    public GraphicalRotation getActingPawnRotation(){
        return this.actingPawnRotation;
    }
    
    /**
     * @return the acting pawn's graphical transposition 
     */
    public GraphicalTransposition getActingPawnTransposition(){
        return this.actingPawnTransposition;
    }
    
    /**
     * @return the transposition of eliminated pawns 
     */
    public ArrayList<GraphicalTransposition> getTranspositionDead(){
        return this.transpositionDead;
    }
    
    /**
     * @return the rotation of eliminated pawns 
     */
    public ArrayList<GraphicalRotation> getRotationDead(){
        return this.rotationDead;
    }
    
    /**
     * @return model instances of board squares
     */
    public Array<GraphicsFloorInstance> getFloor(){
        return this.floor;
    }
    
    /**
     * @return model instances of pawn
     */
    public Array<GraphicsPawnInstance> getPawns(){
        return this.pawn;
    }
    
    /**
     * @return all model instances
     */
    public Array<GraphicsInstance> getInstases(){
        return this.instances;
    }
}