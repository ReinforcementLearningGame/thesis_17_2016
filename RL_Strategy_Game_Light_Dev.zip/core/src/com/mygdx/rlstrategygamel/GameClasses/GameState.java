/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygamel.GameClasses;

import com.mygdx.rlstrategygamel.GameClasses.Actions.GameAction;
import com.mygdx.rlstrategygamel.GameClasses.Actions.Rotation;
import com.mygdx.rlstrategygamel.GameClasses.Actions.Transposition;
import com.mygdx.rlstrategygamel.GameClasses.Actions.Attack;
import com.mygdx.rlstrategygamel.GameClasses.Players.Player;
import com.mygdx.rlstrategygamel.GameClasses.Players.ComputerPlayer;
import com.mygdx.rlstrategygamel.GameClasses.Players.HumanPlayer;
import com.mygdx.rlstrategygamel.GameClasses.Units.Knight;
import com.mygdx.rlstrategygamel.GameClasses.Units.Spearman;
import com.mygdx.rlstrategygamel.GameClasses.Units.Infantry;
import com.mygdx.rlstrategygamel.GameClasses.Units.Unit;
import java.util.ArrayList;
import java.util.Random;
import com.badlogic.gdx.math.Vector2;

/**
 * Specific state of the game 
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class GameState {
    public Game game;
    public boolean complete;
   
    public Player redPlayer; //id == 0
    public Player bluePlayer;//id == 1
    public Player activePlayer;
    
    public BoardLocation locations[][];
    
    public int remainingMoves;
    public int remainingTurns;
    
    public boolean gameOver;
    public Player winner;
    
    public ArrayList<int[]> undoCurrentTurnActions = new ArrayList<int[]>();
    /**
     * Constructor for GameState
     * @param game
     */
    public GameState(Game game){
        this.game = game;
        this.complete = false;
    }                        
    /**
     * Clone the GameState
     * @return copy of the GameState
     */
    public GameState clone(){
        //System.out.println("Clone");
        if(!this.complete) return null;
        GameState copy = new GameState(this.game);

        copy.remainingMoves = this.remainingMoves;
        copy.remainingTurns = this.remainingTurns;
        copy.gameOver = this.gameOver;
        copy.winner = this.winner;
        copy.undoCurrentTurnActions = new ArrayList<int[]>();
        
        copy.locations = new BoardLocation[game.Xmax][game.Zmax];
        for(int i = 0;i<game.Xmax;i++)
            for(int j =0;j<game.Zmax;j++)
                copy.locations[i][j] = new BoardLocation(this.locations[i][j]);
        //initialize Around Locations
        for(int j=0;j<game.Zmax;j++){
            for(int i=0;i<game.Xmax;i++){
                if(j-1>=0) copy.locations[i][j].north = copy.locations[i][j-1];
                else copy.locations[i][j].north = null;
                if(j+1<game.Zmax) copy.locations[i][j].south = copy.locations[i][j+1];
                else copy.locations[i][j].south = null;
                if(i-1>=0) copy.locations[i][j].west = copy.locations[i-1][j];
                else copy.locations[i][j].west = null;
                if(i+1<game.Xmax) copy.locations[i][j].east = copy.locations[i+1][j];
                else copy.locations[i][j].east = null;
            }
        }
        
        if(this.redPlayer instanceof HumanPlayer) copy.redPlayer = new HumanPlayer(0,copy.locations[game.Xmax-1][0], new Vector2(game.Xmax,game.Zmax));
        else copy.redPlayer = new ComputerPlayer((ComputerPlayer)this.redPlayer,copy.locations[game.Xmax-1][0], new Vector2(game.Xmax,game.Zmax));
        if(this.bluePlayer instanceof HumanPlayer) copy.bluePlayer = new HumanPlayer(1,this.locations[0][game.Zmax-1], new Vector2(game.Xmax,game.Zmax));
        else copy.bluePlayer = new ComputerPlayer((ComputerPlayer)this.bluePlayer,this.locations[0][game.Zmax-1], new Vector2(game.Xmax,game.Zmax));
        
        if(this.activePlayer.id==0) copy.activePlayer = copy.redPlayer;
        else copy.activePlayer = copy.bluePlayer;
        
        copy.redPlayer.units = new Unit[this.redPlayer.units.length];
        for(int i = 0;i<this.redPlayer.units.length;i++){
            BoardLocation tempLocation = null;
            boolean alive = false;
            if(this.redPlayer.units[i].alive){
                int x = this.redPlayer.units[i].location.x;
                int z = this.redPlayer.units[i].location.z;
                tempLocation = copy.locations[x][z];
                alive = true;
            }
            if(this.redPlayer.units[i] instanceof Infantry)
                copy.redPlayer.units[i] = new Infantry(tempLocation,this.redPlayer.units[i].direction,copy.redPlayer,alive,i);
            else if(this.redPlayer.units[i] instanceof Spearman)
                copy.redPlayer.units[i] = new Spearman(tempLocation,this.redPlayer.units[i].direction,copy.redPlayer,alive,i);
            else if(this.redPlayer.units[i] instanceof Knight){
                copy.redPlayer.units[i] = new Knight(tempLocation,this.redPlayer.units[i].direction,copy.redPlayer,alive,i);
                Knight originalKnight = (Knight)this.redPlayer.units[i];
                if(originalKnight.alive && originalKnight.startingLocation!=null){
                    Knight copyKnight = (Knight)copy.redPlayer.units[i];
                    copyKnight.startingLocation = copy.locations[originalKnight.location.x][originalKnight.location.z];
                }
            }
        }
        
        copy.bluePlayer.units = new Unit[this.bluePlayer.units.length];
        for(int i = 0;i<this.bluePlayer.units.length;i++){
            BoardLocation tempLocation = null;
            boolean alive = false;
            if(this.bluePlayer.units[i].alive){
                int x = this.bluePlayer.units[i].location.x;
                int z = this.bluePlayer.units[i].location.z;
                tempLocation = copy.locations[x][z];
                alive = true;
            }
            if(this.bluePlayer.units[i] instanceof Infantry)
                copy.bluePlayer.units[i] = new Infantry(tempLocation,this.bluePlayer.units[i].direction,copy.bluePlayer,alive,i);
            else if(this.bluePlayer.units[i] instanceof Spearman)
                copy.bluePlayer.units[i] = new Spearman(tempLocation,this.bluePlayer.units[i].direction,copy.bluePlayer,alive,i);
            else if(this.bluePlayer.units[i] instanceof Knight){
                copy.bluePlayer.units[i] = new Knight(tempLocation,this.bluePlayer.units[i].direction,copy.bluePlayer,alive,i);
                Knight originalKnight = (Knight)this.bluePlayer.units[i];
                if(originalKnight.alive && originalKnight.startingLocation!=null){
                    Knight copyKnight = (Knight)copy.bluePlayer.units[i];
                    copyKnight.startingLocation = copy.locations[originalKnight.location.x][originalKnight.location.z];
                }
            }
        }       
        copy.complete = true;
        return copy;
    }
    
    /**
     * Perform an action to the GameState
     * @param action the action is going to be performed
     */
    public boolean perform(GameAction action){
        if(!action.isValidAction(this)) return false;
        
        int movingCost = this.locations[action.actingUnitX][action.actingUnitZ].unit.movingCost;

        // save for undo
        if(this.remainingMoves==2){// sosoume ta stoixeia tou pioniou pou tha kinithei mono an einai i prwti tou kinisi
            
            this.undoCurrentTurnActions.clear(); //diagrafi palaiwn kinisevn
           
            int[] saveData = new int[5];
            saveData[0] = this.activePlayer.id;
            saveData[1] = this.locations[action.actingUnitX][action.actingUnitZ].unit.id;
            saveData[2] = action.actingUnitX;
            saveData[3] = action.actingUnitZ;
            saveData[4] = this.locations[action.actingUnitX][action.actingUnitZ].unit.direction;
            undoCurrentTurnActions.add(saveData);
        }
        
        
        if(action instanceof Transposition) this.perform((Transposition) action);
        else if(action instanceof Rotation) this.perform((Rotation) action);
        else if (action instanceof Attack)this.perform((Attack) action);
        else return false;
        
        this.remainingMoves -= movingCost;
        
        return true;
    }
    
    /**
     * Clone the GameState and perform an action to the copy
     * @param action the action is going to be performed
     * @return the new GameState after action has been performed
     */
    public GameState performAndClone(GameAction action){

        if(!action.isValidAction(this)){
            System.out.println("GameState-execute and clone-InValid Action");
            return null;
        }
        
        GameState newState = this.clone();
        int movingCost = this.locations[action.actingUnitX][action.actingUnitZ].unit.movingCost;
        
        if(action instanceof Transposition) newState.perform((Transposition) action);
        else if(action instanceof Rotation) newState.perform((Rotation) action);
        else if (action instanceof Attack)newState.perform((Attack) action);
        else return null;
        newState.remainingMoves -= movingCost;
        return newState;
    }
    
    /**
     * Perform a Transposition to the GameState
     * @param transposition the Transposition is going to be performed
     */
    private void perform(Transposition transposition){
        //Unit actingUnit = this.getUnit(transposition);
        Unit actingUnit = this.locations[transposition.actingUnitX][transposition.actingUnitZ].unit;       
        //System.out.println("GameState.executeAndClone Transposition"+tempUnit);
        if(actingUnit instanceof Knight){
            Knight tempKnight = (Knight)actingUnit;
            if(this.remainingMoves == 2) tempKnight.startingLocation = tempKnight.location;
            else if(this.remainingMoves == 1)tempKnight.startingLocation = null;
        }
        if(transposition.direction==0)actingUnit.moveNorth();
        else if(transposition.direction==1)actingUnit.moveWest();
        else if(transposition.direction==2)actingUnit.moveSouth();
        else if(transposition.direction==3)actingUnit.moveEast();
        
        //if(!this.moveUnit(actingUnit, transposition.direction))System.err.println("GameState.executeAndClone transposition moveUnit fail");
    }
    
    /**
     * Perform a Rotation to the GameState
     * @param rotation the Rotation is going to be performed
     */
    private void perform(Rotation rotation ){
        //Unit actingUnit = this.getUnit(rotation);
        Unit actingUnit = this.locations[rotation.actingUnitX][rotation.actingUnitZ].unit;
        if(rotation.direction==0)actingUnit.turnNorth();
        else if(rotation.direction==1)actingUnit.turnWest();
        else if(rotation.direction==2)actingUnit.turnSouth();
        else if(rotation.direction==3)actingUnit.turnEast();
    }
    
    /**
     * Perform an Attack to the GameState
     * @param attack the Attack is going to be performed
     */
    private void perform(Attack attack){

        BoardLocation attackUnitLocation = this.locations[attack.actingUnitX][attack.actingUnitZ];
        BoardLocation defenceUnitLocation = attackUnitLocation.next(attack.direction);
        Unit defenceUnit = defenceUnitLocation.unit;

        // sozoume ta stoixeia tou pioniou pou tha fagwthei
        int[] saveData = new int[5];
        saveData[0] = defenceUnit.player.id;
        saveData[1] = defenceUnit.id;
        saveData[2] = defenceUnit.location.x;
        saveData[3] = defenceUnit.location.z;
        saveData[4] = defenceUnit.direction;
        undoCurrentTurnActions.add(saveData);
        
        defenceUnit.kill();
        Unit attackUnit = attackUnitLocation.unit;
        
        if(attackUnit instanceof Spearman){
            Spearman temp = (Spearman) attackUnit;
            if(attack.direction==4) temp.moveNorthWest();
            else if(attack.direction==5) temp.moveSouthWest();
            else if(attack.direction==6) temp.moveSouthEast();
            else if(attack.direction==7)temp.moveNorthEast();
        }
        else{
            if(attack.direction==0)attackUnit.moveNorth();
            else if(attack.direction==1)attackUnit.moveWest();
            else if(attack.direction==2)attackUnit.moveSouth();
            else if(attack.direction==3)attackUnit.moveEast();
        }  
    }
    
    /**
     * Undo the last performed action 
     */
    public void undo(){
        if(this.undoCurrentTurnActions.isEmpty()) return;
        
        if(this.undoCurrentTurnActions.get(0)[0]==0) this.activePlayer = this.redPlayer;
        else this.activePlayer = this.bluePlayer;
        
        do{
            int loadData[] = this.undoCurrentTurnActions.get(0);
            //evresi tou player thesi 0 sta data
            Player player;
            if(this.redPlayer.id == loadData[0]) player = redPlayer;
            else player = bluePlayer;
            
            //evresi tou unit thesi 1 sta data
            if(player.units[loadData[1]].location!=null){//to unit einai alive
                player.units[loadData[1]].location.captured = false;
                player.units[loadData[1]].location.unit = null;
            }
            
            //evresi arxikis thesis unit theseis 2,3 data
            player.units[loadData[1]].location = this.locations[loadData[2]][loadData[3]];
            this.locations[loadData[2]][loadData[3]].unit = player.units[loadData[1]];
            this.locations[loadData[2]][loadData[3]].captured = true;
            
            //evresi arxikis kateuthinsi unit thesi 4 data
            player.units[loadData[1]].direction = loadData[4];
            
            if(player.units[loadData[1]].alive == false){
                player.units[loadData[1]].alive = true;
                player.numberofAliveUnits++;
                player.deadPoint = player.deadPoint.sub(player.deadVector);
            }
            if(player.units[loadData[1]] instanceof Knight){
                Knight tempKnight = (Knight) player.units[loadData[1]];
                tempKnight.startingLocation = null;
            }
            this.undoCurrentTurnActions.remove(0);
        }while(!this.undoCurrentTurnActions.isEmpty());
        
        this.remainingMoves = 2;
    }
    
    /**
     * Find all possible actions of active player
     * @return possible actions in ArrayList
     */
    public ArrayList<GameAction[]> findPossibleActions(){
        if(this.remainingMoves!=2)System.err.println("GameState findPossibleActions this.remeainigMoves!=2");
        ArrayList<GameAction[]> actionList = new ArrayList<GameAction[]>();
        int i = 0;
        int length = this.activePlayer.units.length;
        for(i=0;i<length;i++){
            Unit activeUnit = this.activePlayer.units[i];
            //System.out.println("GameState.getPossibleActions Unit:"+ i+1+"-"+activeUnit);
            if(activeUnit.alive ){
                ArrayList<GameAction[]> tempList;
                tempList = activeUnit.getPossibleActions(this);
                for(GameAction[] tempAction: tempList) actionList.add(tempAction);
            }
            //System.out.println(i+"-"+activeUnit);
        }
        //System.out.println("GameState Possible Actions found");
        return actionList;
    }
    
    /**
     * @return a random action (or actions) 
     */
    public GameAction[] getRandomAction(){
        Random random = new Random();
        random.setSeed(System.currentTimeMillis());
             
        do{
            //epilogi enos tuxaiou pioniou
            int x = random.nextInt();
            if(x<0)x*=-1;
            x = x%this.activePlayer.units.length;
            //if(!this.activePlayer.units[x].alive) continue;
            ArrayList<GameAction[]> actions = this.activePlayer.units[x].getPossibleActions(this);
            if(actions==null || actions.isEmpty()) continue;
            x = random.nextInt();
            if(x<0)x*=-1;
            x=x%actions.size();
            return actions.get(x);
        } while(true);
    }
}
