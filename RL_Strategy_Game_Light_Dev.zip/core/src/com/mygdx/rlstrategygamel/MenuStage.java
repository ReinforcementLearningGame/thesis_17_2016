package com.mygdx.rlstrategygamel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the templlate in the editor.
 */


import com.mygdx.rlstrategygamel.GameClasses.Settings;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.scenes.scene2d.ui.TextField.TextFieldFilter;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.Array;

/**
 * Interact with keyboard to control the camera in 3D environment
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class MenuStage extends Stage{
    
    protected TextButton bnStartGame;
    protected Array<TextButton> bnSelectTrack;
    protected Array<TextButton> bnSelectRedPlayer;
    protected Array<TextButton> bnSelectBluePlayer;



    protected Label lbSelectTrack;
    protected Label lbBluePlayer;
    protected Label lbRedPlayer;

    protected Label lbDrawLimit;


    
    protected Image eapLogo;

    
    //private TextureRegion eapLogo;
    //------listeners----------------------------
    public ClickListener newGameListener;
    public ClickListener selectGameListener;
    public ClickListener displayGameListener;
    
    private Color deselectColor = Color.GRAY;
    private Color selectColor = Color.valueOf("E34968");
    private Color startColor = Color.valueOf("76B43C");
    protected TextField tfDrawLimit;
    
    
    public MenuStage(){
        super();
    }
    
    public Settings initialize(final Settings gameSettings, Skin skin){
        
        int W = Gdx.graphics.getWidth();
        int H = Gdx.graphics.getHeight();
        
        //------Label Red Player------------------------------------------
        lbRedPlayer = new Label("Red Player",skin);
        lbRedPlayer.setPosition(34*W/100, H-25*H/100);
        lbRedPlayer.setWidth(32*W/100);
        //lbRedPlayer.setHeight(4*H/100);
        lbRedPlayer.setAlignment(0);
        this.addActor(lbRedPlayer);
        //------Label Blue Player------------------------------------------
        lbBluePlayer = new Label("Blue Player",skin);
        lbBluePlayer.setPosition(67*W/100, H-25*H/100);
        lbBluePlayer.setWidth(32*W/100);
        //lbBluePlayer.setHeight(4*H/100);
        lbBluePlayer.setAlignment(0);
        this.addActor(lbBluePlayer);
        //------Label Select Track------------------------------------------
        lbSelectTrack = new Label("Select Track",skin);
        lbSelectTrack.setPosition(1*W/100, H-25*H/100);
        lbSelectTrack.setWidth(32*W/100);
        //lbSelectTrack.setHeight(7*H/100);
        lbSelectTrack.setAlignment(0);
        
        this.addActor(lbSelectTrack);
        //-------Lista me pistes--------------------------------------------
        FileHandle tracksDirecrory = Gdx.files.internal("tracks");
        FileHandle[] listOfTracks = tracksDirecrory.list();
        bnSelectTrack = new Array<TextButton>();
        int i = 4;
        for(FileHandle temp:listOfTracks){
            TextButton bnTrack;
            String name = temp.name().substring(0, temp.name().length()-4);
            bnTrack = new TextButton(name, skin, "default");
            bnTrack.setName(name);
            bnTrack.setWidth(32*W/100);
            bnTrack.setHeight(7*H/100);
            bnTrack.setPosition(1*W/100, H-i*9*H/100);
            bnTrack.setColor(deselectColor);
            bnTrack.addListener(new ClickListener(){
                @Override 
                public void clicked(InputEvent event, float x, float y){
                    String tempName = event.getListenerActor().getName();
                    for(TextButton tempButton:bnSelectTrack){
                        if(tempButton.getName().equals(tempName)){
                            tempButton.setColor(selectColor);
                            gameSettings.setTrack(tempName);
                        }
                        else tempButton.setColor(deselectColor);
                    }
                }
            });
            this.addActor(bnTrack);
            bnSelectTrack.add(bnTrack);
            i++;
        }

        String[] Players = new String[]{"Human", "CPU Random", "CPU Attack", "CPU Defence", "CPU Preset", "CPU RL"};
        //-----Lista me Red Players-----------------------------------------
        bnSelectRedPlayer = new Array<TextButton>();
        i = 4  ;
        for(String temp:Players){
            TextButton bnPlayer;
            bnPlayer = new TextButton(temp, skin, "default");
            bnPlayer.setName(temp);
            bnPlayer.setWidth(32*W/100);
            bnPlayer.setHeight(7*H/100);
            bnPlayer.setPosition(34*W/100, H-i*9*H/100);
            bnPlayer.setColor(deselectColor);
            bnPlayer.addListener(new ClickListener(){
                @Override 
                public void clicked(InputEvent event, float x, float y){
                    String tempName = event.getListenerActor().getName();
                    if(tempName.startsWith("CPU RL")) gameSettings.redAI = true;
                    else gameSettings.redAI = false;
                    for(TextButton tempButton:bnSelectRedPlayer){
                        if(tempButton.getName().equals(tempName)){
                            tempButton.setColor(selectColor);
                            gameSettings.setRedPlayer(tempName);
                        }
                        else tempButton.setColor(deselectColor);
                    }
                }
            });
            bnSelectRedPlayer.add(bnPlayer);
            this.addActor(bnPlayer);
            i++;
        }
        //-----Lista me Blue Players-----------------------------------------
        bnSelectBluePlayer = new Array<TextButton>();
        i = 4;
        for(String temp:Players){
            TextButton bnPlayer;
            bnPlayer = new TextButton(temp, skin, "default");
            bnPlayer.setName(temp);
            bnPlayer.setWidth(32*W/100);
            bnPlayer.setHeight(7*H/100);
            bnPlayer.setPosition(67*W/100, H-i*9*H/100);
            bnPlayer.setColor(deselectColor);
            bnPlayer.addListener(new ClickListener(){
                @Override 
                public void clicked(InputEvent event, float x, float y){
                    String tempName = event.getListenerActor().getName();
                    if(tempName.startsWith("CPU RL")) gameSettings.blueAI = true;
                    else gameSettings.blueAI = false;
                    for(TextButton tempButton:bnSelectBluePlayer){
                        if(tempButton.getName().equals(tempName)){
                            tempButton.setColor(selectColor);
                            gameSettings.setBluePlayer(tempName);

                        }
                        else tempButton.setColor(deselectColor);
                    }
                }
            });
            bnSelectBluePlayer.add(bnPlayer);
            this.addActor(bnPlayer);
            i++;
        }
        //----Button Start game--------------------------------------------
        bnStartGame = new TextButton("Start Game",skin, "default");
        bnStartGame.setWidth(65*W/100);
        bnStartGame.setHeight(15*H/100);
        bnStartGame.setPosition(34*W/100, H-98*H/100);
        bnStartGame.setColor(startColor);
        bnStartGame.addListener(newGameListener);

        this.addActor(bnStartGame);
        
        //------Label Draw Limit------------------------------------------
        lbDrawLimit = new Label("Draw Limit",skin);
        lbDrawLimit.setPosition(1*W/100, H-92*H/100);
        lbDrawLimit.setWidth(16*W/100);
        lbDrawLimit.setHeight(15*H/100);
        lbDrawLimit.setAlignment(5);
        this.addActor(lbDrawLimit);
        
        //------Text Field Draw Limit------------------------------------------
        this.tfDrawLimit = new TextField("200",skin);
        this.tfDrawLimit.setPosition(16*W/100, H-98*H/100);
        this.tfDrawLimit.setSize(17*W/100, 15*H/100);
        this.tfDrawLimit.setTextFieldFilter(new TextFieldFilter.DigitsOnlyFilter());
        this.tfDrawLimit.setMaxLength(4);
        this.tfDrawLimit.setAlignment(3);
        this.addActor(tfDrawLimit);
        

        
        //------EAP Logo Image---------
        Texture texture = new Texture(Gdx.files.internal("Logo.jpg")); 
        this.eapLogo = new Image (texture);
        this.eapLogo.setPosition(0, H-18*H/100);
        this.eapLogo.setSize(W, 18*H/100);
        this.addActor(this.eapLogo);
  
        
        return this.defaultValues(gameSettings);
    }
    
    public Settings defaultValues(Settings gameSettings){
        //-----defaults-----------------------------------------------------
        for(TextButton tempButton:bnSelectTrack) tempButton.setColor(deselectColor);
        for(TextButton tempButton:bnSelectRedPlayer) tempButton.setColor(deselectColor);
        for(TextButton tempButton:bnSelectBluePlayer) tempButton.setColor(deselectColor);
        // default epileges einai oi prwtes
        TextButton tempButton = bnSelectTrack.first();
        tempButton.setColor(selectColor);
        gameSettings.setTrack(tempButton.getName());
        tempButton = bnSelectRedPlayer.first();
        tempButton.setColor(selectColor);
        gameSettings.setRedPlayer(tempButton.getName());
        tempButton = bnSelectBluePlayer.first();
        tempButton.setColor(selectColor);
        gameSettings.setBluePlayer(tempButton.getName());

        gameSettings.redAI = false;
        gameSettings.blueAI = false;
        
        gameSettings.setLoggingOn(false);

        gameSettings.setGraphicsOn(true);
        this.tfDrawLimit.setText("200");
        gameSettings.setDrawLimit(this.tfDrawLimit.getText().toString());
        

        
        
        return gameSettings;
        
        //System.out.println("Default menu");
    }
    
    

}
