package com.mygdx.rlstrategygamel.client;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.backends.gwt.GwtApplication;
import com.badlogic.gdx.backends.gwt.GwtApplicationConfiguration;
import com.mygdx.rlstrategygamel.RL_Strategy_Game_L;

/**
 * Run the application in web browser
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */

public class HtmlLauncher extends GwtApplication {

        @Override
        public GwtApplicationConfiguration getConfig () {
                return new GwtApplicationConfiguration(1056, 594);
        }

        @Override
        public ApplicationListener createApplicationListener () {
                return new RL_Strategy_Game_L();
        }
}