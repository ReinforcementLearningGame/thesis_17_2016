/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygame.GameClasses.Players;

import com.mygdx.rlstrategygame.GameClasses.BoardLocation;
import com.mygdx.rlstrategygame.GameClasses.Actions.GameAction;
import com.mygdx.rlstrategygame.GameClasses.GameState;
import com.mygdx.rlstrategygame.GameClasses.Units.Spearman;
import com.mygdx.rlstrategygame.GameClasses.Units.Infantry;
import com.mygdx.rlstrategygame.GameClasses.Units.Unit;
import java.util.ArrayList;
import javafx.geometry.Point2D;

/**
 * Abstract class for 2 kinds of RL Strategy Game's players
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public abstract class Player {
    
    
    public int id;
    public BoardLocation flag;
    public int numberofAliveUnits;
    public Unit units[];
    public Point2D boardSize;
    
    public Point2D deadPoint; //sindetagmenes stin skakiera pou tha topothetithei to epomeno fagwmwno pioni
    public Point2D deadVector;//vector gia ipologismo tou epomenou deadPoint
    public int deadDirection; // kateuthinsi twn fagwmwnwn pioniwn tou paikti
    
    public Player(int id,BoardLocation flag,Point2D boardSize)
    {
        this.id =id;
        this.flag = flag;
        this.numberofAliveUnits = 0;
        this.boardSize = boardSize;
        if(id==0){
            this.deadDirection = 3;
            this.deadPoint = new Point2D(-1,-1);
            this.deadVector = new Point2D(0,1);
        }
        else if(id==1){
            this.deadDirection = 1;
            this.deadPoint = boardSize;
            this.deadVector = new Point2D(0,-1);
        }
    }
    
    public boolean hasPossibleActions(GameState state){
        //ean exei estw ena alive Infantry i Spearman exei kai pithanes kiniseis
        for(Unit unit:units)
            if(unit.alive && (unit instanceof Infantry ||unit instanceof Spearman))
                return true;
        //tha ftasei edo ean exei mono alive knights
        for(Unit unit:units)
            if(unit.alive){
                ArrayList<GameAction> possibleActions = unit.findActions(state);
                if(!possibleActions.isEmpty()) return true;
            }
        return false;
    }
}
