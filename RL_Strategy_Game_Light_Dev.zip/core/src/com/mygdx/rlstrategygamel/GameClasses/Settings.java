/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygamel.GameClasses;

import com.mygdx.rlstrategygamel.RL_Agents.NeuralNet;

/**
 * Settings of the game 
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class Settings {
    private String track;
    private boolean loggingOn;
    private String logging;
    private boolean graphicsOn;
    public String redPlayer;
    public String bluePlayer;
    private int drawLimit;
    private int numberOfGames;
    private double minReward;
    private double maxReward;
    //---AI Red----
    public boolean redAI;
    public boolean redLearning;
    private double redEGreedy;
    private double redLambda;
    private double redGamma;
    private boolean redEliminationReward;
    
    //---AI Blue---
    public boolean blueAI;
    public boolean blueLearning;
    private double blueEGreedy;
    private double blueLambda;
    private double blueGamma;
    private boolean blueEliminationReward;
    
    public NeuralNet redNeuralNet;
    public NeuralNet blueNeuralNet;
    
    public Settings(){

    }

    public boolean settingsReady(){

        if(drawLimit<50){
            System.out.println("Draw limit <50");
            return false;
        }
        else if(loggingOn && logging==null){
            System.out.println("Logging path empty");
            return false;
        }
        else if(redPlayer==null){
            System.out.println("Red player is null");
            return false;
        }
        else if(bluePlayer==null){
            System.out.println("Blue player is null");
            return false;
        }
        else return true;
    }
    public void setTrack(String track){
        this.track = track;
    }
    public void setRedPlayer(String player){
        this.redPlayer = player;
    }
    public void setBluePlayer(String player){
        this.bluePlayer = player;
    }
    public void setLoggingOn(boolean bool){
        this.loggingOn = false;
    }
    public void setGraphicsOn(boolean bool){
        this.graphicsOn = true;
    }
    public String getTrack(){
        return this.track;
    }
    public String getLogging(){
        return this.logging;
    }
    public boolean isLoggingOn(){
        return this.loggingOn;
    }
    public boolean isGraphicsOn(){
        return this.graphicsOn;
    }
    
    public void setMinReward(String minReward){
        try{
            this.minReward = Double.parseDouble(minReward);
        }catch(NumberFormatException e){
            this.minReward =-1.0;
        }
    }
    
    public void setMaxReward(String maxReward){
        try{
            this.maxReward = Double.parseDouble(maxReward);
        }catch(NumberFormatException e){
            this.maxReward =1.0;
        }
    }
    
    public double getMinReward(){
        return this.minReward;
    }
    
    public double getMaxReward(){
        return this.maxReward;
    }
    
    public void setDrawLimit(String drawLimit){
        try{
            this.drawLimit = Integer.parseInt(drawLimit);
        }catch(NumberFormatException e){
            this.drawLimit =500;
        }
        if(this.drawLimit<50) this.drawLimit = 50;
    }
    public int getDrawLimit(){
        return this.drawLimit;
    }
    
    public void setRedEGreedy(String redEGreedy){
        try{
            this.redEGreedy = Double.parseDouble(redEGreedy);
        }catch(NumberFormatException e){
            this.redEGreedy = 1;
        }
    }
    
    public void setBlueEGreedy(String blueEGreedy){
        try{
            this.blueEGreedy = Double.parseDouble(blueEGreedy);
        }catch(NumberFormatException e){
            this.blueEGreedy = 1;
        }
    }
    
    public void setRedLambda(String redLambda){
        try{
            this.redLambda = Double.parseDouble(redLambda);
        }catch(NumberFormatException e){
            this.redLambda = 0;
        }
    }
    
    public void setBlueLambda(String blueLambda){
        try{
            this.blueLambda = Double.parseDouble(blueLambda);
        }catch(NumberFormatException e){
            this.blueLambda = 0;
        }
    }
    
    public void setRedGamma(String redGamma){
        try{
            this.redGamma = Double.parseDouble(redGamma);
        }catch(NumberFormatException e){
            this.redGamma = 0;
        }
    }
    
    public void setBlueGamma(String blueGamma){
        try{
            this.blueGamma = Double.parseDouble(blueGamma);
        }catch(NumberFormatException e){
            this.blueGamma = 0;
        }
    }
    
    public void setRedEliminationReward(boolean redEliminationReward){
        this.redEliminationReward = redEliminationReward;
    }
    
    public void setBlueEliminationReward(boolean blueEliminationReward){
        this.blueEliminationReward = blueEliminationReward;
    }
    
    public double getRedEGreedy(){
        return this.redEGreedy;
    }
    
    public double getBlueEGreedy(){
        return this.blueEGreedy;
    }
    
    public double getRedLambda(){
        return this.redLambda;
    }
    
    public double getBlueLambda(){
        return this.blueLambda;
    }

    public double getRedGamma(){
        return this.redGamma;
    }
    
    public double getBlueGamma(){
        return this.blueGamma;
    }
    
    public boolean getRedEliminationReward(){
        return this.redEliminationReward;
    }
    
    public boolean getBlueEliminationReward(){
        return this.blueEliminationReward;
    }

}
