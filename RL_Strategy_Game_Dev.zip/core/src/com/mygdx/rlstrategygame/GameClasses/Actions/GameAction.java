/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygame.GameClasses.Actions;


import com.mygdx.rlstrategygame.GameClasses.BoardLocation;
import com.mygdx.rlstrategygame.GameClasses.GameState;
import com.mygdx.rlstrategygame.GameClasses.Units.Unit;


/**
 * Abstract class for 3 kinds of RL Strategy Game's actions 
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public abstract class GameAction {
    public int actingUnitX, actingUnitZ, direction;
    
    public GameAction(int actingUnitX, int actingUnitZ){
        this.actingUnitX = actingUnitX;
        this.actingUnitZ = actingUnitZ;
    }
    
    public static boolean isAction(String string){
        if(Transposition.isTransposition(string)||Rotation.isRotation(string)||Attack.isAttack(string)) return true;
        return false;
    }

    //Checks if this action is valid to this gameState
    protected boolean isValid(GameState gameState){
        //Game game = gameState.game;
        BoardLocation startingLocation = gameState.locations[this.actingUnitX][this.actingUnitZ];
        //energeia apo thesi ektws pistas
        if(startingLocation==null) return false;
        //energeia apo nogo thesi
        if(!startingLocation.canGo) return false;
        //energeia apo keni go thesi
        //System.out.println("GameAction.isValid getUnit call for actingUnit");
        //Unit actiongUnit = gameState.getUnit(this);
        Unit actiongUnit = startingLocation.unit;
        if(actiongUnit==null)return false;
        //energeia pioniou andipalou
        if(actiongUnit.player.id != gameState.activePlayer.id) return false;
        //exei idi ginei mia kinisi alogou, kai ginetai apopeira kinisis allou pioniou
        if(actiongUnit.movingCost>gameState.remainingMoves) return false;
        // i energeia borei na ektelestei
        //System.out.println("Valid Action");
        return true;
    }
    
    public boolean isValidAction(GameState gameState){
        if(this instanceof Attack){
            Attack temp = (Attack)this;
            return temp.isValid(gameState);
        }
        else if (this instanceof Rotation){
            Rotation temp = (Rotation)this;
            return temp.isValid(gameState);
        }
        else if (this instanceof Transposition){
            Transposition temp = (Transposition)this;
            return temp.isValid(gameState);
        }
        System.out.println("Validation failed");
        return false;
    }
    
    public int getX(){
        return this.actingUnitX;
    }
    
    public int getZ(){
        return this.actingUnitZ;
    }
    
    public String toString(){
        if(this instanceof Transposition) return (((Transposition)this).toString());
        else if(this instanceof Rotation) return (((Rotation)this).toString());
        else if(this instanceof Attack) return (((Attack)this).toString());
        else return null;
    }
}
