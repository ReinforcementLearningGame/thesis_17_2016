/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygame.RL_Agents;

import com.mygdx.rlstrategygame.GameClasses.Actions.GameAction;
import com.mygdx.rlstrategygame.GameClasses.GameState;
import java.util.ArrayList;

/**
 *An abstract Agent that handles the decision making process and value assignment.
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public abstract class RLAgent {
    /**
     * Which RL method does the RLAgent use to make decisions (i.e. TD(λ)-SARSA/Q, MC etc).
     */
    protected String RLMethod;
    
    /**
     * An integer number defining the turn of the game, that is currently being played.
     */
    protected int turn;
    
    /**
     * The neural network that will be trained for decision making purposes.
     */
    protected NeuralNet neuralNetwork;
    
    /**
     * The ε-greedy value of RL Learning. Higher values mean that exploitation will occur more often than exploration.
     */
    protected double eGreedyValue;
    
    
    public double currentReward;
    
    /**
     * Choose a PawnAction among all legal actions passed to the RL Agent.
     * @param legalActions all possible legal actions, the agent may choose in any game state.
     * @param state the current game state
     * @return the chosen action or actions
     */
    public abstract GameAction[] chooseAction(ArrayList<GameAction[]> legalActions, GameState state);
    
    
    /**
     * Apply the chosen action and calculate the values of the RL process.
     * @param chosenAction the action chosen by the RL agent
     * @param state the current game state
     */
    public abstract void learnFromAction(GameState state,GameAction[] chosenAction);
    
    /**
     * The Agent learns by evaluating the afterstate, that emerges after the players move
     * @param state the current game state
     */
    public abstract void learnFromAfterstate(GameState state);
    
    /**
     * Store the Agents current reward.
     * @param state the current game state
     */
    public abstract void updateCurrentReward(GameState state);
    
    
    /**
     * @return the RLMethod
     */
    public String getRLMethod() {
        return RLMethod;
    }

    /**
     * @param RLMethod the RLMethod to set
     */
    protected void setRLMethod(String RLMethod) {
        this.RLMethod = RLMethod;
    }

    /**
     * @return the neuralNetwork
     */
    protected NeuralNet getNeuralNetwork() {
        return neuralNetwork;
    }

    /**
     * @param neuralNetwork the neuralNetwork to set
     */
    protected void setNeuralNetwork(NeuralNet neuralNetwork) {
        this.neuralNetwork = neuralNetwork;
    }

    /**
     * @return the eGreedyValue
     */
    protected double geteGreedyValue() {
        return eGreedyValue;
    }

    /**
     * @param eGreedyValue the eGreedyValue to set
     */
    protected void seteGreedyValue(double eGreedyValue) {
        this.eGreedyValue = eGreedyValue;
    }

    /**
     * Define what happens after the end of a training session.
     */
    public abstract void endOfGame();
    
    /**
     * Initialize the agent to start learning.
     */
    public abstract void initialize(GameState state);
    
}
