/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygamel;

import com.mygdx.rlstrategygamel.Graphics.GraphicsGame;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.IntIntMap;

/**
 * Interact with keyboard to control the camera in 3D environment
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class BoardCameraController extends InputAdapter {
	private final Camera camera;
	private final IntIntMap keys = new IntIntMap();
	private int STRAFE_LEFT = Keys.A;
	private int STRAFE_RIGHT = Keys.D;
	private int FORWARD = Keys.W;
	private int BACKWARD = Keys.S;
	private int UP = Keys.R;
	private int DOWN = Keys.F;
        private int ZOOM_IN = Keys.Z;
	private int ZOOM_OUT = Keys.X;
        private int TURN_LEFT = Keys.LEFT;
	private int TURN_RIGHT = Keys.RIGHT;
        private int LOOK_UP = Keys.UP;
	private int LOOK_DOWN = Keys.DOWN;
        private int STANDARD_1 = Keys.NUM_1;
        private int STANDARD_2 = Keys.NUM_2;
        private int STANDARD_3 = Keys.NUM_3;
        private int STANDARD_4 = Keys.NUM_4;
        private int STANDARD_5 = Keys.NUM_5;
        
	private float velocity = 5;
	private float degreesPerPixel = 0.5f;
	private final Vector3 tmp = new Vector3();
        private int limitX, limitZ;
        
	public BoardCameraController (Camera camera,Vector2 limits) {
		this.camera = camera;
                limitX = (int)limits.x;
                limitZ = (int)limits.y;
	}

	@Override
	public boolean keyDown (int keycode) {
		keys.put(keycode, keycode);
		return true;
	}

	@Override
	public boolean keyUp (int keycode) {
		keys.remove(keycode, 0);
		return true;
	}

	/** Set the velocity in units per second for moving forward, backward and strafing left/right.
	 * @param velocity the velocity in units per second 
         */
	public void setVelocity (float velocity) {
		this.velocity = velocity;
	}
        
        /**
         * Update the condition of the camera
         */
	public void update () {
            float deltaTime = Gdx.graphics.getDeltaTime();
            int size = GraphicsGame.getSize();

            if (keys.containsKey(FORWARD)) {
                tmp.set(camera.direction.x,0,camera.direction.z).nor().scl(2*deltaTime * velocity);
                camera.position.add(tmp);
                checkLimits();
            }
            if (keys.containsKey(BACKWARD)) {
                tmp.set(camera.direction.x,0,camera.direction.z).nor().scl(-2*deltaTime * velocity);
                camera.position.add(tmp);
                checkLimits();
            }
            if (keys.containsKey(STRAFE_LEFT)) {
                tmp.set(camera.direction).crs(camera.up).nor().scl(-2*deltaTime * velocity);
                camera.position.add(tmp);
                checkLimits();
            }
            if (keys.containsKey(STRAFE_RIGHT)) {
                tmp.set(camera.direction).crs(camera.up).nor().scl(2*deltaTime * velocity);
                camera.position.add(tmp);
                checkLimits();
            }
            if (keys.containsKey(ZOOM_IN)) {
                tmp.set(camera.direction).nor().scl(2*deltaTime * velocity);
                camera.position.add(tmp);
                checkLimits();
            }
            if (keys.containsKey(ZOOM_OUT)) {
                tmp.set(camera.direction).nor().scl(-2*deltaTime * velocity);
                camera.position.add(tmp);
                checkLimits();
            }
            if (keys.containsKey(UP)) {
                tmp.set(0,1,0).nor().scl(2*deltaTime * velocity);
                camera.position.add(tmp);
                //uper 
                if(camera.position.y > 1.1f*size*max(limitX,limitZ))
                    camera.position.set(camera.position.x,1.1f*size*max(limitX ,limitZ),camera.position.z);
            }
            if (keys.containsKey(DOWN)) {
                tmp.set(0,1,0).nor().scl(-2*deltaTime * velocity);
                camera.position.add(tmp);
                //lower limit
                if(camera.position.y<3f*size) camera.position.set(camera.position.x,3f*size,camera.position.z);
            }
            if (keys.containsKey(TURN_LEFT)){
                camera.rotateAround(camera.position,new Vector3(0,1,0), 5*deltaTime * velocity);
            }
            if (keys.containsKey(TURN_RIGHT)){
                camera.rotateAround(camera.position,new Vector3(0,-1,0), 5*deltaTime * velocity);
            }
            if (keys.containsKey(LOOK_UP)){
                tmp.set(camera.direction).crs(camera.up);
                camera.rotateAround(camera.position,tmp, 10*deltaTime * velocity);
                //look up limit
                if(camera.direction.y>=0){
                    camera.up.set(0,1,0);
                    camera.direction.set(camera.direction.x,0,camera.direction.z);
                }
            }
            if (keys.containsKey(LOOK_DOWN)){
                
                tmp.set(camera.direction).crs(-camera.up.x,-camera.up.y,-camera.up.z);
                camera.rotateAround(camera.position,tmp, 10*deltaTime * velocity);
                //look down limit
                if(camera.up.y<=0){
                    camera.up.set(camera.up.x,0,camera.up.z);
                    camera.direction.set(0,-1,0);
                }
            }
            if (keys.containsKey(STANDARD_1)){
                
                camera.position.set(size*(float)(limitX-1)/2.0f, 0.75f*size*max(limitX,limitZ), size*(limitZ+1.5f));
                camera.up.set(0, 1, 0);
                camera.lookAt(size*(float)(limitX-1)/2.0f, 0, size*(float)(limitZ-1)/2.0f);
            }
            if (keys.containsKey(STANDARD_2)){
                
                camera.position.set(size*(limitX+1.5f), 0.75f*size*max(limitX,limitZ), size*(float)(limitZ-1)/2.0f);
                camera.up.set(0, 1, 0);
                camera.lookAt(size*(float)(limitX-1)/2.0f, 0, size*(float)(limitZ-1)/2.0f);
            }
            if (keys.containsKey(STANDARD_3)){
                camera.position.set(size*(float)(limitX-1)/2.0f, 0.75f*size*max(limitX,limitZ), -2.5f*size);
                camera.up.set(0, 1, 0);
                camera.lookAt(size*(float)(limitX-1)/2.0f, 0, size*(float)(limitZ-1)/2.0f);
            }
            if (keys.containsKey(STANDARD_4)){

                camera.position.set(-2.5f*size, 0.75f*size*max(limitX,limitZ), size*(float)(limitZ-1)/2.0f);
                camera.up.set(0, 1, 0);
                camera.lookAt(size*(float)(limitX-1)/2.0f, 0, size*(float)(limitZ-1)/2.0f);
            }
            if (keys.containsKey(STANDARD_5)){

                camera.position.set(size*(float)(limitX-1)/2.0f, 1.1f*size*max(limitX,limitZ), size*(float)(limitZ-1)/2.0f);
                camera.lookAt(size*(float)(limitX-1)/2.0f, 0, size*(float)(limitZ-1)/2.0f);
                camera.up.set(1, 0, 0);
            }
            camera.update(true);
	}
        
        /**
         * Keep the camera close to the board
         */
        private void checkLimits(){
            int size = GraphicsGame.getSize();
            if(camera.position.x<-3.5f*size) camera.position.set(-3.5f*size, camera.position.y, camera.position.z);
            if(camera.position.z<-3.5f*size) camera.position.set(camera.position.x, camera.position.y, -3.5f*size);
            if(camera.position.x>size*(limitX+2.5f)) camera.position.set(size*(limitX+2.5f), camera.position.y, camera.position.z);
            if(camera.position.z>size*(limitZ+2.5f)) camera.position.set(camera.position.x, camera.position.y, size*(limitZ+2.5f));
            if(camera.position.y>1.1f*size*max(limitX,limitZ)) camera.position.set(camera.position.x,1.1f*size*max(limitX,limitZ),camera.position.z);
            if(camera.position.y<3f*size) camera.position.set(camera.position.x,3f*size,camera.position.z);
        }
        
        /**
        * Return the max between 2 integers
        */
        private int max(int a, int b){
            if(a>b) return a;
            else return b;
        }
}
