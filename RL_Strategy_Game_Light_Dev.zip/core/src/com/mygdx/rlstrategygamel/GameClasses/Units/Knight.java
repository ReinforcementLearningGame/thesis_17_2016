/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygamel.GameClasses.Units;

import com.mygdx.rlstrategygamel.GameClasses.BoardLocation;
import com.mygdx.rlstrategygamel.GameClasses.Actions.GameAction;
import com.mygdx.rlstrategygamel.GameClasses.GameState;
import com.mygdx.rlstrategygamel.GameClasses.Players.Player;
import java.util.ArrayList;

/**
 * The class for pawn type "Knight"
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class Knight extends Unit{
    
    private static int movingCost = 1;
    public BoardLocation startingLocation;
    
    public Knight(BoardLocation location,int direction,Player player){
        super(location,direction,player);
        super.movingCost = movingCost;
    }
    public Knight(BoardLocation location,int direction,Player player,boolean alive,int id){
        super(location,direction,player,alive,id);
        super.movingCost = movingCost;
    }
    
    @Override
    public ArrayList<GameAction[]> getPossibleActions(GameState state){
        if(state.remainingMoves!=2)System.err.println("Knight getPossibleActions status.remeainigMoves!=2="+state.remainingMoves);
        
        ArrayList<GameAction[]> actionList = new ArrayList<GameAction[]>();
        if(!this.alive) return actionList;
        GameAction[] actionArray;
        ArrayList<GameAction> tempList1 = findActions(state);
        //System.out.println("Templist1: "+tempList1);
        
        for(GameAction tempAction1:tempList1){ //gia kathe prwti kinisi
            //kratame tin arxiki thesi tou pioniou
            //System.out.println("Knight.getPossibleActions(1 thesi)-call getUnit");
            //BoardLocation tempLocation = state.getUnit(tempAction1).location;
            
            //System.out.println(tempLocation.x+"-"+tempLocation.z+"-"+tempAction1.direction);
            //GameState tempState = state.executeAndClone(tempAction1); //ipologismos tou endiamesou state
            state.perform(tempAction1);
            //evresi tis telikis thesis tou pioniou pou kinithike
            //System.out.println(state.remainingMoves+"-"+tempState+"-"+tempAction1);
            BoardLocation tempLocation = state.locations[tempAction1.actingUnitX][tempAction1.actingUnitZ];
            tempLocation = tempLocation.next(tempAction1.direction);

            //System.out.println(tempLocation.x+"-"+tempLocation.z+"-"+tempState.getUnit(tempLocation.x, tempLocation.z));
            //evresi twn epomenwn energeiwn pou borei na kanei to idio pioni
            //System.out.println("Knight.getPossibleActions(2 thesi)-call getUnit");
            //ArrayList<GameAction> tempList2 = tempState.getUnit(tempLocation.x, tempLocation.z).findActions(tempState);
            ArrayList<GameAction> tempList2 = tempLocation.unit.findActions(state);
            //System.out.println("Templist2: "+tempList2);
            for(GameAction tempAction2:tempList2){
                actionArray = new GameAction[2];
                actionArray[0] = tempAction1;
                actionArray[1] = tempAction2;
                actionList.add(actionArray);
            }
            state.undo();
        }
        //System.out.println("Knight.getPossibleActions Unit:"+this+" Number of action:"+actionList.size());
        return actionList;
    }
}
