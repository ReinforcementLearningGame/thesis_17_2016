/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygame.GameClasses.Units;

import com.mygdx.rlstrategygame.GameClasses.Actions.Attack;
import com.mygdx.rlstrategygame.GameClasses.BoardLocation;
import com.mygdx.rlstrategygame.GameClasses.Actions.GameAction;
import com.mygdx.rlstrategygame.GameClasses.GameState;
import com.mygdx.rlstrategygame.GameClasses.Players.Player;
import com.mygdx.rlstrategygame.GameClasses.Actions.Rotation;
import com.mygdx.rlstrategygame.GameClasses.Actions.Transposition;
import java.util.ArrayList;

/**
 * * Abstract class for 3 kinds of RL Strategy Game's pawns
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public abstract class Unit {
    public Player player;
    public BoardLocation location;
    public int direction;
    public boolean alive;
    public int movingCost;
    public int id;
    
    public Unit(BoardLocation location,int direction,Player player)
    {
        this.location = location;
        this.direction = direction;
        this.player = player;
        this.alive = true;
        this.location.captured = true;
        this.location.unit = this;
        this.player.numberofAliveUnits++;
    }
    public Unit(BoardLocation location, int direction, Player player, boolean alive,int id)
    {
        this.id = id;
        this.location = location;
        this.direction = direction;
        this.alive = alive;
        this.player = player;
        if(this.alive){
            this.location.captured = true;
            this.location.unit = this;
            this.player.numberofAliveUnits++;
        }
    }
    public void moveNorth(){
        this.location.unit = null;
        this.location.captured = false;
        this.location = this.location.north;
        this.location.captured = true;
        this.location.unit = this;
        this.turnNorth();
    }
    
    public void moveSouth(){
        this.location.unit = null;
        this.location.captured = false;
        this.location = this.location.south;
        this.location.captured = true;
        this.location.unit = this;
        this.turnSouth();
    }
    
    public void moveEast(){
        this.location.unit = null;
        this.location.captured = false;
        this.location = this.location.east;
        this.location.captured = true;
        this.location.unit = this;
        this.turnEast();
    }
    
    public void moveWest(){
        this.location.unit = null;
        this.location.captured = false;
        this.location = this.location.west;
        this.location.captured = true;
        this.location.unit = this;
        this.turnWest();
    }

    public void turnNorth(){
        this.direction = 0;
    }
    public void turnWest(){
        this.direction = 1;
    }
    public void turnSouth(){
        this.direction = 2;
    }
    public void turnEast(){
        this.direction = 3;
    }
    
    public boolean canBeAttackedNextTurnBy(Unit attackUnit){
        if(!attackUnit.alive||!this.alive) return false;
        if(attackUnit instanceof Knight){    
            int d=this.location.distance(attackUnit.location);
            if(d==1) return this.canBeAttackedBy(attackUnit);
            else if(d==2){
                for(int i =0;i<4;i++){
                    BoardLocation tempLocation = this.location.next(i);
                    if(tempLocation == null || !tempLocation.canGo) continue;
                    if(tempLocation.distance(attackUnit.location)==1&&(!tempLocation.captured||tempLocation.unit.canBeAttackedBy(attackUnit))
                            &&tempLocation!=this.face()) return true;
                }
            }
            else return false;
        }
        else return this.canBeAttackedBy(attackUnit);
        return false;
    }
    
    public boolean canBeAttackedBy(Unit attackUnit){
        int i;
        if(this.player.id==attackUnit.player.id) return false;//elegxos an ta 2 units anoikoun se diaforetiki omada
        if(attackUnit instanceof Spearman){//an o epitithemenos einai spearman kai vrisketai doiagwnia tou aminomenou i epithesi borei na ektelestei
            BoardLocation[] temp = this.diagonal();
            for(i=0;i<4;i++) if(temp[i]!=null&&attackUnit.location == temp[i]) return true;
        }
        else{
            // an o epitithemenos einai Infantry i Knight kai epitithetai plagia i pisw apo ton aminomeno
            BoardLocation[] temp = this.backSide();
            for(i=0;i<4;i++) if(temp[i]!=null&&attackUnit.location == temp[i]) return true;
            // an o epitithemenos einai Infantry kai epitithetai sto face tou aminomenou opou den einai Infantry
            BoardLocation temp2 = this.face();
            if(attackUnit instanceof Infantry &&! (this instanceof Infantry) && temp2!=null && attackUnit.location == temp2) return true; 
        }
        return false;
    }
    
    public BoardLocation[] diagonal(){
        BoardLocation[] diag = new BoardLocation[4];
        if(this.location.west!=null){
            diag[0]= this.location.west.north;
            diag[1]= this.location.west.south;
        }
        if(this.location.east!=null){
            diag[2]= this.location.east.north;
            diag[3]= this.location.east.south;
        }
        return diag;
    }
    
    public BoardLocation face(){
        if(this.direction==0) return this.location.north;
        else if(this.direction==1) return this.location.west;
        else if(this.direction==2) return this.location.south;
        else if(this.direction==3) return this.location.east;
        else return null;
    }
    
    public BoardLocation[] backSide(){
        BoardLocation backside[] = new BoardLocation[4];
        backside[0] = this.location.north;
        backside[1] = this.location.west;
        backside[2] = this.location.south;
        backside[3] = this.location.east;
        
        if(this.direction==0) backside[0] = null;
        if(this.direction==1) backside[1] = null;
        if(this.direction==2) backside[2] = null;
        if(this.direction==3) backside[3] = null;

        return backside;
    }
    
    public void kill(){
        if(this.alive==false) return; // to pioni einai idi fagwmwno
        this.alive=false;
        this.direction = this.player.deadDirection;
        this.player.numberofAliveUnits--;
        this.player.deadPoint = this.player.deadPoint.add(this.player.deadVector);
        this.location.captured = false;
        this.location.unit = null;
        this.location = null;
    }
    
    public ArrayList<GameAction> findActions(GameState state){
        
        ArrayList<GameAction> actionList = new ArrayList<GameAction>();
        GameAction action;
        if(!this.alive) return actionList;
        //find Transpositions and infantry/Knight attacks
        for(int i = 0;i<4;i++){
            action = new Transposition(this.location.x,this.location.z,i);
            //an pros mia kateuthinsi borei na ginei transposition den ginetai attack
            if(action.isValidAction(state)) actionList.add(action);
            else if(!(this instanceof Spearman)){
                action = new Attack(this.location.x,this.location.z,i);
                if(action.isValidAction(state)) actionList.add(action);
            }
        }
        //find Rorations
        for(int i =0;i<4;i++){
            action = new Rotation(this.location.x,this.location.z,i);
            if(action.isValidAction(state)) actionList.add(action);
        }
        //find Spearman Attacks
        if(this instanceof Spearman) for(int i =4;i<8;i++){
            action = new Attack(this.location.x,this.location.z,i);
            if(action.isValidAction(state)) actionList.add(action);
        }
        return actionList;
    }
    
    //xrisimopoieitai apo Spearman kai Infantry opou kanoun mia kinisi
    public ArrayList<GameAction[]> getPossibleActions(GameState state){
        if(this instanceof Knight)System.err.println("Unit.getPossibleAction illegal use from Knight");
        ArrayList<GameAction[]> actionList = new ArrayList<GameAction[]>();
        if(!this.alive) return actionList;
        ArrayList<GameAction> tempList = findActions(state);
        GameAction[] actionArray;
        for(GameAction tempAction:tempList){
            actionArray = new GameAction[1];
            actionArray[0] = tempAction;
            actionList.add(actionArray); 
        }
        //System.out.println("Unit.getPossibleActions Unit:"+this+" Number of action:"+actionList.size());
        return actionList;
    }
}
