/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygame.GameClasses.Actions;

import com.mygdx.rlstrategygame.GameClasses.BoardLocation;
import com.mygdx.rlstrategygame.GameClasses.GameState;
import com.mygdx.rlstrategygame.GameClasses.Units.Unit;

/**
 * Action that eliminates an opponent's pawn 
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class Attack extends GameAction{
    
    public static boolean isAttack(String string){
        //to string na ksekinaei apo "att"
        int index1 = string.indexOf("att");
        if(index1!=0)return false;
        //o tetartos xaraktiras na einai ','
        index1 = string.indexOf(',');
        if(index1!=3)return false;
        //an den iparxei deutero komma ','
        int index2 = string.indexOf(',',index1+1);
        if(index2==-1)return false;
        //an den iparxei deutero komma ','
        int index3 = string.indexOf(',',index2+1);
        if(index3==-1) return false;
        try{
            Integer.parseInt(string.substring(index1+1, index2));
            Integer.parseInt(string.substring(index2+1, index3));
            Integer.parseInt(string.substring(index3+1));
        }
        catch(NumberFormatException e){
            return false;
        }
        return true;
    }
    
    public Attack(int actingUnitX, int actingUnitZ,int direction) {
        super(actingUnitX, actingUnitZ);
        this.direction = direction;
    }
    
    public Attack(Unit unit,int direction) {
        super(unit.location.x, unit.location.z);
        this.direction = direction;
    }
    
    public Attack(String string){
        super(0,0);
        int index1 = string.indexOf(',');
        int index2 = string.indexOf(',',index1+1);
        int index3 = string.indexOf(',',index2+1);
        int x,z,d;
        x=Integer.parseInt(string.substring(index1+1, index2));
        z=Integer.parseInt(string.substring(index2+1, index3));
        d=Integer.parseInt(string.substring(index3+1));
        this.actingUnitX = x;
        this.actingUnitZ = z;
        this.direction = d;
    }
    
    //Checks if this attack can be perforded to this gameState
    public boolean isValid(GameState gameState){
        //int[] targetLocation = new int[2];
        BoardLocation targetLocation;
        //Game game = gameState.game;
        //i epithesi einai egkuri ws enegreia 
        if(!super.isValid(gameState))return false;
        //epithesi pros thesi ektws pistas
        //targetLocation = findNewLocation(game);
        targetLocation = gameState.locations[this.actingUnitX][this.actingUnitZ].next(this.direction);
        if(targetLocation == null) return false;
        //epithesi pros nogo thesi
        if(!targetLocation.canGo) return false;
        //epithesi pros mi katilimeni thesi
        if(!targetLocation.captured)return false;
        //epithesi se filio pioni
        Unit defenceUnit = targetLocation.unit;
        if(defenceUnit.player.id == gameState.activePlayer.id) return false;
        //epitrepomeni epithesi simfwna me konones paixnidiou
        Unit attackUnit = gameState.locations[this.actingUnitX][this.actingUnitZ].unit;
        if(!defenceUnit.canBeAttackedBy(attackUnit)) return false;
        return true;
    }
    
    public String toString(){
        return new String("att,"+this.actingUnitX+","+this.actingUnitZ+","+this.direction);
    }
}
