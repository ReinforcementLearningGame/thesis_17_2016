/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygamel.Intelligence;

import com.mygdx.rlstrategygamel.GameClasses.GameState;
import com.mygdx.rlstrategygamel.GameClasses.BoardLocation;
import com.mygdx.rlstrategygamel.GameClasses.Actions.GameAction;
import com.mygdx.rlstrategygamel.GameClasses.Actions.Transposition;
import com.mygdx.rlstrategygamel.GameClasses.Actions.Attack;
import com.mygdx.rlstrategygamel.GameClasses.Actions.Rotation;
import com.mygdx.rlstrategygamel.GameClasses.Units.Spearman;
import com.mygdx.rlstrategygamel.GameClasses.Units.Knight;
import com.mygdx.rlstrategygamel.GameClasses.Units.Unit;
import com.mygdx.rlstrategygamel.GameClasses.Units.Infantry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

/**
 * Implementation of intelligence class
 * Computer player plays in a preset orthological way. 
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class PresetIntelligence implements Intelligence{
    private static final int knightValue = 3;
    private static final int SpearmanValue = 2;
    private static final int InfantryValue = 1;

    private static Random random;
    
    public PresetIntelligence(){
        random = new Random();
        random.setSeed(System.currentTimeMillis());
    }
    
    public static float primaryValueFunction(GameState state){
        int AAUV=0; //Allied Alive Units
        int OAUV=0; //Enemy Alive Units
        int ARUV=0; //Alied Risk Units
        int ORUV=0; //Enemy Risk Units

        ArrayList<Unit[]> conflicts = new ArrayList<Unit[]>();
        
        boolean enemyFlagCapuredSafely = false;
        
        BoardLocation enemyFlag;
        //System.out.println(state.activePlayer);
        if(state.activePlayer.id ==0) enemyFlag = state.bluePlayer.flag;
        else enemyFlag = state.redPlayer.flag;
        
        ArrayList<Unit> units = new ArrayList<Unit>();
        units.addAll(Arrays.asList(state.redPlayer.units));
        units.addAll(Arrays.asList(state.bluePlayer.units));
        
        Unit defenceUnit;
        Unit attackUnit;
        int length = units.size();
        for(int i=0; i<length; i++){
            defenceUnit = units.get(i);
            if(!defenceUnit.alive) continue;
            int value;
            if(defenceUnit instanceof Knight) value = knightValue;
            else if(defenceUnit instanceof Spearman) value = SpearmanValue;
            else value = InfantryValue;
            
            
            //metraw ta alive pionia
            if(defenceUnit.player.equals(state.activePlayer)) AAUV+=value;   
            else{ OAUV+=value;
                //elegxw an to enemy pioni vrisketai stin allied simaia
                if(defenceUnit.location.equals( state.activePlayer.flag)) return 0;
            }
            
            //katagrfw poia pionia boroun na dextoun epithesi
            boolean safeUnit = true;
            for(int j=0; j<length; j++){
                attackUnit = units.get(j);
                if(!attackUnit.alive) continue;
                if(attackUnit.player.equals(defenceUnit.player)) continue;
                if(attackUnit.location.distance(defenceUnit.location)>2) continue;

                if(defenceUnit.canBeAttackedBy(attackUnit)) safeUnit = false;

                if(safeUnit && attackUnit instanceof Knight){
                    for(int direction=0; direction<4; direction++){
                        BoardLocation temp = attackUnit.location.next(direction);
                        if(temp==null ||! temp.canGo) continue;
                        Unit nextUnit = temp.unit;
                        if(nextUnit==null ||(nextUnit!=null && nextUnit.player.equals(defenceUnit.player) && nextUnit.face()!=attackUnit.location))//captured mono game oxi gamestate
                            for(int direction2=0; direction2<4; direction2++){
                                BoardLocation def = temp.next(direction2);
                                if(def!=null && def == defenceUnit.location && defenceUnit.face() !=temp){
                                    safeUnit = false;
                                    break;
                                }
                            }
                        if(!safeUnit) break;
                    }
                }
                //krataw ta pionia pou boroun na dextoun epithesi kai apo poia
                if(!safeUnit){
                    conflicts.add(new Unit[]{defenceUnit,attackUnit});
                    safeUnit = true;
                }  
            }
            //eksetazw tin periptwsi pou allied pioni bainei asfalws stin simaia andipalou    
            if(defenceUnit.player == state.activePlayer && defenceUnit.location==enemyFlag){
                if(conflicts.isEmpty()) enemyFlagCapuredSafely = true;
                else{
                    int last = conflicts.size()-1;
                    if(!defenceUnit.equals(conflicts.get(last)[0]))
                        enemyFlagCapuredSafely = true;
                }
            }  
        }
        
        if(enemyFlagCapuredSafely) return 1;
        
        length = conflicts.size();
        //afairw ta pionia tou active pou apeiloun alla dexondai kai apeili tautoxrona
        for(int i=0; i<length;i++){
            Unit attack = conflicts.get(i)[1];
            if(attack.player.equals(state.activePlayer)){
                for(int j=0; j<length; j++){
                    Unit defence = conflicts.get(j)[0];
                    if(defence==attack){
                        conflicts.remove(i);
                        length--;
                        i--;
                        break;
                    }
                }
            }
        }

        //metraw ta pionia pou vriskontai se kindino
        while(!conflicts.isEmpty()){
            int value;
            defenceUnit = conflicts.get(0)[0];
            if(defenceUnit instanceof Knight) value = knightValue;
            else if(defenceUnit instanceof Spearman) value = SpearmanValue;
            else value = InfantryValue;
            if(defenceUnit.player.equals(state.activePlayer))ARUV+=value; 
            else ORUV+=value;
            conflicts.remove(0);
        }

        return (float)(3*AAUV-ARUV)/(float)(3*(AAUV+OAUV)-ORUV);
    }
    
    public static float secondaryValueFunction(GameState state, GameAction[] action){
        int value = 0;
        int length = action.length;
        int distance;
        int attackDirection;
        BoardLocation unitLocation = state.locations[action[0].actingUnitX][action[0].actingUnitZ];
        BoardLocation flag;
        if(state.activePlayer.id ==0 ){
            flag = state.bluePlayer.flag;
            attackDirection=2;
        }
        else{
            flag = state.redPlayer.flag;
            attackDirection=0;
        }
        
        
        distance = unitLocation.distance(unitLocation.x,flag.z);
        
        for(int i=0; i<length; i++){
            if(action[i] instanceof Rotation);
            else if(action[i] instanceof Attack) value++;
            else if(action[i] instanceof Transposition)
                //kinisi pros ta mprosta
                if(unitLocation.next(action[i].direction).distance(action[i].actingUnitX,flag.z)<distance) value++;
                //otan exoume ftasei terma brosta kinoumaste pros tin simaia
                else if(unitLocation.z==flag.z&&unitLocation.distance(flag)>unitLocation.next(action[i].direction).distance(flag)) value++;
                //otan mprosta exoume mpodio kinoumaste dexia-aristera i allo pioni
                else if(unitLocation.next(attackDirection)!=null &&(!unitLocation.next(attackDirection).canGo||unitLocation.next(attackDirection).captured)&&action[i].direction/2==1) value++;
            
            unitLocation = unitLocation.next(action[i].direction);
        }
        return (float)value/(float)length;
    }
    
    public static float defenceStrength(GameState state){
        BoardLocation def1, def2;
        if(state.activePlayer.id == 0){
            def1 = state.redPlayer.flag.west;//Infantry Position
            def2= state.redPlayer.flag.next(5);//Spearman Position
        }
        else{
            def1 = state.bluePlayer.flag.east;//Infantry Position
            def2= state.bluePlayer.flag.next(7);//Spearman Position
        }
        int distance1 = state.game.Xmax+state.game.Zmax;
        int distance2 = state.game.Xmax+state.game.Zmax;
        int length = state.activePlayer.units.length;
        for(int i = 0;i<length;i++){
            Unit unit=state.activePlayer.units[i];
            if(!unit.alive) continue;
            
            if(unit instanceof Infantry ){
                int dist = unit.location.distance(def1);
                if(dist<distance1) distance1 = dist;
            }
            else if (unit instanceof Spearman){
                int dist = unit.location.distance(def2);
                if(dist<distance2) distance2 = dist;
            }
            
        }
        return (1-((float)(distance1+distance2)/(2*(state.game.Xmax+state.game.Zmax))));
    }
    
    public static ArrayList<GameAction[]> bestActions(GameState state,ArrayList<GameAction[]> actions){
        ArrayList<GameAction[]> best = new ArrayList<GameAction[]>();
        ArrayList<Float> strengthList = new ArrayList<Float>();
        float maxValue = 0;
        for(int actCount=0; actCount<actions.size(); actCount++){
            GameAction tempAction[]=actions.get(actCount);
            //ektelesi tis pithanes enegreis / energeiwn
            //GameState nextState = state.executeAndClone(tempAction[0]);
            state.perform(tempAction[0]);
            if(tempAction.length==2) state.perform(tempAction[1]);
            //if(tempAction.length==2) nextState = nextState.executeAndClone(tempAction[1]); //stin periptwsi alogou

            float value = primaryValueFunction(state);
            
            //diatiroume tis energeies me tin megaliteri timi
            if(value>=maxValue){
                if(value>maxValue){
                    maxValue = value; 
                    best.clear();
                    strengthList.clear();
                }
                best.add(tempAction);
                strengthList.add(defenceStrength(state));
            }
            state.undo();
        }
        //System.out.println("OptimizedIntelligence rewardfunction MaxValue "+maxValue +"-"+optimized.size());
        //se periptwsi isovathmias epilegei tis poio epithetikes kiniseis
        int length = best.size();
        if(length>1){
            boolean defence;
            //elegxos defenceStrength gia trexousa katastasi
            float currectDefenceStrength = defenceStrength(state);
            if(currectDefenceStrength==1) defence = false;
            else{

                int x = random.nextInt(2);
                //if(x%2==0) defence = true;
                if(x==0)defence = true;
                else defence = false;
            }
            //System.out.println("OptimizedIntelligence Defence Strength: "+currectDefenceStrength+"-Defence: "+defence);
            ArrayList<GameAction[]> best2 = new ArrayList<GameAction[]>();
            maxValue = 0;
            
            if(defence){
                for(int actCount=0; actCount<length; actCount++){
                    float value = strengthList.get(actCount);
                    if(value>=maxValue){
                        if(value>maxValue){
                            maxValue = value; 
                            best2.clear();
                        }
                        best2.add(best.get(actCount));
                    }
                }
                best = best2;
                best2 = new ArrayList<GameAction[]>();
                length = best.size();
            }
            maxValue = 0;
            for(int actCount=0; actCount<length; actCount++){
                GameAction action[]=best.get(actCount);
                float strength = strengthList.get(actCount);
                
                float value;
                
                if(strength<currectDefenceStrength) value = 0;//aporipsi kinisewn pou adinatizoun tin amina
                else value = secondaryValueFunction(state,action);
                
                if(value>=maxValue){
                    if(value>maxValue){
                        maxValue = value; 
                        best2.clear();
                    }
                    best2.add(action);
                }
            }
            //System.out.println("OptimizedIntelligence rewardfunction2 MaxValue "+maxValue);
            return best2;
        }
        return best;
    }
    
    @Override
    public GameAction[] decideAction(GameState state) {
        if(state.remainingMoves!=2)System.err.println("PresetIntelligence decideAction state.remeainigMoves!=2");


        
        //vriskei tis epomenes pithanes kiniseis
        ArrayList<GameAction[]> actions=state.findPossibleActions();

        
        //vriskei tis optimized kiniseis
        ArrayList<GameAction[]> optimized = bestActions(state, actions);

        if(optimized.isEmpty()){ 
            optimized = actions;
            System.err.println("PresetIntelligence - No optimized moves");
        }
        if(optimized.size()>0){
            int x = random.nextInt(optimized.size());
            return optimized.get(x);
        }
        else return null;
    }
    
    @Override
    public String toString(){
        return "Preset";
    }
}
