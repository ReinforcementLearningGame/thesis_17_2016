/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygamel.desktop;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Dialog;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.mygdx.rlstrategygamel.RL_Strategy_Game_L;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;

/**
 * Run the application for desktop
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class DesktopLauncher {
	public static LwjglApplicationConfiguration config;
    public static LwjglApplication application;
    private static int W ,H;
    public static void main (String[] arg) {      
        config = new LwjglApplicationConfiguration();
        GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
        config.width = gd.getDisplayMode().getWidth();
        config.height = gd.getDisplayMode().getHeight();
        config.title = "RL Strategy Game (Lightweight Version)";
        
        
        
        final RL_Strategy_Game_L render3D  = new RL_Strategy_Game_L();
        application = new LwjglApplication(render3D,config){
            //add question dialog: Are you sure you want to exit?
            @Override
            public void exit(){
                Skin skin = new Skin(Gdx.files.internal("uiskin.json"));
                
                final Dialog dialog = new Dialog("Are you sure you want to exit?",skin){
                    @Override
                    public float getPrefWidth() {
                        W = 400;
                        return W;
                    }

                    @Override
                    public float getPrefHeight() {
                        H = 100;
                        return H;
                    }
                };
                
                dialog.setModal(true);
                dialog.setMovable(false);
                dialog.setResizable(true);
                
                TextButton btnYes = new TextButton("Exit", skin);
                btnYes.setWidth(100);
                btnYes.setHeight(50);
                btnYes.setPosition(50, 20);
                btnYes.setColor(Color.valueOf("76B43C"));//green
                   // private Color selectColor = Color.valueOf("E34968");
   
                btnYes.addListener(new ClickListener() {
                    @Override
                    public boolean touchDown(InputEvent event, float x, float y,int pointer, int button) {
                        exitTheGame();
                        return true;
                    }

                });
                dialog.addActor(btnYes);
                
                TextButton btnNo = new TextButton("Cancel", skin);
                btnNo.setWidth(100);
                btnNo.setHeight(50);
                btnNo.setPosition(250, 20);
                btnNo.setColor(Color.valueOf("E34968"));//red
                btnNo.addListener(new ClickListener() {
                    @Override
                    public boolean touchDown(InputEvent event, float x, float y,int pointer, int button) {
                        dialog.remove();
                        return true;
                    }
                });
                dialog.addActor(btnNo);
                
                
                if(render3D.renderer.menuFlag) dialog.show(render3D.renderer.menuStage);
                else dialog.show(render3D.renderer.worldStage); 
            };
            
            private void exitTheGame(){
                if(render3D.renderer.backgroundThread!= null && render3D.renderer.backgroundThread.isAlive()) render3D.renderer.backgroundThread.stop();
                super.exit();
            }
        }; 
    }
}
