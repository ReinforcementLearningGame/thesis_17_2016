/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygame;

import com.mygdx.rlstrategygame.GameClasses.Settings;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.Touchable;
import com.badlogic.gdx.scenes.scene2d.ui.CheckBox;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.ProgressBar;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.scenes.scene2d.ui.TextField.TextFieldFilter;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.Array;
import java.awt.Component;
import java.awt.HeadlessException;
import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * The main menu of RL Strategy Game
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class MenuStage extends Stage{
    
    protected TextButton bnStartGame;
    protected Array<TextButton> bnSelectTrack;
    protected Array<TextButton> bnSelectRedPlayer;
    protected Array<TextButton> bnSelectBluePlayer;
    protected TextButton bnSelectGame;
    protected TextButton bnDisplayGame;
    protected JFileChooser displayGameChooser;
    protected Label lbSelectTrack;
    protected Label lbBluePlayer;
    protected Label lbRedPlayer;
    protected Label lbDisplayGame;
    protected Label lbDrawLimit;
    protected Label lbNumberOfGames;
    protected Label lbTotalVictories;
    protected Label lbVictoriesBlue;
    protected Label lbVictoriesRed;
    protected Label lbTotalDraw;
    protected Label lbStatistics;
    protected Label lbRedWins;
    protected Label lbBlueWins;
    protected Label lbDraw;
    protected Label lbAvgTurns;
    
    protected Label lbRedEGreedy;
    protected Label lbBlueEGreedy;
    protected Label lbRedLambda;
    protected Label lbBlueLambda;
    protected Label lbRedGamma;
    protected Label lbBlueGamma;
    protected Label lbMinReward;
    protected Label lbMaxReward;

    protected TextField tfDrawLimit;
    protected TextField tfNumberOfGames;
    protected TextField tfBlueVictories;
    protected TextField tfRedVictories;
    protected TextField tfTotalDraw;
    protected TextField tfRedWins;
    protected TextField tfBlueWins;
    protected TextField tfDraw;
    protected TextField tfAvgTurns;
    protected TextField tfRedEGreedy;
    protected TextField tfBlueEGreedy;
    protected TextField tfRedLambda;
    protected TextField tfBlueLambda;
    protected TextField tfRedGamma;
    protected TextField tfBlueGamma;
    protected TextField tfMinReward;
    protected TextField tfMaxReward;
    
    protected CheckBox cbGraphicsOn;
    protected CheckBox cbRedLearningOn;
    protected CheckBox cbBlueLearningOn;
    protected CheckBox cbRedEliminationReward;
    protected CheckBox cbBlueEliminationReward;
    protected ProgressBar pbVictories;
    
    protected Image eapLogo;

    //------ClickListeners----------------------------
    public ClickListener newGameListener;
    public ClickListener selectGameListener;
    public ClickListener displayGameListener;
    
    private Color deselectColor = Color.GRAY;
    private Color selectColor = Color.valueOf("E34968");
    private Color startColor = Color.valueOf("76B43C");
    
    /**
     * Constructor of Menu Stage 
     */
    public MenuStage(){
        super();
    }
    
    /**
     * Build the Menu Screen
     * @param gameSettings Settings of the game
     * @param skin skin for buttons of 2D graphics
     * @return Settings of the game
     */
    public Settings initialize(final Settings gameSettings, Skin skin){
        
        int W = Gdx.graphics.getWidth();
        int H = Gdx.graphics.getHeight();
        
        //------Label Red Player------------------------------------------
        lbRedPlayer = new Label("Red Player",skin);
        lbRedPlayer.setPosition(26*W/100, H-20*H/100);
        lbRedPlayer.setWidth(15*W/100);
        lbRedPlayer.setHeight(4*H/100);
        lbRedPlayer.setAlignment(0);
        this.addActor(lbRedPlayer);
        //------Label Blue Player------------------------------------------
        lbBluePlayer = new Label("Blue Player",skin);
        lbBluePlayer.setPosition(42*W/100, H-20*H/100);
        lbBluePlayer.setWidth(15*W/100);
        lbBluePlayer.setHeight(4*H/100);
        lbBluePlayer.setAlignment(0);
        this.addActor(lbBluePlayer);
        //------Label Select Track------------------------------------------
        lbSelectTrack = new Label("Select Track",skin);
        lbSelectTrack.setPosition(10*W/100, H-20*H/100);
        lbSelectTrack.setWidth(15*W/100);
        lbSelectTrack.setHeight(4*H/100);
        lbSelectTrack.setAlignment(0);
        
        this.addActor(lbSelectTrack);
        //-------Lista me pistes--------------------------------------------
        File folder = new File(gameSettings.getSource()+"/tracks");
        
        //Taxinomisi
        String[] arrayOfTracks = folder.list();
        
        bnSelectTrack = new Array<TextButton>();
        int i = 5;
        for(String temp:arrayOfTracks){
            TextButton bnTrack;
            String name = temp.substring(0, temp.length()-4);
            bnTrack = new TextButton(name, skin, "default");
            bnTrack.setName(name);
            bnTrack.setWidth(15*W/100);
            bnTrack.setHeight(4*H/100);
            bnTrack.setPosition(10*W/100, H-i*5*H/100);
            bnTrack.setColor(deselectColor);
            bnTrack.addListener(new ClickListener(){
                @Override 
                public void clicked(InputEvent event, float x, float y){
                    String tempName = event.getListenerActor().getName();
                    for(TextButton tempButton:bnSelectTrack){
                        if(tempButton.getName().equals(tempName)){
                            tempButton.setColor(selectColor);
                            gameSettings.setTrack(tempName);
                        }
                        else tempButton.setColor(deselectColor);
                    }
                }
            });
            this.addActor(bnTrack);
            bnSelectTrack.add(bnTrack);
            i++;
        }

        String[] Players = new String[]{"Human", "CPU Random", "CPU Attack", "CPU Defence", "CPU Preset", "CPU RL"};
        //-----Lista me Red Players-----------------------------------------
        bnSelectRedPlayer = new Array<TextButton>();
        i = 5;
        for(String temp:Players){
            TextButton bnPlayer;
            bnPlayer = new TextButton(temp, skin, "default");
            bnPlayer.setName(temp);
            bnPlayer.setWidth(15*W/100);
            bnPlayer.setHeight(4*H/100);
            bnPlayer.setPosition(26*W/100, H-i*5*H/100);
            bnPlayer.setColor(deselectColor);
            bnPlayer.addListener(new ClickListener(){
                @Override 
                public void clicked(InputEvent event, float x, float y){
                    String tempName = event.getListenerActor().getName();
                    
                    cbRedLearningOn.setChecked(false);
                    setRedLearnigOff(gameSettings);
                    if(tempName.startsWith("CPU RL")) {
                        cbRedLearningOn.setTouchable(Touchable.enabled);
                        gameSettings.redAI = true;
                    }
                    else {
                        cbRedLearningOn.setTouchable(Touchable.disabled);
                        gameSettings.redAI = false;
                    }
                    
                    if(tempName.equals("Human")&&!cbGraphicsOn.isChecked()) return;
                    
                    for(TextButton tempButton:bnSelectRedPlayer){
                        if(tempButton.getName().equals(tempName)){
                            tempButton.setColor(selectColor);
                            gameSettings.setRedPlayer(tempName);
                        }
                        else tempButton.setColor(deselectColor);
                    }
                }
            });
            bnSelectRedPlayer.add(bnPlayer);
            this.addActor(bnPlayer);
            i++;
        }
        //-----Lista me Blue Players-----------------------------------------
        bnSelectBluePlayer = new Array<TextButton>();
        i = 5;
        for(String temp:Players){
            TextButton bnPlayer;
            bnPlayer = new TextButton(temp, skin, "default");
            bnPlayer.setName(temp);
            bnPlayer.setWidth(15*W/100);
            bnPlayer.setHeight(4*H/100);
            bnPlayer.setPosition(42*W/100, H-i*5*H/100);
            bnPlayer.setColor(deselectColor);
            bnPlayer.addListener(new ClickListener(){
                @Override 
                public void clicked(InputEvent event, float x, float y){
                    String tempName = event.getListenerActor().getName();
                    
                    cbBlueLearningOn.setChecked(false);
                    setBlueLearnigOff(gameSettings);
                    if(tempName.startsWith("CPU RL")) {
                        cbBlueLearningOn.setTouchable(Touchable.enabled);
                        gameSettings.blueAI = true;
                    }
                    else {
                        cbBlueLearningOn.setTouchable(Touchable.disabled);
                        gameSettings.blueAI = false;
                    }
                    
                    if(tempName.equals("Human")&&!cbGraphicsOn.isChecked()) return;
                    
                    for(TextButton tempButton:bnSelectBluePlayer){
                        if(tempButton.getName().equals(tempName)){
                            tempButton.setColor(selectColor);
                            gameSettings.setBluePlayer(tempName);

                        }
                        else tempButton.setColor(deselectColor);
                    }
                }
            });
            bnSelectBluePlayer.add(bnPlayer);
            this.addActor(bnPlayer);
            i++;
        }
        //----Button Start game--------------------------------------------
        bnStartGame = new TextButton("Start Game",skin, "default");
        bnStartGame.setWidth(15*W/100);
        bnStartGame.setHeight(4*H/100);
        bnStartGame.setPosition(59*W/100, H-25*H/100);
        bnStartGame.setColor(startColor);
        bnStartGame.addListener(newGameListener);

        this.addActor(bnStartGame);
        //----Button Display Game--------------------------------------------
        bnDisplayGame = new TextButton("Display Game",skin, "default");
        bnDisplayGame.setWidth(15*W/100);
        bnDisplayGame.setHeight(4*H/100);
        bnDisplayGame.setPosition(75*W/100, H-25*H/100);
        bnDisplayGame.setColor(startColor);
        bnDisplayGame.addListener(displayGameListener);
        this.addActor(bnDisplayGame);
        //----Button Select Game--------------------------------------------
        
        
        bnSelectGame = new TextButton("Select Game",skin, "default");
        bnSelectGame.setWidth(15*W/100);
        bnSelectGame.setHeight(4*H/100);
        bnSelectGame.setPosition(75*W/100, H-30*H/100);
        bnSelectGame.setColor(Color.GRAY);
        bnSelectGame.addListener(selectGameListener);
        this.addActor(bnSelectGame);
        //------CheckBox Graphics On------------------------------------------
        cbGraphicsOn = new CheckBox("Graphics On",skin);
        cbGraphicsOn.setPosition(59*W/100, H-35*H/100);
        cbGraphicsOn.addListener(new ClickListener(){
            @Override 
            public void clicked(InputEvent event, float x, float y){
                if(cbGraphicsOn.isChecked()){
                    cbGraphicsOn.setText("Graphics On");
                    gameSettings.setGraphicsOn(true);
                    gameSettings.setLoggingOn(true);
                    tfNumberOfGames.setDisabled(true);
                    tfNumberOfGames.setText("");
                    //kanei olwn twn eidwn tous paiktes Touchable
                    /*int length = bnSelectBluePlayer.size;
                    for(int i=0;i<length;i++){
                        TextButton tempButton = bnSelectBluePlayer.get(i);
                        tempButton.setTouchable(Touchable.enabled);
                    }
                    length = bnSelectRedPlayer.size;
                    for(int i=0;i<length;i++){
                        TextButton tempButton = bnSelectRedPlayer.get(i);
                        tempButton.setTouchable(Touchable.enabled);
                    }*/
                }
                else{
                    cbGraphicsOn.setText("Graphics Off");
                    gameSettings.setGraphicsOn(false);
                    gameSettings.setLoggingOn(false);
                    tfNumberOfGames.setDisabled(false);
                    tfNumberOfGames.setText("100");
                    //kanei tous Human paiktes Not Touchable
                    int length = bnSelectBluePlayer.size;
                    for(int i=0;i<length;i++){
                        TextButton tempButton = bnSelectBluePlayer.get(i);
                        if(tempButton.getColor().equals(selectColor)){
                            if(tempButton.getText().toString().equals("Human")){
                                tempButton.setColor(Color.GRAY);
                                //tempButton.setTouchable(Touchable.disabled);
                                tempButton = bnSelectBluePlayer.get(++i);
                                tempButton.setColor(selectColor);
                                gameSettings.setBluePlayer(tempButton.getText().toString());
                            }
                            break;
                        }
                    }

                    length = bnSelectRedPlayer.size;
                    for(int i=0;i<length;i++){
                        TextButton tempButton = bnSelectRedPlayer.get(i);
                        if(tempButton.getColor().equals(selectColor)){
                            if(tempButton.getText().toString().equals("Human")){
                                tempButton.setColor(Color.GRAY);
                                //tempButton.setTouchable(Touchable.disabled);
                                tempButton = bnSelectRedPlayer.get(++i);
                                tempButton.setColor(selectColor);
                                gameSettings.setRedPlayer(tempButton.getText().toString());
                            }
                            break;
                        }
                    }
                }

            }
        });
        this.addActor(cbGraphicsOn);
        
        //cbGraphicsOn.setTouchable(Touchable.disabled);
        //------Label Draw Limit------------------------------------------
        lbDrawLimit = new Label("Draw Limit",skin);
        lbDrawLimit.setPosition(59*W/100, H-30*H/100);
        //lbDrawLimit.setWidth(15*W/100);
        lbDrawLimit.setHeight(4*H/100);
        this.addActor(lbDrawLimit);
        
        //------Text Field Draw Limit------------------------------------------
        this.tfDrawLimit = new TextField("200",skin);
        this.tfDrawLimit.setPosition(67*W/100, H-30*H/100);
        this.tfDrawLimit.setSize(7*W/100, 4*H/100);
        this.tfDrawLimit.setTextFieldFilter(new TextFieldFilter.DigitsOnlyFilter());
        this.tfDrawLimit.setMaxLength(4);
        this.addActor(tfDrawLimit);
        
        //------Label Number Of Games------------------------------------------
        this.lbNumberOfGames = new Label("Games",skin);
        this.lbNumberOfGames.setPosition(59*W/100, H-40*H/100);
        //this.lbNumberOfGames.setWidth(9*W/100);
        this.lbNumberOfGames.setHeight(4*H/100);
        this.addActor(this.lbNumberOfGames);
        
        //------Text Field Number Of Games-------------------------------------
        this.tfNumberOfGames = new TextField("",skin);
        this.tfNumberOfGames.setPosition(67*W/100, H-40*H/100);
        this.tfNumberOfGames.setSize(7*W/100, 4*H/100);
        this.tfNumberOfGames.setTextFieldFilter(new TextFieldFilter.DigitsOnlyFilter());
        this.tfNumberOfGames.setMaxLength(6);
        this.addActor(this.tfNumberOfGames);
        
        //------Label Min Reward------------------------------------------------       
        this.lbMinReward = new Label("Min Reward:",skin);
        this.lbMinReward.setPosition(75*W/100, H-35*H/100);
        this.lbMinReward.setSize(7*W/100, 4*H/100);
        this.addActor(this.lbMinReward);
        
        //------TextField Min Reward--------------------------------------------
        this.tfMinReward = new TextField("-1.0",skin);
        this.tfMinReward.setPosition(83*W/100, H-35*H/100);
        this.tfMinReward.setSize(7*W/100, 4*H/100);
        this.tfMinReward.setMaxLength(5);
        this.addActor(this.tfMinReward);     
        
        //------Label Max Reward------------------------------------------------        
        this.lbMaxReward = new Label("Max Reward:",skin);
        this.lbMaxReward.setPosition(75*W/100, H-40*H/100);
        this.lbMaxReward.setSize(7*W/100, 4*H/100);
        this.addActor(this.lbMaxReward);
        
        //------TextField Min Reward--------------------------------------------
        this.tfMaxReward = new TextField("1.0",skin);
        this.tfMaxReward.setPosition(83*W/100, H-40*H/100);
        this.tfMaxReward.setSize(7*W/100, 4*H/100);
        this.tfMaxReward.setMaxLength(5);
        this.addActor(this.tfMaxReward);            
        //------CheckBox Red Learning On------------------------------------------
        this.cbRedLearningOn = new CheckBox("Learning Off",skin);
        this.cbRedLearningOn.setPosition(26*W/100, H-55*H/100);
        this.cbRedLearningOn.setChecked(false);
        this.cbRedLearningOn.setTouchable(Touchable.disabled);
        this.cbRedLearningOn.addListener(new ClickListener(){
            @Override 
            public void clicked(InputEvent event, float x, float y){
                if(cbRedLearningOn.isChecked()&& (!gameSettings.bluePlayer.equals(gameSettings.redPlayer) || !cbBlueLearningOn.isChecked()))setRedLearnigOn(gameSettings);
                else{
                    cbRedLearningOn.setChecked(false);
                    setRedLearnigOff(gameSettings);
                }
            }
        });
        this.addActor(cbRedLearningOn);
        
        //------CheckBox Blue Learning On-----------------------------------------
        
        this.cbBlueLearningOn = new CheckBox("Learning Off",skin);
        this.cbBlueLearningOn.setPosition(42*W/100, H-55*H/100);
        this.cbBlueLearningOn.setChecked(false);
        this.cbBlueLearningOn.setTouchable(Touchable.disabled);
        this.cbBlueLearningOn.addListener(new ClickListener(){
            @Override 
            public void clicked(InputEvent event, float x, float y){
                
                if(cbBlueLearningOn.isChecked() && (!gameSettings.redPlayer.equals(gameSettings.bluePlayer) || !cbRedLearningOn.isChecked())) setBlueLearnigOn(gameSettings);
                else{
                    cbBlueLearningOn.setChecked(false);
                    setBlueLearnigOff(gameSettings);
                }
            }
        });
        this.addActor(cbBlueLearningOn);
        
        //------Label Red EGreedy------------------------------------------
        
        this.lbRedEGreedy = new Label("e-greedy",skin);
        this.lbRedEGreedy.setPosition(26*W/100, H-60*H/100);
        this.addActor(lbRedEGreedy);
        
        //------Text Field Red EGreedy--------------------------------------
        
        this.tfRedEGreedy = new TextField("1",skin);
        this.tfRedEGreedy.setPosition(34*W/100, H-60*H/100);
        this.tfRedEGreedy.setSize(7*W/100, 4*H/100);
        this.tfRedEGreedy.setMaxLength(5);
        //this.tfRedEGreedy.setTouchable(Touchable.disabled);
        this.addActor(tfRedEGreedy);
        
        //------Label Blue EGreedy------------------------------------------
        
        this.lbBlueEGreedy = new Label("e-greedy",skin);
        this.lbBlueEGreedy.setPosition(42*W/100, H-60*H/100);
        this.addActor(lbBlueEGreedy);
        
        //------Text Field Blue EGreedy--------------------------------------
        
        this.tfBlueEGreedy = new TextField("1",skin);
        this.tfBlueEGreedy.setPosition(50*W/100, H-60*H/100);
        this.tfBlueEGreedy.setSize(7*W/100, 4*H/100);
        this.tfBlueEGreedy.setMaxLength(5);
        //this.tfBlueEGreedy.setTouchable(Touchable.disabled);
        this.addActor(tfBlueEGreedy);
        
        //------Label Red Lambda------------------------------------------
        
        this.lbRedLambda = new Label("lambda",skin);
        this.lbRedLambda.setPosition(26*W/100, H-65*H/100);
        this.addActor(lbRedLambda);
        
        //------Text Field Red Lambda--------------------------------------
        
        this.tfRedLambda = new TextField("0",skin);
        this.tfRedLambda.setPosition(34*W/100, H-65*H/100);
        this.tfRedLambda.setSize(7*W/100, 4*H/100);
        this.tfRedLambda.setMaxLength(5);
        //this.tfRedLambda.setTouchable(Touchable.disabled);
        this.addActor(tfRedLambda);
        
        //------Label Blue Lambda------------------------------------------
        
        this.lbBlueLambda = new Label("lambda",skin);
        this.lbBlueLambda.setPosition(42*W/100, H-65*H/100);
        this.addActor(lbBlueLambda);

        //------Text Field Blue Lambda--------------------------------------
        
        this.tfBlueLambda = new TextField("0",skin);
        this.tfBlueLambda.setPosition(50*W/100, H-65*H/100);
        this.tfBlueLambda.setSize(7*W/100, 4*H/100);
        this.tfBlueLambda.setMaxLength(5);
        //this.tfBlueLambda.setTouchable(Touchable.disabled);
        this.addActor(tfBlueLambda);
        
        //------Label Red Gamma------------------------------------------
        
        this.lbRedGamma = new Label("gamma",skin);
        this.lbRedGamma.setPosition(26*W/100, H-70*H/100);
        this.addActor(lbRedGamma);
        
        //------Text Field Red Gamma--------------------------------------
        
        this.tfRedGamma = new TextField("0",skin);
        this.tfRedGamma.setPosition(34*W/100, H-70*H/100);
        this.tfRedGamma.setSize(7*W/100, 4*H/100);
        this.tfRedGamma.setMaxLength(5);
        //this.tfRedGamma.setTouchable(Touchable.disabled);
        this.addActor(tfRedGamma);
        
        //------Label Blue Gamma------------------------------------------
        
        this.lbBlueGamma = new Label("gamma",skin);
        this.lbBlueGamma.setPosition(42*W/100, H-70*H/100);
        this.addActor(lbBlueGamma);
        
        //------Text Field Blue Gamma--------------------------------------
        
        this.tfBlueGamma = new TextField("0",skin);
        this.tfBlueGamma.setPosition(50*W/100, H-70*H/100);
        this.tfBlueGamma.setSize(7*W/100, 4*H/100);
        this.tfBlueGamma.setMaxLength(4);
        //this.tfBlueGamma.setTouchable(Touchable.disabled);
        this.addActor(tfBlueGamma);
        
        //-----CheckBox Red Elimination Reward-----------------------------
        
        this.cbRedEliminationReward = new CheckBox("Elimination Reward",skin);
        this.cbRedEliminationReward.setPosition(26*W/100, H-75*H/100);
        this.cbRedEliminationReward.setChecked(true);
        this.cbRedEliminationReward.setTouchable(Touchable.disabled);
        this.cbRedEliminationReward.addListener(new ClickListener(){
            @Override 
            public void clicked(InputEvent event, float x, float y){
                
                
            }
        });
        this.addActor(cbRedEliminationReward);
        
        //-----CheckBox Blue Elimination Reward-----------------------------
        
        this.cbBlueEliminationReward = new CheckBox("Elimination Reward",skin);
        this.cbBlueEliminationReward.setPosition(42*W/100, H-75*H/100);
        this.cbBlueEliminationReward.setChecked(true);
        this.cbBlueEliminationReward.setTouchable(Touchable.disabled);
        this.cbBlueEliminationReward.addListener(new ClickListener(){
            @Override 
            public void clicked(InputEvent event, float x, float y){
                
                
            }
        });
        this.addActor(cbBlueEliminationReward);

        //------Label Total Victories------------------------------------------
        this.lbTotalVictories = new Label("Total Victories",skin);
        this.lbTotalVictories.setPosition(59*W/100, H-45*H/100);
        this.lbTotalVictories.setHeight(4*H/100);
        this.lbTotalVictories.setWidth(31*W/100);
        this.lbTotalVictories.setAlignment(0);
        this.addActor(this.lbTotalVictories);
        
        //------Label Blue Victories------------------------------------------
        this.lbVictoriesBlue = new Label("Blue",skin);
        this.lbVictoriesBlue.setPosition(70*W/100, H-50*H/100);
        this.lbVictoriesBlue.setHeight(4*H/100);
        this.lbVictoriesBlue.setWidth(9*W/100);
        this.lbVictoriesBlue.setAlignment(0);
        this.addActor(this.lbVictoriesBlue);
        
        //------Label Red Victories------------------------------------------
        this.lbVictoriesRed = new Label("Red",skin);
        this.lbVictoriesRed.setPosition(59*W/100, H-50*H/100);
        this.lbVictoriesRed.setHeight(4*H/100);
        this.lbVictoriesRed.setWidth(9*W/100);
        this.lbVictoriesRed.setAlignment(0);
        this.addActor(this.lbVictoriesRed);
        
        //------Label Total Draw---------------------------------------------
        this.lbTotalDraw = new Label("Draws",skin);
        this.lbTotalDraw.setPosition(81*W/100, H-50*H/100);
        this.lbTotalDraw.setHeight(4*H/100);
        this.lbTotalDraw.setWidth(9*W/100);
        this.lbTotalDraw.setAlignment(0);
        this.addActor(this.lbTotalDraw);
        
        //------Text Field Blue Victories-------------------------------------
        this.tfBlueVictories = new TextField("",skin);
        this.tfBlueVictories.setPosition(70*W/100, H-55*H/100);
        this.tfBlueVictories.setSize(9*W/100, 4*H/100);
        this.tfBlueVictories.setTextFieldFilter(new TextFieldFilter.DigitsOnlyFilter());
        this.tfBlueVictories.setDisabled(true);
        this.tfBlueVictories.setMaxLength(6);
        this.addActor(this.tfBlueVictories);
        
        //------Text Field Red Victories-------------------------------------
        this.tfRedVictories = new TextField("",skin);
        this.tfRedVictories.setPosition(59*W/100, H-55*H/100);
        this.tfRedVictories.setSize(9*W/100, 4*H/100);
        this.tfRedVictories.setTextFieldFilter(new TextFieldFilter.DigitsOnlyFilter());
        this.tfRedVictories.setDisabled(true);
        this.tfRedVictories.setMaxLength(6);
        this.addActor(this.tfRedVictories);
        
        //------Text Field Total Draws-------------------------------------
        this.tfTotalDraw = new TextField("",skin);
        this.tfTotalDraw.setPosition(81*W/100, H-55*H/100);
        this.tfTotalDraw.setSize(9*W/100, 4*H/100);
        this.tfTotalDraw.setTextFieldFilter(new TextFieldFilter.DigitsOnlyFilter());
        this.tfTotalDraw.setDisabled(true);
        this.tfTotalDraw.setMaxLength(6);
        this.addActor(this.tfTotalDraw);
        
        //-----ProgressBar------------------------------------------------------
        this.pbVictories = new ProgressBar(0,100,1,false,skin);
        this.pbVictories.setPosition(59*W/100, H-60*H/100);
        this.pbVictories.setSize(31*W/100, 4*H/100);
        this.pbVictories.setColor(Color.GREEN);
        this.addActor(this.pbVictories);
        
        //-----Label statistics-----
        
        this.lbStatistics = new Label("Statistics",skin);
        this.lbStatistics.setPosition(59*W/100, H-65*H/100);
        this.lbStatistics.setSize(31*W/100, 4*H/100);
        this.lbStatistics.setAlignment(0);
        this.addActor(this.lbStatistics);
        
        //----- Label Red Wins ---------
        
        this.lbRedWins = new Label("Red Wins",skin);
        this.lbRedWins.setPosition(59*W/100, H-70*H/100);
        this.lbRedWins.setSize(7*W/100, 4*H/100);
        this.lbRedWins.setAlignment(0);
        this.addActor(this.lbRedWins);
        
        //----- Label Blue Wins ---------
        
        this.lbBlueWins = new Label("Blue Wins",skin);
        this.lbBlueWins.setPosition(67*W/100, H-70*H/100);
        this.lbBlueWins.setSize(7*W/100, 4*H/100);
        this.lbBlueWins.setAlignment(0);
        this.addActor(this.lbBlueWins);
        
        //----- Label Draw ---------
        
        this.lbDraw = new Label("Draws",skin);
        this.lbDraw.setPosition(75*W/100, H-70*H/100);
        this.lbDraw.setSize(7*W/100, 4*H/100);
        this.lbDraw.setAlignment(0);
        this.addActor(this.lbDraw);
        
        //----- Label Average Turns ---------
        
        this.lbAvgTurns = new Label("Avg Turns",skin);
        this.lbAvgTurns.setPosition(83*W/100, H-70*H/100);
        this.lbAvgTurns.setSize(7*W/100, 4*H/100);
        this.lbAvgTurns.setAlignment(0);
        this.addActor(this.lbAvgTurns);
        
        //----- Text Field Red Wins ---------
        this.tfRedWins = new TextField("",skin);
        this.tfRedWins.setPosition(59*W/100, H-75*H/100);
        this.tfRedWins.setSize(7*W/100, 4*H/100);

        this.tfRedWins.setDisabled(true);

        this.addActor(this.tfRedWins);
        
                
        //----- Text Field Blue Wins ---------
        this.tfBlueWins = new TextField("",skin);
        this.tfBlueWins.setPosition(67*W/100, H-75*H/100);
        this.tfBlueWins.setSize(7*W/100, 4*H/100);

        this.tfBlueWins.setDisabled(true);

        this.addActor(this.tfBlueWins);
        
        //----- Text Field Draws --------------
        this.tfDraw = new TextField("",skin);
        this.tfDraw.setPosition(75*W/100, H-75*H/100);
        this.tfDraw.setSize(7*W/100, 4*H/100);

        this.tfDraw.setDisabled(true);

        this.addActor(this.tfDraw);
        
        //----- Text Field Avg Turns --------------
        this.tfAvgTurns = new TextField("",skin);
        this.tfAvgTurns.setPosition(83*W/100, H-75*H/100);
        this.tfAvgTurns.setSize(7*W/100, 4*H/100);

        this.tfAvgTurns.setDisabled(true);

        this.addActor(this.tfAvgTurns);
        
        //------EAP Logo Image---------
        Texture texture = new Texture(Gdx.files.internal(gameSettings.getSource()+"/Logo.jpg")); 
        this.eapLogo = new Image (texture);
        this.eapLogo.setPosition(0, H-15*H/100);
        this.eapLogo.setSize(W, 15*H/100);
        this.addActor(this.eapLogo);
        // beltiwnei ta grafika tou displayGameChooser
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(WorldRendererAndController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(WorldRendererAndController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(WorldRendererAndController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnsupportedLookAndFeelException ex) {
            Logger.getLogger(WorldRendererAndController.class.getName()).log(Level.SEVERE, null, ex);
        }

        displayGameChooser = new JFileChooser(){
            @Override // gia na exoume ton parathiro brosta apo ta alla parathira
            protected JDialog createDialog(Component parent) throws HeadlessException {
                // intercept the dialog created by JFileChooser
                JDialog dialog = super.createDialog(parent);
                dialog.setAlwaysOnTop(true);
                return dialog;
                }
             };
        displayGameChooser.setCurrentDirectory(new java.io.File(gameSettings.getSource()+"/logging"));
        displayGameChooser.setDialogTitle("Display Saved Game");
        
        return this.defaultValues(gameSettings);
    }
    
    /**
     * return settings to default values and menu stage to default condition
     * @param gameSettings current settings
     * @return default settings
     */
    public Settings defaultValues(Settings gameSettings){
        //-----defaults-----------------------------------------------------
        for(TextButton tempButton:bnSelectTrack) tempButton.setColor(deselectColor);
        for(TextButton tempButton:bnSelectRedPlayer) tempButton.setColor(deselectColor);
        for(TextButton tempButton:bnSelectBluePlayer) tempButton.setColor(deselectColor);
        // default epileges einai oi prwtes
        TextButton tempButton = bnSelectTrack.first();
        tempButton.setColor(selectColor);
        gameSettings.setTrack(tempButton.getName());
        tempButton = bnSelectRedPlayer.first();
        tempButton.setColor(selectColor);
        gameSettings.setRedPlayer(tempButton.getName());
        tempButton = bnSelectBluePlayer.first();
        tempButton.setColor(selectColor);
        gameSettings.setBluePlayer(tempButton.getName());

        gameSettings.redAI = false;
        gameSettings.blueAI = false;

        this.cbRedLearningOn.setTouchable(Touchable.disabled);
        this.cbBlueLearningOn.setTouchable(Touchable.disabled);
        this.cbRedLearningOn.setChecked(false);
        this.cbBlueLearningOn.setChecked(false);
        
        this.cbRedEliminationReward.setChecked(false);
        this.cbBlueEliminationReward.setChecked(false);
        
        this.setRedLearnigOff(gameSettings);
        this.setBlueLearnigOff(gameSettings);

        gameSettings.setLoggingOn(true);
        this.cbGraphicsOn.setChecked(true);
        this.tfNumberOfGames.setText("");
        this.tfNumberOfGames.setDisabled(true);
        gameSettings.setGraphicsOn(true);
        this.tfDrawLimit.setText("200");
        gameSettings.setDrawLimit(this.tfDrawLimit.getText().toString());
        
        this.pbVictories.setValue(0);
        this.lbStatistics.setText("Statistics");
        this.tfRedVictories.setText("");
        this.tfRedWins.setText("");
        this.tfBlueVictories.setText("");
        this.tfBlueWins.setText("");
        this.tfDraw.setText("");
        this.tfTotalDraw.setText("");
        this.tfAvgTurns.setText("");

        return gameSettings;
        
        //System.out.println("Default menu");
    }
    
    /**
     * Automatic changes when disabling the learning of blue player
     * @param gameSettings current settings of the game
     */
    private void setBlueLearnigOff(Settings gameSettings){
        cbBlueLearningOn.setText("Learning Off");
        gameSettings.blueLearning = false;
        tfBlueEGreedy.setDisabled(true);
        tfBlueLambda.setDisabled(true);
        tfBlueGamma.setDisabled(true);
        cbBlueEliminationReward.setTouchable(Touchable.disabled);
        cbBlueEliminationReward.setChecked(false);
        tfBlueEGreedy.setText("1");
        tfBlueLambda.setText("0");
        tfBlueGamma.setText("0");
    }
    
    /**
     * Automatic changes when enabling the learning of blue player
     * @param gameSettings current settings of the game
     */
    private void setBlueLearnigOn(Settings gameSettings){
        cbBlueLearningOn.setText("Learning On");
        gameSettings.blueLearning = true;
        tfBlueEGreedy.setDisabled(false);
        tfBlueLambda.setDisabled(false);
        tfBlueGamma.setDisabled(false);
        cbBlueEliminationReward.setTouchable(Touchable.enabled);
        cbBlueEliminationReward.setChecked(true);
        tfBlueEGreedy.setText("0.9");
        tfBlueLambda.setText("0.7");
        tfBlueGamma.setText("0.9");
    }
    
    /**
     * Automatic changes when disabling the learning of red player
     * @param gameSettings current settings of the game
     */
    private void setRedLearnigOff(Settings gameSettings){
        cbRedLearningOn.setText("Learning Off");
        gameSettings.redLearning = false;
        tfRedEGreedy.setDisabled(true);
        tfRedLambda.setDisabled(true);
        tfRedGamma.setDisabled(true);
        cbRedEliminationReward.setTouchable(Touchable.disabled);
        cbRedEliminationReward.setChecked(false);
        tfRedEGreedy.setText("1");
        tfRedLambda.setText("0");
        tfRedGamma.setText("0");
    }
    
    /**
     * Automatic changes when enabling the learning of red player
     * @param gameSettings current settings of the game
     */
    private void setRedLearnigOn(Settings gameSettings){
        cbRedLearningOn.setText("Learning On");
        gameSettings.redLearning = true;
        tfRedEGreedy.setDisabled(false);
        tfRedLambda.setDisabled(false);
        tfRedGamma.setDisabled(false);
        cbRedEliminationReward.setTouchable(Touchable.enabled);
        cbRedEliminationReward.setChecked(true);
        tfRedEGreedy.setText("0.9");
        tfRedLambda.setText("0.7");
        tfRedGamma.setText("0.9");
    }
    
    public synchronized void setRedVictories(int wins){
        this.tfRedVictories.setText(Integer.toString(wins));
    }
    
    public synchronized void setBlueVictories(int wins){
        this.tfBlueVictories.setText(Integer.toString(wins));
    }
    
    public synchronized void setTotalDraws(int draw){
        this.tfTotalDraw.setText(Integer.toString(draw));
    }
    
    public synchronized void setProgressBar(float percentage){
        this.pbVictories.setValue(100*percentage);
    }
    
    public synchronized void setStatistics(String statistics){
        this.lbStatistics.setText(statistics);
    }
    
    public synchronized void setRedWins(double wins){
        this.tfRedWins.setText(Double.toString(wins));
    }
    
    public void setBlueWins(double wins){
        this.tfBlueWins.setText(Double.toString(wins));
    }
    
    public synchronized void setDraws(double draw){
        this.tfDraw.setText(Double.toString(draw));
    }
    
    public synchronized void setAvgTurns(double turns){
        this.tfAvgTurns.setText(Double.toString(turns));
    }
    
    public void resetResults(){
        this.tfRedVictories.setText("");
        this.tfBlueVictories.setText("");
        this.tfTotalDraw.setText("");
        this.pbVictories.setValue(0);
    }
}
