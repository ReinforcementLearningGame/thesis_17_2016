/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygamel.Intelligence;

import com.mygdx.rlstrategygamel.GameClasses.BoardLocation;
import com.mygdx.rlstrategygamel.GameClasses.Actions.GameAction;
import com.mygdx.rlstrategygamel.GameClasses.GameState;
import com.mygdx.rlstrategygamel.GameClasses.Units.Knight;
import com.mygdx.rlstrategygamel.GameClasses.Actions.Rotation;
import com.mygdx.rlstrategygamel.GameClasses.Actions.Transposition;
import com.mygdx.rlstrategygamel.GameClasses.Units.Unit;
import static com.mygdx.rlstrategygamel.Intelligence.AttackIntelligence.attackActions;
import com.mygdx.rlstrategygamel.GameClasses.Players.Player;
import java.util.ArrayList;
import java.util.Random;

/**
 * Implementation of intelligence class
 * Computer player tries to protect their pawns, eliminate opponent,
 * or plays randomly
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class DefenceIntelligence implements Intelligence{
    
    Random random;
    
    public DefenceIntelligence(){
        random = new Random();
        random.setSeed(System.currentTimeMillis());
    }
    
    public static ArrayList<GameAction[]> saferActions(GameState state,ArrayList<GameAction[]> actions){
        ArrayList<GameAction[]> safe = new ArrayList<GameAction[]>();
        int riskLevel = state.activePlayer.units.length;
        for(int actCount=0; actCount<actions.size(); actCount++){
            GameAction tempAction[]=actions.get(actCount);
            //ektelesi tis pithanis enegreis / energeiwn
            //GameState nextState = state.executeAndClone(tempAction[0]);
            state.perform(tempAction[0]);
            if(tempAction.length==2) state.perform(tempAction[1]); //stin periptwsi alogou

            //evresi arithmou pioniwn pou kindineuoun me tin sigekrimeni energeia
            
            Player attackPlayer;
            if(state.activePlayer.id == 0) attackPlayer = state.bluePlayer;
            else attackPlayer = state.redPlayer;
            
            int unsafeUnits = 0;
            for(int i = 0;i<state.activePlayer.units.length;i++){
                boolean safeUnit = true;
                Unit defenceUnit = state.activePlayer.units[i];
                if(!defenceUnit.alive) continue;
                
                for(int j = 0;j<attackPlayer.units.length;j++){
                    Unit attackUnit = attackPlayer.units[j];
                    if(!attackUnit.alive) continue;
                    
                    if(defenceUnit.canBeAttackedBy(attackUnit)){ 
                        safeUnit = false;
                        break;
                    }
                    
                    if(attackUnit instanceof Knight && attackUnit.location.distance(defenceUnit.location)<3){
                        for(int i2=0; i2<4; i2++){
                            BoardLocation temp = attackUnit.location.next(i2);
                            if(temp==null ||! temp.canGo) continue;
                            Unit nextUnit = temp.unit;
                            if(nextUnit==null ||(nextUnit!=null && nextUnit.player.equals(state.activePlayer) && nextUnit.face()!=attackUnit.location))//captured mono game oxi gamestate
                                for(int j2=0; j2<4; j2++){
                                    BoardLocation def = temp.next(j2);
                                    if(def!=null && def == defenceUnit.location && defenceUnit.face() !=temp){
                                        safeUnit = false;
                                        break;
                                    }
                                }
                            if(!safeUnit) break;
                        }
                    }
                    if(!safeUnit) break;
                }
                if(!safeUnit){
                    unsafeUnits++;
                    //System.out.println("DefenceIntelligence defenceUnit "+defenceUnit);
                }
            }
            //diatiroume tis energeies me ton mikrotero arithmo kindineuwn pioniwn
            if(unsafeUnits<=riskLevel){
                if(unsafeUnits<riskLevel){
                    //System.out.println("DefenceIntelligence: riskLevel reduction to: "+riskLevel);
                    riskLevel = unsafeUnits; 
                    safe.clear();
                }
                safe.add(tempAction);
            }
            state.undo();
        }
        //System.out.println("DefenceIntelligence: riskLevel: "+riskLevel);
        return safe;
    }
    
    public static ArrayList<GameAction[]> closerFlagActions(GameState state, ArrayList<GameAction[]> actions){
        ArrayList<GameAction[]> closerFlag = new ArrayList<GameAction[]>();
        int minDistance = Integer.MAX_VALUE;
        Player enemy;
        if(state.activePlayer.id == 0) enemy = state.bluePlayer;
        else enemy = state.redPlayer;
        for(int actCount=0; actCount<actions.size(); actCount++){
            GameAction tempAction[]=actions.get(actCount);
            BoardLocation startLocation = state.locations[tempAction[0].actingUnitX][tempAction[0].actingUnitZ];
            BoardLocation endLocation;
            if(!(tempAction[0] instanceof Rotation)) endLocation = startLocation.next(tempAction[0].direction);
            else endLocation = startLocation;
            //GameState nextState = state.executeAndClone(tempAction[0]);

            if(tempAction.length==2){
                //nextState = nextState.executeAndClone(tempAction[1]);
                //System.out.println(tempAction[1].direction);
                if(!(tempAction[1] instanceof Rotation))endLocation = endLocation.next(tempAction[1].direction);
                //if(endLocation==null) System.out.println("Null");
            } //stin periptwsi alogou
            int startDistance = enemy.flag.distance(startLocation);
            int distance = enemy.flag.distance(endLocation);
            if(distance<startDistance && distance<=minDistance){
                if(distance<minDistance){
                    minDistance = distance; 
                    closerFlag.clear();
                }
                closerFlag.add(tempAction);
            }
        }
        return closerFlag;
    }
    
    public static ArrayList<GameAction[]> transpositionActions(ArrayList<GameAction[]> actions){
        ArrayList<GameAction[]> transpositions = new ArrayList<GameAction[]>();
        for(GameAction tempAction[]:actions)
            if(tempAction[0] instanceof Transposition)
                transpositions.add(tempAction);
        return transpositions;
    }
    
    @Override
    public GameAction[] decideAction(GameState state) {
        if(state.remainingMoves!=2)System.err.println("DefeceIntelligence decideAction state.remeainigMoves!=2");

        
        //vriskei tis epomenes pithanes kiniseis
        ArrayList<GameAction[]> actions=state.findPossibleActions();

        
        //krataei tis kiniseiw me to mikrotero risko
        ArrayList<GameAction[]> safe = saferActions(state, actions);
        
        ArrayList<GameAction[]> optimized = attackActions(safe);
        if(optimized.isEmpty()) optimized = transpositionActions(safe);
        if(optimized.isEmpty()) optimized = safe;
        
        int x = random.nextInt(optimized.size());
        return optimized.get(x);
    }
    
    @Override
    public String toString(){
        return "Defence";
    }
}
