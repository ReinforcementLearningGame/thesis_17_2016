/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygame.Intelligence;

import com.mygdx.rlstrategygame.GameClasses.Actions.Attack;
import com.mygdx.rlstrategygame.GameClasses.Game;
import com.mygdx.rlstrategygame.GameClasses.Actions.GameAction;
import com.mygdx.rlstrategygame.GameClasses.GameState;
import com.mygdx.rlstrategygame.GameClasses.Actions.Rotation;
import com.mygdx.rlstrategygame.GameClasses.Settings;
import com.mygdx.rlstrategygame.GameClasses.Actions.Transposition;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Implementation of intelligence class
 * Computer player reads their next move from a log file, in order to repeat an old game.
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class DisplayFromFile implements Intelligence{

    private static boolean validFile = false;
    private static int counter;
    private static ArrayList<String> input;
    
    //eisagei sta settings tis pista pou diavazei apo to display file kai pairnei tis enegries se string
    public static boolean loadFile(String diplayFile,Settings settings){
        counter=0;
        String track = null;
        FileInputStream fis = null;
        input = new ArrayList<String>();
        //diavasma arxeiou se array of strings
        try {
            fis = new FileInputStream(diplayFile);
            BufferedReader br = new BufferedReader(new InputStreamReader(fis));
            String line;
            try {
                int i = 0;
                boolean actions = false;
                while((line = br.readLine())!=null){
                    if(actions)input.add(line);
                    else{
                        if(i==0) track = line;
                        else if(line.startsWith("start")) actions = true;
                    }
                    i++;
                }
                br.close();
            } 
            catch (IOException ex) {
                validFile = false;
                return validFile;
            }
        }
        catch (FileNotFoundException ex) {
            Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
            validFile = false;
            return validFile;
        }
        finally {
            try {fis.close();}
            catch (Exception ex) {}
        }
        //Afairesi full path tis pistas se periptwsi pou exei kratithei
        if(track.lastIndexOf('/')!=-1){
            track = track.substring(track.lastIndexOf('/')+1);
            track = track.substring(0,track.lastIndexOf(".txt"));
        }
        settings.setTrack(track);
        validFile = true;
        return validFile;
    }

    public static boolean isValid(){
        return validFile;
    }
    
    @Override
    public GameAction[] decideAction(GameState state) {
        GameAction[] resultActions;
        String inputAction;
        int size = input.size();
        boolean undoFlag;
        do{
            undoFlag = false;
            do{
                if(counter>=size) return null;
                inputAction = input.get(counter);
                counter++;
            }while(inputAction.startsWith("undo"));
            GameAction action = null;
            if(inputAction.startsWith("tra"))action = new Transposition(inputAction);
            else if(inputAction.startsWith("att")) action = new Attack(inputAction);
            else if(inputAction.startsWith("rot")) action = new Rotation(inputAction);
            if(action==null){
                System.err.println("File is corrupted - not an action: "+inputAction);
                return null;
            }
            GameState newState = state.performAndClone(action);
            if(newState == null){
                System.err.println("File is corrupted - invalid action 1: "+action.toString());
                return null;
            }
            
            if(newState.remainingMoves!=0){
                resultActions = new GameAction[2];
                resultActions[0] = action;
                
                inputAction = input.get(counter);
                if(inputAction.startsWith("undo")) undoFlag=true;
                else{
                    if(inputAction.startsWith("tra"))action = new Transposition(inputAction);
                    else if(inputAction.startsWith("att")) action = new Attack(inputAction);
                    else if(inputAction.startsWith("rot")) action = new Rotation(inputAction);
                    newState = newState.performAndClone(action);
                    if(newState == null){
                        System.err.println("File is corrupted - invalid action 2");
                        return null;
                    }
                    resultActions[1] = action;
                }
                counter++;
                
            }else{
                resultActions = new GameAction[1];
                resultActions[0] = action;
            }
            if(!undoFlag){
                //elegxos gia undo meta tin oloklirwsi tis kinisis
                if(counter>=size) return resultActions;
                inputAction = input.get(counter);
                if(inputAction.startsWith("undo")){
                    if((inputAction.startsWith("undo red")&&state.activePlayer.id==0)
                   ||(inputAction.startsWith("undo blue")&&state.activePlayer.id==1)){
                        undoFlag=true;
                        counter++;
                    }
                }
            }
        } while(undoFlag);
        return resultActions;
    }
    
    @Override
    public String toString(){
        return "Display";
    }
}