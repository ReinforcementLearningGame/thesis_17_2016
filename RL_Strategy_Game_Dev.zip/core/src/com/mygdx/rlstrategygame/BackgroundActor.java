/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygame;

import com.mygdx.rlstrategygame.GameClasses.Game;
import com.mygdx.rlstrategygame.GameClasses.GameLogger;
import com.mygdx.rlstrategygame.GameClasses.Settings;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.Touchable;
import java.text.DecimalFormat;
import java.util.Date;

/**
 * Play games in background in a different thread
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class BackgroundActor implements Runnable {
    int totalNumberOfGames;
    long totalTurns;
    Settings gameSettings;
    MenuStage menuStage;
    GameLogger logger;
    Thread menuThread;
    int stageRefresh;
    
    public static volatile boolean running;
            
    public BackgroundActor(Settings gameSettings, MenuStage menuStage, Thread menuThread){
        this.running = true;
        this.stageRefresh = gameSettings.getNumberOfGames()/100;
        this.logger = new GameLogger(gameSettings.getSource()+"/logging/BackgroundGames");
        this.totalNumberOfGames = gameSettings.getNumberOfGames();
        this.gameSettings = gameSettings;
        this.menuStage = menuStage;
        this.menuThread = menuThread;
        
        
    }
    
    @Override
    public void run(){
        
        String track = gameSettings.getTrackPath();
        track = track.substring(track.lastIndexOf('/')+1);
        track = track.substring(0,track.lastIndexOf(".txt"));
        this.logger.write("Track: "+track);
        logger.write("Red Player: "+gameSettings.redPlayer);
        if(gameSettings.redAI){
            logger.write("\tLearning: "+gameSettings.redLearning);
            logger.write("\te-greedy: "+gameSettings.getRedEGreedy());
            logger.write("\tlambda: "+gameSettings.getRedLambda());
            logger.write("\tgamma: "+gameSettings.getRedGamma());
            if(gameSettings.getRedEliminationReward())logger.write("\telimination reward: true");
            else logger.write("\telimination reward: false");
        }
        logger.write("Blue Player: "+gameSettings.bluePlayer);
        if(gameSettings.blueAI){
            logger.write("\tLearning: "+gameSettings.blueLearning);
            logger.write("\te-greedy: "+gameSettings.getBlueEGreedy());
            logger.write("\tlambda: "+gameSettings.getBlueLambda());
            logger.write("\tgamma: "+gameSettings.getBlueGamma());
            if(gameSettings.getBlueEliminationReward())logger.write("\telimination reward: true");
            else logger.write("\telimination reward: false");
        }
        logger.write("Min Reward: "+gameSettings.getMinReward());
        logger.write("Max Reward: "+gameSettings.getMaxReward());
        logger.write("Number Of Games: "+totalNumberOfGames);
        logger.write("---Data---");
        
        Game game=null;
        
        int refreshCounter = 0 ;
        int draw = 0;
        int blueWin = 0;
        int redWin = 0;
        int turns = 0;
                
        int totalDraw = 0;
        int totalBlueWin = 0;
        int totalRedWin = 0;
        long totalTurns = 0;
        
        DecimalFormat df = new DecimalFormat("##0.00");
        
        long lStartTime = new Date().getTime();
        for(int i = 0;i<totalNumberOfGames;i++){
            game = new Game(gameSettings);
            //if(gameSettings.redNeuralNet==null) System.err.println("GameShedule:Game:"+i+" Red Null");
            //if(gameSettings.blueNeuralNet==null) System.err.println("GameShedule Game:"+i+" Blue Null");             
            game.playTheGame();
           
            gameSettings.updateNeuralNetworks();
            
            if(game.currentState.gameOver){
                
                if(game.currentState.winner == null)draw++;
                else if(game.currentState.winner.id == 0) redWin++;
                else if(game.currentState.winner.id == 1) blueWin++;
 
                turns+=gameSettings.getDrawLimit()-game.currentState.remainingTurns;

            }
            refreshCounter++;
            if(refreshCounter>=stageRefresh || i==this.totalNumberOfGames-1){
                
                logger.write(i+1+"\t"+df.format(redWin*100/(float)refreshCounter)+"\t"+df.format(blueWin*100/(float)refreshCounter)
                        +"\t"+df.format(draw*100/(float)refreshCounter)+"\t"+df.format(turns/(float)refreshCounter));
                
                
                menuThread.suspend();
                
                menuStage.setStatistics("Statistics for last "+refreshCounter+" games");
                
                totalTurns+=turns;
                //menuStage.setAvgTurns(df.format(turns/(float)refreshCounter));
                menuStage.setAvgTurns(Math.round(100d*(turns/(float)refreshCounter))/100d);
                turns=0;
                totalDraw+=draw;
                //menuStage.setDraws(df.format(draw*100/(float)refreshCounter));
                menuStage.setDraws(Math.round(100d*(draw*100/(float)refreshCounter))/100d);
                draw = 0;
                totalRedWin+=redWin;
                //menuStage.setRedWins(df.format(redWin*100/(float)refreshCounter));
                menuStage.setRedWins(Math.round(100d*(redWin*100/(float)refreshCounter))/100d);
                redWin=0;
                totalBlueWin+=blueWin;
                //menuStage.setBlueWins(df.format(blueWin*100/(float)refreshCounter));
                menuStage.setBlueWins(Math.round(100d*(blueWin*100/(float)refreshCounter))/100d);
                blueWin=0;
                
                refreshCounter = 0;
                
                menuStage.setTotalDraws(totalDraw);
                menuStage.setRedVictories(totalRedWin);
                menuStage.setBlueVictories(totalBlueWin);
                menuStage.setProgressBar((float)(i+1)/(float)totalNumberOfGames);
                
                menuThread.resume();
                Gdx.graphics.setContinuousRendering(true);
            }
        }
        long lEndTime = new Date().getTime();
        float difference = (lEndTime - lStartTime)/(float)1000;
        
        logger.write("---Summary---");
        logger.write("Red WIns: "+totalRedWin);
        logger.write("Blue WIns: "+totalBlueWin);
        logger.write("Draws: "+totalDraw);
        logger.write("Total Turns: "+totalTurns);
        logger.write("Time: "+difference+" sec");
        logger.write("Turns/sec: "+((float)totalTurns/(float)difference));
        
        //System.out.println("Blue WIns:"+totalBlueWin+" - Red WIns:"+totalRedWin+" - Draws:"+totalDraw+" - Total Turns:"+totalTurns+" - Time:"+difference+" sec - Turns/sec:"+((float)totalTurns/(float)difference));
        this.running = false;
        
        gameSettings.saveNeuralNetworks();
        gameSettings.redNeuralNet = null;
        gameSettings.blueNeuralNet = null;
        
        Color startColor = Color.valueOf("76B43C");
        
        //menuStage.bnStartGame.setTouchable(Touchable.enabled);
        menuStage.bnStartGame.setColor(startColor);
        menuStage.bnStartGame.setText("Start Game");
        
        menuStage.bnDisplayGame.setTouchable(Touchable.enabled);
        menuStage.bnDisplayGame.setColor(startColor);
        //menuStage.bnDisplayGame.setText("Dispay Game");
        
        Gdx.graphics.setContinuousRendering(true);
    }
}
