/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygame.GameClasses.Players;

import com.mygdx.rlstrategygame.GameClasses.BoardLocation;
import com.mygdx.rlstrategygame.GameClasses.Actions.GameAction;
import com.mygdx.rlstrategygame.GameClasses.GameState;
import com.mygdx.rlstrategygame.GameClasses.Settings;
import com.mygdx.rlstrategygame.Intelligence.*;
import javafx.geometry.Point2D;

/**
 * The class computer players
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class ComputerPlayer extends Player{
    
    private boolean thinking;
    private boolean ready;
    //thinking false, ready false-- den exei trigaristei
    //thinking true, ready false-- exei trigaristei skeftetai to apotelesma den einai etoimo
    //thinking false, ready true-- den etoimo apotelesma
    private GameAction[] action;
    private Intelligence intelligence;
    private int currentActionId;
    
    
    public ComputerPlayer(int id, BoardLocation flag,String intelligence,Point2D boardSize) {
        super(id, flag,boardSize);
        //System.out.println("inteligence: "+intelligence);
        if(intelligence.equals("Random"))this.intelligence = new RandomIntelligence();
        else if (intelligence.equals("Attack"))this.intelligence = new AttackIntelligence();
        else if (intelligence.equals("Defence"))this.intelligence = new DefenceIntelligence();
        else if (intelligence.equals("Preset"))this.intelligence = new PresetIntelligence();
        else if (intelligence.equals("DisplayFromFile"))this.intelligence = new DisplayFromFile();
        else if (intelligence.startsWith("RL")); //Artificial Intelligence will be initialize later //this.intelligence = new ArtificialIntelligence(gameSettings,id,boardSize,intelligence);
        else{
            this.intelligence = new RandomIntelligence();
            System.out.println("Intelligence: "+intelligence+" does not exist - default inteligence is Random");
        }
    }
    
    public ComputerPlayer(ComputerPlayer temp,BoardLocation flag,Point2D limits) {
        super(temp.id,flag, limits);
        this.thinking = temp.thinking;
        this.ready = temp.ready;
        this.action = temp.action;
        this.intelligence = temp.intelligence;
    }
    
    public void initializeAI(Settings gameSettings, GameState initialState){
        //Den ftiaxnw tin artificial Intelligence me ton constructor tou paikti
        //giati thelw na parei ta pionia prwta
        this.intelligence = new ArtificialIntelligence(gameSettings,this,initialState);
    }
    
    public void finalizeAI(GameState finalState){
        if(this.intelligence instanceof ArtificialIntelligence){
            ArtificialIntelligence temp = (ArtificialIntelligence) this.intelligence;
            //System.out.println("Computer Player finalize AI");
            temp.finalize(finalState);
        }
   
    }
    
    public boolean isNotTriged(){
        return(!thinking&&!ready);
    }
    
    public boolean isThinking(){
        return(thinking&&!ready);
    }
    
    public boolean isReady(){
        return(!thinking&&ready);
    }
    
    public void trig(GameState state){
        if(this.isThinking())return;
        //System.out.println("ComputerPlayer Trigggggggggggggggggggggggggggggggggggggggggggggggg");
        //allagi katastasis ComputerPlayer player se thinking
        this.thinking = true; this.ready=false;
        action = intelligence.decideAction(state);
        //if(action==null)System.out.println("No Actionssssssssssssssssssssssssssssss");
        this.currentActionId = 0;
        //allagi katastasis ComputerPlayer player se ready
        if(action!=null) this.thinking = false; this.ready=true;
    }
    
    public GameAction getAction(){
        if(!this.isReady()) return null;
        GameAction current = null;
        if(this.currentActionId<action.length){
            current = action[this.currentActionId];
            this.currentActionId++;
        }
        //allagi katastasis ComputerPlayer player se notTriged
        if(this.currentActionId==action.length){
            this.thinking = false;
            this.ready = false;
        }
        return current;
    }
    public void clearActions(){
        this.action = null;
    }
    @Override
    public String toString(){
        return "CPU " + this.intelligence.toString();
    }
}
