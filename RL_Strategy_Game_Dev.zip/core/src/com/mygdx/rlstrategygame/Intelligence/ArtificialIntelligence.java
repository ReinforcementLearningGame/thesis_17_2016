/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygame.Intelligence;

import com.mygdx.rlstrategygame.GameClasses.Players.ComputerPlayer;
import com.mygdx.rlstrategygame.GameClasses.Actions.GameAction;
import com.mygdx.rlstrategygame.GameClasses.GameState;
import com.mygdx.rlstrategygame.GameClasses.Settings;
import com.mygdx.rlstrategygame.RL_Agents.RLAgent;
import com.mygdx.rlstrategygame.RL_Agents.TDAgent;

/**
 * Implementation of intelligence class
 * Computer player uses a TD Agent to decide their actions
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class ArtificialIntelligence implements Intelligence {

    RLAgent agent;
    boolean learnig;
    
    public ArtificialIntelligence(Settings gameSettings, ComputerPlayer player, GameState initialState){
        
        String intelligenceType;
        if(player.id==0){
            intelligenceType = gameSettings.redPlayer.substring(4);
            learnig = gameSettings.redLearning;
        }
        else{
            intelligenceType = gameSettings.bluePlayer.substring(4);
            learnig = gameSettings.blueLearning;
        }
        
        if(intelligenceType.equals("RL")) this.agent = new TDAgent(gameSettings,player.id,initialState);
        this.agent.initialize(initialState);
        
    }
    
    @Override
    public GameAction[] decideAction(GameState state) {
        GameAction[] choosenActions = agent.chooseAction(state.findPossibleActions(), state);
        if(learnig){
            agent.updateCurrentReward(state);
            agent.learnFromAction(state, choosenActions);
        }
        return choosenActions;
    }
    
    public void finalize(GameState finalState){
        if(!learnig){
            agent.endOfGame();
            return;
        }
        //System.out.println("ArtificialIntelligence-test");
        if(!finalState.gameOver) return;

        agent.updateCurrentReward(finalState);
        //System.out.println("ArtificialIntelligence - finalize Reward:"+agent.currentReward);
        agent.learnFromAfterstate(finalState);
        agent.endOfGame();
    }
    
    @Override
    public String toString(){
        return "Artificial";
    }
}
