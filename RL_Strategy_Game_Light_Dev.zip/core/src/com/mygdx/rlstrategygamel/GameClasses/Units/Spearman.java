/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygamel.GameClasses.Units;

import com.mygdx.rlstrategygamel.GameClasses.BoardLocation;
import com.mygdx.rlstrategygamel.GameClasses.Players.Player;

/**
 * The class for pawn type "Spearman"
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class Spearman extends Unit{
    
    private static int movingCost = 2;
    
    public Spearman (BoardLocation location,int direction,Player player){
        super(location,direction,player);
        super.movingCost = movingCost;
    }
    public Spearman (BoardLocation location,int direction,Player player,boolean alive,int id){
        super(location,direction,player,alive,id);
        super.movingCost = movingCost;
    }
    
    public void moveNorthEast(){
        this.location.unit = null;
        this.location.captured = false;
        this.location = this.location.north.east;
        this.location.captured = true;
        this.location.unit = this;
        this.turnEast();
    }
    
    public void moveNorthWest(){
        this.location.unit = null;
        this.location.captured = false;
        this.location = this.location.north.west;
        this.location.captured = true;
        this.location.unit = this;
        this.turnWest();
    }
    
    public void moveSouthEast(){
        this.location.unit = null;
        this.location.captured = false;
        this.location = this.location.south.east;
        this.location.captured = true;
        this.location.unit = this;
        this.turnEast();
    }
    
    public void moveSouthWest(){
        this.location.unit = null;
        this.location.captured = false;
        this.location = this.location.south.west;
        this.location.captured = true;
        this.location.unit = this;
        this.turnWest();
    }
}
