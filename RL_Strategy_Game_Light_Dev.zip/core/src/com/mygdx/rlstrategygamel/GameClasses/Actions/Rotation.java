/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygamel.GameClasses.Actions;

import com.mygdx.rlstrategygamel.GameClasses.GameState;
import com.mygdx.rlstrategygamel.GameClasses.Units.Knight;
import com.mygdx.rlstrategygamel.GameClasses.Units.Unit;


/**
 * Action that rotates the selected pawn
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class Rotation extends GameAction{

    public static boolean isRotation(String string){
        //to string na ksekinaei apo "rot"
        int index1 = string.indexOf("rot");
        if(index1!=0)return false;
        //o tetartos xaraktiras na einai ','
        index1 = string.indexOf(',');
        if(index1!=3)return false;
        //an den iparxei deutero komma ','
        int index2 = string.indexOf(',',index1+1);
        if(index2==-1)return false;
        //an den iparxei deutero komma ','
        int index3 = string.indexOf(',',index2+1);
        if(index3==-1) return false;
        try{
            Integer.parseInt(string.substring(index1+1, index2));
            Integer.parseInt(string.substring(index2+1, index3));
            Integer.parseInt(string.substring(index3+1));
        }
        catch(NumberFormatException e){
            return false;
        }
        return true;
    }
    
    public Rotation(int actingUnitX, int actingUnitZ,int direction) {
        super(actingUnitX, actingUnitZ);
        this.direction = direction;
    }
    
    public Rotation(Unit unit,int direction) {
        super(unit.location.x, unit.location.z);
        this.direction = direction;
    }
    
    public Rotation(String string){
        super(0,0);//antikathistatai apo katw
        int index1 = string.indexOf(',');
        int index2 = string.indexOf(',',index1+1);
        int index3 = string.indexOf(',',index2+1);
        int x,z,d;
        x=Integer.parseInt(string.substring(index1+1, index2));
        z=Integer.parseInt(string.substring(index2+1, index3));
        d=Integer.parseInt(string.substring(index3+1));
        this.actingUnitX = x;
        this.actingUnitZ = z;
        this.direction = d;
    }
    
    //Checks if this rotation can be perforded to this gameState
    public boolean isValid(GameState gameState){
        //i peristrofi einai egkuri ws enegreia 
        if(!super.isValid(gameState))return false;
        //i teliki kateuthinsi einai idia me tin arxiki
        //System.out.println("Rotation.isValid GetUnit call for Rotationg Unit");
        Unit rotatingUnit = gameState.locations[this.actingUnitX][this.actingUnitZ].unit;
        if(rotatingUnit.direction == this.direction) return false;
        //alogo prospathei na ksekinisei me peristrofi
        if(rotatingUnit instanceof Knight && gameState.remainingMoves==2) return false;
        return true;
    }
    
    public String toString(){
        return new String("rot,"+this.actingUnitX+","+this.actingUnitZ+","+this.direction);
    }
}
