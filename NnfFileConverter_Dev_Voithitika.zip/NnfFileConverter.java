/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nnffileconverter;
import java.awt.Component;
import java.awt.HeadlessException;
import java.io.*;
import java.util.ArrayList;
import java.util.Collection;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import org.apache.commons.io.*;
import org.apache.commons.io.filefilter.DirectoryFileFilter;
import org.apache.commons.io.filefilter.RegexFileFilter;
 /**
 *
 * @author alexandros
 */
public class NnfFileConverter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
        // TODO code application logic here
        JFileChooser convertFileChooser = new JFileChooser(){
            @Override // gia na exoume ton parathiro brosta apo ta alla parathira
            protected JDialog createDialog(Component parent) throws HeadlessException {
                // intercept the dialog created by JFileChooser
                JDialog dialog = super.createDialog(parent);
                dialog.setAlwaysOnTop(true);
                return dialog;
                }
             };
        convertFileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        convertFileChooser.showOpenDialog(convertFileChooser);
        
        
        File dir = new File(convertFileChooser.getSelectedFile().getAbsolutePath());
        System.out.println(dir.getAbsolutePath());
        
        //Collection fileList = FileUtils.listFiles(dir, new RegexFileFilter("*.nnf"), DirectoryFileFilter.DIRECTORY);
        
        
        ArrayList<File> files = new  ArrayList<File>();
        nnfFileColector(files,dir);
        for(int k=0;k<files.size();k++){
            
            FileInputStream stream = new FileInputStream(files.get(k));
            String filePath = files.get(k).getAbsolutePath();
            //----------read format1--------------------------------------------
            /*ObjectInputStream in = new ObjectInputStream(stream);
            
            int nrOfInputNodes = (Integer) in.readObject();
            int nrOfHiddenNodes = (Integer) in.readObject();        
            int nrOfOutputNodes = (Integer) in.readObject();
            //System.out.println("nrOfInputNodes: " + nrOfInputNodes+" nrOfHiddenNodes: "+nrOfHiddenNodes+" nrOfOutputNodes: "+nrOfOutputNodes);
            //then load the weights of the network
            double[][] w = (double[][]) in.readObject();
            double[][] v = (double[][]) in.readObject();
            double[][] ew = (double[][]) in.readObject();
            double[][][] ev = (double[][][]) in.readObject();
            in.close();
            */
            
            //----------read format2--------------------------------------------
            DataInputStream in = new DataInputStream(stream);
            
            int nrOfInputNodes = (Integer) in.readInt();
            int nrOfHiddenNodes = (Integer) in.readInt();        
            int nrOfOutputNodes = (Integer) in.readInt();
            
            double w[][] = new double[nrOfHiddenNodes+1][nrOfOutputNodes];
            double v[][] = new double[nrOfInputNodes+1][nrOfHiddenNodes+1];
            //loading the weights
            for (int i=0;i<=nrOfHiddenNodes;i++)
                for (int j=0; j<nrOfOutputNodes;j++)
                    w[i][j] = in.readDouble();
            for (int i=0;i<=nrOfInputNodes;i++)
                for (int j=0; j<=nrOfHiddenNodes;j++)
                    v[i][j] = in.readDouble();
            in.close();
            
            //-------------write format 2---------------------------------------------
            /*
            DataOutputStream out = new DataOutputStream( new FileOutputStream(filePath));
            out.writeInt(nrOfInputNodes);
            out.writeInt(nrOfHiddenNodes);
            out.writeInt(nrOfOutputNodes);
            for (int i=0;i<=nrOfHiddenNodes;i++)
                for (int j=0; j<nrOfOutputNodes;j++)
                     out.writeDouble(w[i][j]);
            for (int i=0;i<=nrOfInputNodes;i++)
                for (int j=0; j<=nrOfHiddenNodes;j++)
                        out.writeDouble(v[i][j]);
            out.close();
            */
            
            //-------------write format 3---------------------------------------------
            FileWriter fw = new FileWriter(filePath+"t",false);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.append(nrOfInputNodes +",");
            bw.append(nrOfHiddenNodes +",");
            bw.append(nrOfOutputNodes +",");
            
            for (int i=0;i<=nrOfHiddenNodes;i++)
                for (int j=0; j<nrOfOutputNodes;j++)
                    bw.append(w[i][j]+",");
            for (int i=0;i<=nrOfInputNodes;i++)
                for (int j=0; j<=nrOfHiddenNodes;j++)
                    bw.append(v[i][j]+",");
            bw.close();
            
        }   
    }
    private static void nnfFileColector(ArrayList<File> files, File dir){
        File[] faFiles = dir.listFiles();
        for(File cur:faFiles){
            if(cur.getName().endsWith(".nnf"))files.add(cur);
            else if(cur.isDirectory())nnfFileColector(files,cur);
        }
        
    }
}
