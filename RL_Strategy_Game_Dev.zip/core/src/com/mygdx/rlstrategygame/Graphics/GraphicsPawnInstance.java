/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygame.Graphics;

import com.mygdx.rlstrategygame.GameClasses.Units.Unit;
import com.badlogic.gdx.graphics.g3d.Model;

/**
 * An instance of a 3D pawn model
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class GraphicsPawnInstance extends GraphicsInstance {

    protected Unit unit;
    //private Point3D graphicsPoint;
    protected int graphicsDirection;
    public GraphicsPawnInstance(Model model, String rootNode, boolean mergeTransform, Unit unit) {
        super(model, rootNode, mergeTransform);
        this.unit = unit;
        //this.graphicsPoint = new Point3D(this.unit.location.x,0,this.unit.location.z);
        this.graphicsDirection = unit.direction*90;
    }
    
    public void moveNorthImmediately()
    {
        this.turnNorthImmediately();
        this.transform.translate(0, GraphicsGame.size, 0);
    }
    
    public void moveSouthImmediately()
    {
        this.turnSouthImmediately();
        this.transform.translate(0, GraphicsGame.size, 0);
    }
    
    public void moveEastImmediately()
    {
        this.turnEastImmediately();
        this.transform.translate(0, GraphicsGame.size, 0);
        
    }
    
    public void moveWestImmediately()
    {
        this.turnWestImmediately();
        this.transform.translate(0, GraphicsGame.size, 0);
    }
    public void turnNorthImmediately()
    {
        this.transform.rotate(0, 0, 1,90*(0-this.unit.direction));
        this.graphicsDirection = 0;
    }
    
    public void turnSouthImmediately()
    {
        this.transform.rotate(0, 0, 1,90*(2-this.unit.direction));
        this.graphicsDirection = 180;
    }
    
    public void turnEastImmediately()
    {
        this.transform.rotate(0, 0, 1,90*(3-this.unit.direction));
        this.graphicsDirection = 270;
    }
    
    public void turnWestImmediately()
    {
        this.transform.rotate(0, 0, 1,90*(1-this.unit.direction));
        this.graphicsDirection = 90;
    }
    
}
