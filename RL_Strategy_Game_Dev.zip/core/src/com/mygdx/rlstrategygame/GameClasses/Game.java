/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygame.GameClasses;

import com.mygdx.rlstrategygame.GameClasses.Actions.GameAction;
import com.mygdx.rlstrategygame.GameClasses.Players.ComputerPlayer;
import com.mygdx.rlstrategygame.GameClasses.Players.HumanPlayer;
import com.mygdx.rlstrategygame.GameClasses.Units.Spearman;
import com.mygdx.rlstrategygame.GameClasses.Units.Knight;
import com.mygdx.rlstrategygame.GameClasses.Units.Infantry;
import com.mygdx.rlstrategygame.GameClasses.Units.Unit;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.geometry.Point2D;

/**
 * Game class coordinates the game's logic
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class Game {
    
    public int Xmax, Zmax;
    public Settings gameSettings;
    public GameLogger logger;
    public GameState currentState;  
    public Unit selectedUnit;
    public GameAction curentAction;
    
    /**
     * Constructor for a new game, using the current settings
     * @param gameSettings the current settings
     */
    public Game(Settings gameSettings){
        this.gameSettings = gameSettings;
        
        this.currentState = new GameState(this);
        this.initialize(gameSettings.getTrackPath());
        
       if(gameSettings.isLoggingOn()){
            this.logger = new GameLogger(gameSettings.getLogging());
            String track = gameSettings.getTrackPath();
            track = track.substring(track.lastIndexOf('/')+1);
            track = track.substring(0,track.lastIndexOf(".txt"));
            this.logger.write(track);
            this.logger.write("Red Player: "+this.currentState.redPlayer.toString());
            this.logger.write("Blue Player: "+this.currentState.bluePlayer.toString());
            this.logger.write("start");
        }
    }
    
    /**
     * Initialize the game
     * @param fileName the file contains the data for the creation of the track
     * @return 
     */
    public boolean initialize(String fileName){ //fileName = axeio pistas

        FileInputStream fis = null;
        ArrayList<Unit> redUnits = new ArrayList<Unit>();
        ArrayList<Unit> blueUnits = new ArrayList<Unit>();

        try {
            fis = new FileInputStream(fileName);
            BufferedReader br = new BufferedReader(new InputStreamReader(fis));
            String line;
            try {
                while((line = br.readLine())!=null){
                    if(line.startsWith("max")){
                        line = line.substring(4);
                        
                        int index = line.indexOf(',');
                        this.Xmax = Integer.parseInt(line.substring(0, index));
                        this.Zmax = Integer.parseInt(line.substring(index+1));
                        this.currentState.locations = new BoardLocation[Xmax][Zmax];
                    }
                    else if(line.startsWith("nogo")){
                        line = line.substring(5);
                        int index = line.indexOf(',');
                        int x = Integer.parseInt(line.substring(0, index));
                        int z = Integer.parseInt(line.substring(index+1));
                        this.currentState.locations[x][z] = new BoardLocation(false,x,z);
                    }
                    else if(line.startsWith("build")){
                        
                        for(int j=0 ;j<Zmax;j++){
                            for(int i=0 ;i<Xmax;i++){
                                if(this.currentState.locations[i][j]==null) this.currentState.locations[i][j] = new BoardLocation(true,i,j);
                            }
                        }
                        
                        //initialize Around Locations
                        for(int j=0;j<Zmax;j++){
                            for(int i=0;i<Xmax;i++){
                                if(j-1>=0) this.currentState.locations[i][j].north = this.currentState.locations[i][j-1];
                                else this.currentState.locations[i][j].north = null;
                                if(j+1<Zmax) this.currentState.locations[i][j].south = this.currentState.locations[i][j+1];
                                else this.currentState.locations[i][j].south = null;
                                if(i-1>=0) this.currentState.locations[i][j].west = this.currentState.locations[i-1][j];
                                else this.currentState.locations[i][j].west = null;
                                if(i+1<Xmax) this.currentState.locations[i][j].east = this.currentState.locations[i+1][j];
                                else this.currentState.locations[i][j].east = null;
                            }
                        }
                        
                        if(gameSettings.redPlayer.equals("Human")) this.currentState.redPlayer = new HumanPlayer(0,this.currentState.locations[Xmax-1][0], new Point2D(this.Xmax,this.Zmax));
                        else if(gameSettings.redPlayer.indexOf("CPU ")!=-1) this.currentState.redPlayer = new ComputerPlayer(0,this.currentState.locations[Xmax-1][0],gameSettings.redPlayer.substring(4), new Point2D(this.Xmax,this.Zmax));
                        else System.err.println("initialize game error");
                        if(gameSettings.bluePlayer.equals("Human")) this.currentState.bluePlayer = new HumanPlayer(1,this.currentState.locations[0][Zmax-1], new Point2D(this.Xmax,this.Zmax));
                        else if(gameSettings.bluePlayer.indexOf("CPU ")!=-1) this.currentState.bluePlayer = new ComputerPlayer(1,this.currentState.locations[0][Zmax-1],gameSettings.bluePlayer.substring(4), new Point2D(this.Xmax,this.Zmax));
                        else System.err.println("initialize game error");
                        this.currentState.activePlayer = this.currentState.redPlayer;
                    }
                    else if(line.startsWith("redknight")){
                        line = line.substring(10);
                        
                        int index1 = line.indexOf(',');
                        int index2 = line.indexOf(',', index1+1);
                        int x,z,d;
                        x=Integer.parseInt(line.substring(0, index1));
                        z=Integer.parseInt(line.substring(index1+1, index2));
                        d=Integer.parseInt(line.substring(index2+1));
                        Knight U1 = new Knight(this.currentState.locations[x][z],d,this.currentState.redPlayer);
                        redUnits.add(U1);
                    }
                    
                    else if(line.startsWith("redinfantry")){
                        line = line.substring(12);
                        
                        int index1 = line.indexOf(',');
                        int index2 = line.indexOf(',', index1+1);
                        int x,z,d;
                        x=Integer.parseInt(line.substring(0, index1));
                        z=Integer.parseInt(line.substring(index1+1, index2));
                        d=Integer.parseInt(line.substring(index2+1));
                        Infantry U1 = new Infantry(this.currentState.locations[x][z],d,this.currentState.redPlayer);
                        redUnits.add(U1);
                    }
                    
                    else if(line.startsWith("redspearman")){
                        line = line.substring(12);
                        
                        int index1 = line.indexOf(',');
                        int index2 = line.indexOf(',', index1+1);
                        int x,z,d;
                        x=Integer.parseInt(line.substring(0, index1));
                        z=Integer.parseInt(line.substring(index1+1, index2));
                        d=Integer.parseInt(line.substring(index2+1));
                        Spearman U1 = new Spearman(this.currentState.locations[x][z],d,this.currentState.redPlayer);
                        redUnits.add(U1);
                    }
                    
                    else if(line.startsWith("blueknight")){
                        line = line.substring(11);
                        
                        int index1 = line.indexOf(',');
                        int index2 = line.indexOf(',', index1+1);
                        int x,z,d;
                        x=Integer.parseInt(line.substring(0, index1));
                        z=Integer.parseInt(line.substring(index1+1, index2));
                        d=Integer.parseInt(line.substring(index2+1));
                        Knight U1 = new Knight(this.currentState.locations[x][z],d,this.currentState.bluePlayer);
                        blueUnits.add(U1);
                    }
                    
                    else if(line.startsWith("blueinfantry")){
                        line = line.substring(13);
                        
                        int index1 = line.indexOf(',');
                        int index2 = line.indexOf(',', index1+1);
                        int x,z,d;
                        x=Integer.parseInt(line.substring(0, index1));
                        z=Integer.parseInt(line.substring(index1+1, index2));
                        d=Integer.parseInt(line.substring(index2+1));
                        Infantry U1 = new Infantry(this.currentState.locations[x][z],d,this.currentState.bluePlayer);
                        blueUnits.add(U1);
                    }
                    
                    else if(line.startsWith("bluespearman")){
                        line = line.substring(13);
                        
                        int index1 = line.indexOf(',');
                        int index2 = line.indexOf(',', index1+1);
                        int x,z,d;
                        x=Integer.parseInt(line.substring(0, index1));
                        z=Integer.parseInt(line.substring(index1+1, index2));
                        d=Integer.parseInt(line.substring(index2+1));
                        Spearman U1 = new Spearman(this.currentState.locations[x][z],d,this.currentState.bluePlayer);
                        blueUnits.add(U1);
                    }
                }
                br.close();
            } 
            catch (IOException ex) {
                return false;
            }
            //enimerwsi pionivn tou kathe paikti kai eisagwgi id
            
            this.currentState.redPlayer.units = redUnits.toArray( new Unit[redUnits.size()]);
            for(int i = 0;i<this.currentState.redPlayer.units.length;i++)
                this.currentState.redPlayer.units[i].id = i;
            
            this.currentState.bluePlayer.units = blueUnits.toArray(new Unit[blueUnits.size()]);
            for(int i = 0;i<this.currentState.bluePlayer.units.length;i++)
                this.currentState.bluePlayer.units[i].id = i;
            
            this.currentState.remainingMoves = 2;
            this.currentState.remainingTurns = this.gameSettings.getDrawLimit();
            this.currentState.gameOver = false;
            this.currentState.winner = null;
            this.currentState.complete = true;
            
            //eisagwgi parametrwn RL (meta tin eisagwgi twn pioniwn)
            
            if(gameSettings.redAI){
                ComputerPlayer temp = (ComputerPlayer)this.currentState.redPlayer;
                temp.initializeAI(this.gameSettings,this.currentState);
            }
            if(gameSettings.blueAI){
                ComputerPlayer temp = (ComputerPlayer)this.currentState.bluePlayer;
                temp.initializeAI(this.gameSettings, this.currentState);
            }

            return true;
        }
        catch (FileNotFoundException ex) {
            Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        finally {
            try {
                fis.close();
            } 
            catch (Exception ex) {}
        }
    }
    
    /**
     * Select the unit from a boardLocation 
     * @param location the boardLocation of the unit to be selected
     * @return true if selection is completed
     */
    public boolean selectUnit(BoardLocation location){
        if(location == null){
            selectedUnit = null;
            return false;
        }
        selectedUnit = location.unit;
        if(selectedUnit==null) return false;
        //System.out.print("Unit Selected in location X:"+location.x+",Z:"+location.z);
        return true;
    }

    /**
     * Select the unit from a boardLocation using an action as parameter
     * @param action is going to be used to find unit's location
     * @return true if selection is completed
     */
    public boolean selectUnit(GameAction action){
        if(action == null){
            selectedUnit = null;
            return false;
        }
        BoardLocation location = this.currentState.locations[action.actingUnitX][action.actingUnitZ];
        
        return selectUnit(location);
    }
    /**
     * This method is called at the end of each turn to:
     *  - write into the log file
     *  - check the winning conditions
     *  - change the acting player
     *  - save the neuralNet in file (if necessary) 
     */
    public void endOfTurnCheck (){
        //System.out.println("endOfTurnCheck");
        if(gameSettings.isLoggingOn())this.logger.write(this.curentAction.toString());
        
        //active player finished his actions
        if(this.currentState.remainingMoves == 0){//allagi paikti kai elegxos nikis
            
            //check if the game is a draw
            if(this.currentState.remainingTurns==0){
                this.currentState.gameOver = true;
                if(gameSettings.isLoggingOn()) this.logger.write("draw");
                //System.out.println("This is a draw");
                //return;
            }else{
                //game is not a draw
                this.currentState.remainingTurns--;
            
                if(currentState.activePlayer instanceof ComputerPlayer){
                    ComputerPlayer temp = (ComputerPlayer)currentState.activePlayer;
                    temp.clearActions();
                }
                //red player's turn just finished
                if(this.currentState.activePlayer.id == 0){
                    
                    //changing active player
                    this.currentState.activePlayer = this.currentState.bluePlayer;
                    this.currentState.remainingMoves = 2;
                    
                    //blue player has no possible action - red player won the game
                    if(!this.currentState.activePlayer.hasPossibleActions(this.currentState)){
                        this.currentState.gameOver = true;
                        this.currentState.winner = this.currentState.redPlayer;
                        //System.out.println("No Possible Actions for Blue Player");
                    }
                    
                    //blue player has no alive pawns - red player won the game
                    if(this.currentState.activePlayer.numberofAliveUnits == 0){
                        //System.out.println("Zero Red Untis");
                        this.currentState.gameOver = true;
                        this.currentState.winner = this.currentState.redPlayer;
                    }
                    
                    //blue player's pawn is inside red flag's corner - blue player won the game
                    else if(this.currentState.redPlayer.flag.captured && this.currentState.redPlayer.flag.unit.player.id==1){
                        //System.out.println("Red Flag Captured");
                        this.currentState.gameOver = true;
                        this.currentState.winner = this.currentState.bluePlayer;

                    }
                }
                //blue player's turn just finished
                else{
                    //changing active player
                    this.currentState.activePlayer = this.currentState.redPlayer;
                    this.currentState.remainingMoves = 2;

                    //red player has no possible action - blue player won the game
                    if(!this.currentState.activePlayer.hasPossibleActions(this.currentState)){
                        this.currentState.gameOver = true;
                        this.currentState.winner = this.currentState.bluePlayer;
                        //System.out.println("No Possible Actions for Red Player");
                    }

                    //red player has no alive pawns - blue player won the game
                    if(this.currentState.activePlayer.numberofAliveUnits == 0){
                        //System.out.println("Zero Blue Untis");
                        this.currentState.gameOver = true;
                        this.currentState.winner = this.currentState.bluePlayer;
                    }
                    //red player's pawn is inside blue flag's corner - red player won the game
                    else if(this.currentState.bluePlayer.flag.captured && this.currentState.bluePlayer.flag.unit.player.id==0){
                        //System.out.println("Blue Flag Captured");
                        this.currentState.gameOver = true;
                        this.currentState.winner = this.currentState.redPlayer;
                    }
                }
                //in case of Knight: deleting starting position
                if(selectedUnit instanceof Knight){
                    //System.out.println("Deleting Knights Starting Location");
                    Knight temp = (Knight)selectedUnit;
                    temp.startingLocation = null;
                }
                //delete selected unit
                selectedUnit = null;
            }
        }
        
        //Game is over, draw or one player won
        if(this.currentState.gameOver){
            
            //in case of AI: finalizing AI 
            //System.out.println("endOfTurnCheck - End of Game");
            if(this.currentState.redPlayer instanceof ComputerPlayer){
                ComputerPlayer temp = (ComputerPlayer)this.currentState.redPlayer;
                temp.finalizeAI(this.currentState);

            }
            if(this.currentState.bluePlayer instanceof ComputerPlayer){
                ComputerPlayer temp = (ComputerPlayer)this.currentState.bluePlayer;
                temp.finalizeAI(this.currentState);

            }
            
            //writing the result of the game in log file 
            if(gameSettings.isLoggingOn()){
                if(this.currentState.winner == null)this.logger.write("draw");
                else if(this.currentState.winner.id == 0)this.logger.write("winner red");
                else this.logger.write("winner blue");
            }
            /*
             * If the game is played in 3D enviroment, we have one single game,
             * and when it's finised, neuran net are saved in files.
             * If the game is not played in 3D enviroment, we have an array of games
             * and the neural net will be saved once by BackgroundActor class, 
             * when tha last game finishes.
             */
            if(gameSettings.isGraphicsOn()){
                gameSettings.saveNeuralNetworks();
                gameSettings.blueNeuralNet = null;
                gameSettings.redNeuralNet = null;
            }
        }
    }
    /**
     * Wake up a computer player when it is it's turn to play
     */
    public void computerAct(){
        if(this.currentState.gameOver) return;
        if(this.currentState.activePlayer instanceof ComputerPlayer){
            ComputerPlayer computerPlayer = (ComputerPlayer)this.currentState.activePlayer;
            if(computerPlayer.isReady()){
                //ektelesi energeias i enegreiwn
                this.curentAction = computerPlayer.getAction();
                selectUnit(this.curentAction);
                //System.out.println("selectedUnit:"+selectedUnit);
  
                if(this.curentAction!=null) this.currentState.perform(this.curentAction);
                endOfTurnCheck();
                //else this.remainingMoves = 0; //periptwsi adinamias ektelesis kinisis
            }
            else if(computerPlayer.isThinking()){
                //anamoni
                return;
            }
            else if(computerPlayer.isNotTriged()){
                //trigarisma
                computerPlayer.trig(this.currentState);
            }
        } else return;
    }
    
    /**
     * When the game is between two computer players
     * method playTheGame forces them to complete all their moves in order to
     * finish the game. This method is used to play games in background.  
     * @return true when game is finished
     */
    public boolean playTheGame(){
        while(!this.currentState.gameOver)computerAct();
        return true;
    }
    
}