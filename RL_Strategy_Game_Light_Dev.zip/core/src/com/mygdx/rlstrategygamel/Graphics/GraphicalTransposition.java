/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygamel.Graphics;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.mygdx.rlstrategygamel.GameClasses.BoardLocation;
import static com.mygdx.rlstrategygamel.Graphics.GraphicsGame.size;

/**
 * Moving a pawn from a BoardLocation to a nearby one or 
 * outside the chessboard in case of elimination.
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class GraphicalTransposition {
    
    private boolean moving;

    private GraphicsPawnInstance movingPawn;
    
    private float speed;
    private Vector3 curentPoint;
    
    /**
     * The primary part of the Transposition is completed in 0.5 sec.
     * In case of moving a pawn from a board square to a nearby one, 
     * the transposition has only primary part and
     * secondaryHorizontalMoving and secondaryVerticalMoving are false.
     * In case of moving a pawn from a board square to an eliminated position,
     * the primary part of transposition is the rise of the pawn up to the
     * maximum height over the board and
     * secondaryHorizontalMoving and secondaryVerticalMoving are true.
     */
    private Vector3 primaryEndPoint;
    private Vector3 primaryMovingDirection;
    private float primaryDistance;
    private boolean primaryMoving;
    
    /**
     * SecondaryHorizontalMoving is used only for moving the eliminated pawns
     * at the side of the board. It is the parallel to the board, part of the
     * move (height = 2 board squares)
     */
    private Vector3 secondaryHorizontalEndPoint;
    private Vector3 secondaryHorizontalMovingDirection;
    private float secondaryHorizontalDistance;
    private boolean secondaryHorizontalMoving;
    
    /**
     * SecondaryVerticalMoving is used only for moving the eliminated pawns
     * at the side of the board. It is the vertical to the board, part of 
     * the move witch moves the pawn down to the board, after the
     * secondaryHorizontalMoving.
     */
    private Vector3 secondaryVerticalEndPoint;
    private Vector3 secondaryVerticalMovingDirection;
    private float secondaryVerticalDistance;
    private boolean secondaryVerticalMoving;
    
    /**
     * Constructor for GraphicalTransposition.
     * Moves a pawn from it's board square to a nearby one.
     * @param pawn The pawn to be moved
     * @param end The board square destination
     */
    public GraphicalTransposition(GraphicsPawnInstance pawn,BoardLocation end){
        this.moving = true;
        primaryMoving = true;
        secondaryHorizontalMoving = false;
        secondaryVerticalMoving = false;
        
        this.movingPawn = pawn;
        primaryEndPoint = new Vector3(end.x,0,end.z);
        //System.out.println("endPoint"+endPoint);
        curentPoint = new Vector3(pawn.unit.location.x,0, pawn.unit.location.z);
        primaryDistance = primaryEndPoint.dst(movingPawn.unit.location.x,0,movingPawn.unit.location.z);
        primaryMovingDirection = primaryEndPoint.sub(curentPoint).nor();
        primaryEndPoint = new Vector3(end.x,0,end.z);
        speed = primaryDistance/0.5f; 
    }
    
    /**
     * Constructor for GraphicalTransposition.
     * It is used to move the eliminated pawn from it's board square to
     * a position at the side of the board
     * @param pawn the pawn to be moved
     * @param end the destination at the side of the board
     */
    public GraphicalTransposition(GraphicsPawnInstance pawn,Vector2 end){

        this.moving = true;
        this.primaryMoving = true;
        secondaryHorizontalMoving = true;
        secondaryVerticalMoving = true;
        this.movingPawn = pawn;
        
        //primary moving-kinhsh pros ta epanw
        primaryEndPoint = new Vector3(pawn.unit.location.x,2, pawn.unit.location.z);
        //System.out.println("endPoint"+endPoint);
        curentPoint = new Vector3(pawn.unit.location.x,0, pawn.unit.location.z);
        primaryDistance = primaryEndPoint.dst(movingPawn.unit.location.x,0,movingPawn.unit.location.z);
        primaryMovingDirection = primaryEndPoint.sub(curentPoint).nor();
        primaryEndPoint = new Vector3(pawn.unit.location.x,2, pawn.unit.location.z);
        
        speed = primaryDistance/0.5f;
        
        //secondary horizontal moving-kinhsh pros tin akri tis skakieras
        this.secondaryHorizontalEndPoint = new Vector3(end.x,2,end.y);
        this.secondaryHorizontalDistance = this.secondaryHorizontalEndPoint.dst(primaryEndPoint);
        this.secondaryHorizontalMovingDirection = secondaryHorizontalEndPoint.sub(primaryEndPoint).nor();
        this.secondaryHorizontalEndPoint = new Vector3(end.x,2,end.y);
        
        //secondary vertical moving-kinhsh pros ta katw
        this.secondaryVerticalEndPoint = new Vector3(end.x,0,end.y);
        this.secondaryVerticalDistance = this.secondaryVerticalEndPoint.dst(secondaryHorizontalEndPoint);
        this.secondaryVerticalMovingDirection = secondaryVerticalEndPoint.sub(secondaryHorizontalEndPoint).nor();
        this.secondaryVerticalEndPoint = new Vector3(end.x,0,end.y);
    }
    
    /**
     * Method is called in every screen refresh, during a transposition.
     * Move the pawn to a small distance, depending on deltaTime in order to:
     *  - complete the transposition in 0.5 sec (board square to board square)
     *  - keep speed at 2 block squares per second (moving of an eliminated pawn). 
     * @param deltaTime time between two refreshments of the screen
     */
    public void move(float deltaTime){
        if(primaryMoving){
            Vector3 deltaMovement = new Vector3(this.primaryMovingDirection.x*speed*deltaTime,this.primaryMovingDirection.y*speed*deltaTime,this.primaryMovingDirection.z*speed*deltaTime);
            if(primaryDistance < deltaMovement.len()){
                primaryDistance = 0;
                movingPawn.transform.setTranslation(size*primaryEndPoint.x,size*primaryEndPoint.y,size*primaryEndPoint.z);
                curentPoint = primaryEndPoint;
                primaryMoving = false;
                if(!secondaryHorizontalMoving) this.moving = false;
                return;
            }
            primaryDistance-=deltaMovement.len();
            curentPoint = curentPoint.add(deltaMovement);
            movingPawn.transform.setTranslation(size*curentPoint.x,size*curentPoint.y,size*curentPoint.z);
        }
        else if(this.secondaryHorizontalMoving){
            Vector3 deltaMovement = new Vector3(this.secondaryHorizontalMovingDirection.x*speed*deltaTime,this.secondaryHorizontalMovingDirection.y*speed*deltaTime,this.secondaryHorizontalMovingDirection.z*speed*deltaTime);
            if(secondaryHorizontalDistance < deltaMovement.len()){
                secondaryHorizontalDistance = 0;
                movingPawn.transform.setTranslation(size*secondaryHorizontalEndPoint.x,size*secondaryHorizontalEndPoint.y,size*secondaryHorizontalEndPoint.z);
                curentPoint = secondaryHorizontalEndPoint;
                secondaryHorizontalMoving = false;
                return;
            }
            secondaryHorizontalDistance-=deltaMovement.len();
            curentPoint = curentPoint.add(deltaMovement);
            movingPawn.transform.setTranslation(size*curentPoint.x,size*curentPoint.y,size*curentPoint.z);
        }
        else if(this.secondaryVerticalMoving){
            Vector3 deltaMovement = new Vector3(this.secondaryVerticalMovingDirection.x*speed*deltaTime,this.secondaryVerticalMovingDirection.y*speed*deltaTime,this.secondaryVerticalMovingDirection.z*speed*deltaTime);
            if(secondaryVerticalDistance < deltaMovement.len()){
                secondaryVerticalDistance = 0;
                movingPawn.transform.setTranslation(size*secondaryVerticalEndPoint.x,size*secondaryVerticalEndPoint.y,size*secondaryVerticalEndPoint.z);
                curentPoint = secondaryVerticalEndPoint;
                secondaryVerticalMoving = false;
                moving=false;
                return;
            }
            secondaryVerticalDistance-=deltaMovement.len();
            curentPoint = curentPoint.add(deltaMovement);
            movingPawn.transform.setTranslation(size*curentPoint.x,size*curentPoint.y,size*curentPoint.z);
        }
    }
    
    /**
     * @return true if the transposition is completed
     */
    public boolean isMoving(){
        return moving;
    }
}
