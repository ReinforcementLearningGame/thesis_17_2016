/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygame.Graphics;

import com.mygdx.rlstrategygame.GameClasses.BoardLocation;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g3d.Material;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;

/**
 * Graphics instance for chessboard squares
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */

public class GraphicsFloorInstance extends GraphicsInstance {
    
    private static Material activeMaterial = new Material(ColorAttribute.createDiffuse(Color.ORANGE));
    private static Material attackActiveMaterial = new Material(ColorAttribute.createDiffuse(Color.SALMON));
    
    private Material originalMaterial;
    private boolean activated;
    private boolean attackActivated;
    protected BoardLocation location;
    
    
    public GraphicsFloorInstance (Model model, String rootNode, boolean mergeTransform, BoardLocation location) {
        super(model, rootNode, mergeTransform);
        this.location = location;
        this.activated = false;
        this.attackActivated = false;
        this.originalMaterial = new Material();
        this.originalMaterial.set(this.materials.get(0));
    }

    public void activate(){
        if(this.activated) return;
        this.materials.get(0).clear();
        this.materials.get(0).set(activeMaterial);
        this.activated = true;
        this.attackActivated = false;
    }
    
    public void attackActivate(){
        if(this.activated) return;
        this.materials.get(0).clear();
        this.materials.get(0).set(attackActiveMaterial);
        this.activated = true;
        this.attackActivated = true;
    }

    public void deactivate(){
        if(!this.activated) return;
        this.materials.get(0).clear();
        this.materials.get(0).set(originalMaterial);
        this.activated = false;
        this.attackActivated = false;
    }
    
    public boolean isActivated(){
        return this.activated;
    }
    
    public boolean isAttackActivated(){
        return this.attackActivated;
    }
}