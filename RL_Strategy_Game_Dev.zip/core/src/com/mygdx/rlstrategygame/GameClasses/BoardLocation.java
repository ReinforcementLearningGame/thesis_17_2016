/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygame.GameClasses;


import com.mygdx.rlstrategygame.GameClasses.Units.Unit;
import static java.lang.Math.abs;

/**
 * Every square of the  chessboard is a BoardLocation
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class BoardLocation {
    public int x,z;
    public boolean canGo;
    public boolean captured;
    public Unit unit;
    public BoardLocation north, east, south, west;
            
    public BoardLocation(boolean canGo, int x, int z)
    {
        this.x = x;
        this.z = z;
        this.canGo = canGo;
        this.captured = false;
        this.unit = null;
        this.north = null;
        this.east = null;
        this.south = null;
        this.west = null;
    }
    
    public BoardLocation (BoardLocation original){
        this.x = original.x;
        this.z = original.z;
        this.canGo = original.canGo;
        this.captured = false;
        this.unit = null;
        this.north = null;
        this.west = null;
        this.south = null;
        this.east = null;
    }
    
    public BoardLocation next(int x){
        if(x<0||x>7) return null;
        if(x==0) return this.north;
        else if(x==1) return this.west;
        else if(x==2) return this.south;
        else if(x==3) return this.east;
        else if(x==4&&this.north!=null) return this.north.west;
        else if(x==5&&this.south!=null) return this.south.west;
        else if(x==6&&this.south!=null) return this.south.east;
        else if(x==7&&this.north!=null) return this.north.east;
        return null;
    }

    public int distance(BoardLocation location){
        if(location == null) System.err.println("BoardLocation distance null location");
        return (abs(this.x-location.x)+abs(this.z-location.z));
    }
    
    public int distance(int x, int z){
        return (abs(this.x-x)+abs(this.z-z));
    }
}
