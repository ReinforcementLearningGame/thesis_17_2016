/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygamel.GameClasses.Players;

import com.mygdx.rlstrategygamel.GameClasses.BoardLocation;
import com.mygdx.rlstrategygamel.GameClasses.Actions.GameAction;
import com.mygdx.rlstrategygamel.GameClasses.GameState;
import com.mygdx.rlstrategygamel.GameClasses.Units.Spearman;
import com.mygdx.rlstrategygamel.GameClasses.Units.Infantry;
import com.mygdx.rlstrategygamel.GameClasses.Units.Unit;
import java.util.ArrayList;
import com.badlogic.gdx.math.Vector2;

/**
 * Abstract class for 2 kinds of RL Strategy Game's players
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public abstract class Player {
    
    
    public int id;
    public BoardLocation flag;
    public int numberofAliveUnits;
    public Unit units[];
    public Vector2 boardSize;
    
    public Vector2 deadPoint; //sindetagmenes stin skakiera pou tha topothetithei to epomeno fagwmwno pioni
    public Vector2 deadVector;//vector gia ipologismo tou epomenou deadPoint
    public int deadDirection; // kateuthinsi twn fagwmwnwn pioniwn tou paikti
    
    public Player(int id,BoardLocation flag,Vector2 boardSize)
    {
        this.id =id;
        this.flag = flag;
        this.numberofAliveUnits = 0;
        this.boardSize = boardSize;
        if(id==0){
            this.deadDirection = 3;
            this.deadPoint = new Vector2(-1,-1);
            this.deadVector = new Vector2(0,1);
        }
        else if(id==1){
            this.deadDirection = 1;
            this.deadPoint = boardSize;
            this.deadVector = new Vector2(0,-1);
        }
    }
    
    public boolean hasPossibleActions(GameState state){
        //ean exei estw ena alive Infantry i Spearman exei kai pithanes kiniseis
        for(Unit unit:units)
            if(unit.alive && (unit instanceof Infantry ||unit instanceof Spearman))
                return true;
        //tha ftasei edo ean exei mono alive knights
        for(Unit unit:units)
            if(unit.alive){
                ArrayList<GameAction> possibleActions = unit.findActions(state);
                if(!possibleActions.isEmpty()) return true;
            }
        return false;
    }
}
