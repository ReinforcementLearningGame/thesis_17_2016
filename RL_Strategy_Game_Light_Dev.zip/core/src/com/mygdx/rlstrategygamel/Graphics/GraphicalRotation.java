/*
* Copyright 2016 Alexandros Nikolakakis <alexandros_nkl@hotmail.com>
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
package com.mygdx.rlstrategygamel.Graphics;

import com.badlogic.gdx.math.Vector3;

/**
 * Rotate a Pawn in 3D environment
 * @author Alexandros Nikolakakis alexandros_nkl@hotmail.com
 */
public class GraphicalRotation {
    private float speed ;
    
    private boolean rotating;
    private float turn;
    private GraphicsPawnInstance rotationPawn;
    private int endDirection;
    
    private Vector3 rotationAxis;
    /**
     * Constructor for GraphicalRotation, rotate a pawn to the endDirection
     * @param endDirection The final direction after the rotation 
     * @param pawn The pawn to be rotated
     */
    public GraphicalRotation(int endDirection, GraphicsPawnInstance pawn){
        
        this.rotating = true;
        this.rotationPawn = pawn;
        this.endDirection = endDirection;
        
        turn = endDirection-this.rotationPawn.graphicsDirection;
        if(turn == 180||turn == -180){
            turn = 180;
            rotationAxis = new Vector3(0,0,-1); //dexiostrofa
        }
        else if(turn >180){
            turn = 360 - turn;
            rotationAxis = new Vector3(0,0,-1); //dexiostrofa
        }
        else if(turn<-180){
            turn = 360+turn;
            rotationAxis = new Vector3(0,0,1); //aristerostrofa
        }
        else if(turn<0){
            turn = -turn;
            rotationAxis = new Vector3(0,0,-1); //dexiostrofa
        }
        else rotationAxis = new Vector3(0,0,1); //aristerostrofa
        speed = turn/0.5f;
    }
    /**
     * Method is called in every screen refresh, during a rotation. 
     * Rotate the pawn within a small angle, depending on deltaTime in order to
     * complete the rotation in 0.5 sec.
     * @param deltaTime time between two refreshes of the screen 
     */
    public void rotate(float deltaTime){
        //System.out.println(deltaTime);
        float deltaTurn = deltaTime * speed;
        if(deltaTurn>turn){
            deltaTurn = turn;
            turn = 0;
        }
        else turn-=deltaTurn;
        this.rotationPawn.transform.rotate(rotationAxis, deltaTurn);
        this.rotationPawn.graphicsDirection += rotationAxis.z*deltaTurn;
        //System.out.println(this.rotationPawn.graphicsDirection);
        if(this.rotationPawn.graphicsDirection>=360)this.rotationPawn.graphicsDirection-=360;
        else if(this.rotationPawn.graphicsDirection<0)this.rotationPawn.graphicsDirection+=360;
        if(turn<=0){
            this.rotating = false;
            this.rotationPawn.graphicsDirection = this.endDirection;
        }
    }
    
    /**
     * @return true if the rotation is completed
     */
    public boolean isRotating(){
        return this.rotating;
    }
}
